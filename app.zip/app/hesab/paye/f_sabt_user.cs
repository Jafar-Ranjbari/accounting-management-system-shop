﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.paye
{
    public partial class f_sabt_user : Form
    {
        public f_sabt_user()
        {
            InitializeComponent();
        }


        classes.paye d = new classes.paye();
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int i = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    d.delete_user(i);
                    dataGridView1.DataSource = d.show_user();
                    MessageBox.Show("  ویزیتور   انتخابی   " + i1 + " حذف  شد ");

                }

                

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            d.Add_user(txt_name.Text , txt_pass.Text );

            dataGridView1.DataSource = d.show_user();
            txt_pass.Text = "";
            txt_name.Text = "";
         

            MessageBox.Show("یک  ویزیتور جدید ثبت شد");

        }

        private void f_sabt_user_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource=            d.show_user();
        }
    }
}
