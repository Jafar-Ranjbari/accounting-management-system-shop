﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.paye
{
    public partial class f_sabt_froshande : Form
    {
        public f_sabt_froshande()
        {
            InitializeComponent();
        }
        public abzar.classes.paye d = new classes.paye();
        private void sabt_froshande_Load(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = d.show_Froshande();
                dataGridView1.Columns[2].Width = 110;
                dataGridView1.Columns[3].Width = 155;
                dataGridView1.Columns[4].Width = 95;
                dataGridView1.Columns[5].Width = 95;
                dataGridView1.Columns[6].Width = 175;
                dataGridView1.Columns[7].Width = 155;
                btn_edite.Visible = false;


            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void txt_Id_froshande_Move(object sender, EventArgs e)
        {
            
        }

        private void txt_Id_froshande_Leave(object sender, EventArgs e)
        {
            txt_Id_froshande.BackColor = Color.White;
        }

        private void txt_name_froshande_Leave(object sender, EventArgs e)
        {
            txt_name_froshande.BackColor = Color.White;
        }

        private void txt_fax_froshande_Leave(object sender, EventArgs e)
        {
            txt_fax_froshande.BackColor = Color.White;
        }

        private void txt_tel_froshande_Leave(object sender, EventArgs e)
        {
            txt_tel_froshande.BackColor = Color.White;
        }

        private void txt_tozih_froshnde_Leave(object sender, EventArgs e)
        {
            txt_tozih_froshnde.BackColor = Color.White;
        }

        private void txt_tozih_froshnde_Click(object sender, EventArgs e)
        {
           // txt_tozih_froshnde.BackColor = Color.Azure;
        }

        private void txt_address_froshande_Click(object sender, EventArgs e)
        {
           
        }

        private void txt_address_froshande_Layout(object sender, LayoutEventArgs e)
        {
            
        }

        private void txt_address_froshande_Leave(object sender, EventArgs e)
        {
            txt_address_froshande.BackColor = Color.White;
        }

        private void txt_tozih_froshnde_Move(object sender, EventArgs e)
        {
             
        }

        private void txt_tozih_froshnde_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void txt_tozih_froshnde_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txt_address_froshande_TabIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void txt_address_froshande_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void txt_address_froshande_KeyPress(object sender, KeyPressEventArgs e)
        {
            

        }

        private void txt_address_froshande_TextChanged(object sender, EventArgs e)
        {
            txt_address_froshande.BackColor = Color.Azure;
        }

        private void txt_Id_froshande_TextChanged(object sender, EventArgs e)
        {
            txt_Id_froshande.BackColor = Color.Azure;
        }

        private void txt_name_froshande_TextChanged(object sender, EventArgs e)
        {
            txt_name_froshande.BackColor = Color.Azure;
        }

        private void txt_fax_froshande_TextChanged(object sender, EventArgs e)
        {
            txt_fax_froshande.BackColor = Color.Azure;
        }

        private void txt_tel_froshande_TextChanged(object sender, EventArgs e)
        {
            txt_tel_froshande.BackColor = Color.Azure;
        }

        private void txt_tozih_froshnde_TextChanged(object sender, EventArgs e)
        {
            txt_tozih_froshnde.BackColor = Color.Azure;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            try
            {

                double fax;


                if (txt_fax_froshande.Text == "")


                    fax = Convert.ToDouble("0");
                else

                    fax = Convert.ToDouble(txt_fax_froshande.Text);




                double tel;


                if (txt_tel_froshande.Text == "")


                    tel = Convert.ToDouble("0");
                else

                    tel = Convert.ToDouble(txt_tel_froshande.Text);




                d.Add_sabt_froshande(int.Parse(txt_Id_froshande.Text), txt_name_froshande.Text, tel, txt_address_froshande.Text,  fax, txt_tozih_froshnde.Text);

                dataGridView1.DataSource = d.show_Froshande();
                txt_tozih_froshnde.Text = "";
                txt_tel_froshande.Text = "";
                txt_name_froshande.Text = "";
                txt_Id_froshande.Text = "";
                txt_fax_froshande.Text = "";
                txt_address_froshande.Text = "";



                MessageBox.Show("یک فروشنده جدید ثبت شد" );

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
            try{




                double fax;


                if (txt_fax_froshande.Text == "")


                    fax = Convert.ToDouble("0");
                else

                    fax = Convert.ToDouble(txt_fax_froshande.Text);




                double tel;


                if (txt_tel_froshande.Text == "")


                    tel = Convert.ToDouble("0");
                else

                    tel = Convert.ToDouble(txt_tel_froshande.Text);

            d.Edit_Froshande(int.Parse(txt_Id_froshande.Text), txt_name_froshande.Text, tel, txt_address_froshande.Text,  fax, txt_tozih_froshnde.Text);
         
            dataGridView1.DataSource = d.show_Froshande();
            MessageBox.Show("  فروشنده  انتخابی  ویرایش  شد " );
            btn_insert.Visible = true;
            btn_edite.Visible = false;
            txt_tozih_froshnde.Text = "";
            txt_tel_froshande.Text = "";
            txt_name_froshande.Text = "";
            txt_Id_froshande.Text = "";
            txt_fax_froshande.Text = "";
            txt_address_froshande.Text = "";

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try{
            if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
            {


                int i = int.Parse(dataGridView1.CurrentRow.Cells[2].Value.ToString());
                string i1 = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                d.delete_Froshande(i);
                dataGridView1.DataSource = d.show_Froshande();
                MessageBox.Show("  فروشنده  انتخابی   " + i1 + " حذف  شد " );

            }

            else if (e.ColumnIndex == 1 && e.RowIndex < dataGridView1.RowCount - 1)
            {

                txt_Id_froshande.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txt_name_froshande.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                txt_tel_froshande.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

                txt_fax_froshande.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                txt_address_froshande.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                txt_tozih_froshnde.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();

                txt_Id_froshande.ReadOnly = true;
                txt_Id_froshande.Enabled = false;
                btn_edite.Visible = true;
                btn_insert.Visible = false;

            }

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {try{
            dataGridView1.DataSource = d.show_search_froshande(txt_search.Text.ToString());
            txt_Id_froshande.Enabled = true;

        }
        catch (Exception a)
        {
            MessageBox.Show(a.Message);


        }


        }

        private void txt_tel_froshande_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_fax_froshande_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_Id_froshande_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_name_froshande_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txt_name_froshande_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        
    }
}
