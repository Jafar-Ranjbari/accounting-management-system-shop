﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
namespace abzar.paye
{
    public partial class f_sabt_moshtari : Form
    {
        public f_sabt_moshtari()
        {
            InitializeComponent();
        }
        public abzar.classes.paye d = new classes.paye();


     
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txt_Id_moshatari_Leave(object sender, EventArgs e)
        {
            txt_Id_moshatari.BackColor = Color.White;
        }

        private void txt_name_moshatari_Leave(object sender, EventArgs e)
        {
           txt_name_moshatari .BackColor = Color.White;
        }

        private void txt_fax_moshatari_Leave(object sender, EventArgs e)
        {
            txt_fax_moshatari.BackColor = Color.White;
        }

        private void txt_tel_moshatari_Leave(object sender, EventArgs e)
        {
            txt_tel_moshatari.BackColor = Color.White;
        }

        private void txt_tozih_moshatari_Leave(object sender, EventArgs e)
        {
            txt_tozih_moshatari.BackColor = Color.White;
        }

        private void txt_address_moshatari_Leave(object sender, EventArgs e)
        {
            txt_address_moshatari.BackColor = Color.White;
        }

        private void txt_Id_moshatari_TextChanged(object sender, EventArgs e)
        {
            txt_Id_moshatari.BackColor = Color.Azure;
        }

        private void txt_name_moshatari_TextChanged(object sender, EventArgs e)
        {
            txt_name_moshatari.BackColor = Color.Azure;
        }

        private void txt_fax_moshatari_TextChanged(object sender, EventArgs e)
        {
            txt_fax_moshatari.BackColor = Color.Azure;
        }

        private void txt_tel_moshatari_TextChanged(object sender, EventArgs e)
        {
            txt_tel_moshatari.BackColor = Color.Azure;
        }

        private void txt_tozih_moshatari_TextChanged(object sender, EventArgs e)
        {
            txt_tozih_moshatari.BackColor = Color.Azure;
        }

        private void txt_address_moshatari_TextChanged(object sender, EventArgs e)
        {
            txt_address_moshatari.BackColor = Color.Azure;
             
        }

        private void sabt_moshtari_Load(object sender, EventArgs e)
        {
             try
            {
                dataGridView1.DataSource = d.show_moshatri();
                dataGridView1.Columns[2].Width = 100;
                dataGridView1.Columns[3].Width = 155;
                dataGridView1.Columns[4].Width = 95;
                dataGridView1.Columns[5].Width = 95;
                dataGridView1.Columns[6].Width = 175;
                dataGridView1.Columns[7].Width = 155;
                btn_edite.Visible = false;


            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }
        
        private void btn_insert_Click(object sender, EventArgs e)
        {
            try
            {



                double fax;


                if (txt_fax_moshatari.Text == "")


                    fax = Convert.ToDouble("0");
                else

                    fax = Convert.ToDouble(txt_fax_moshatari.Text);




                double tel;


                if (txt_tel_moshatari.Text == "")


                    tel = Convert.ToDouble("0");
                else

                    tel = Convert.ToDouble(txt_tel_moshatari.Text);

                d.Add_sabt_moshatri(int.Parse(txt_Id_moshatari.Text), txt_name_moshatari.Text,  fax,  tel ,  txt_address_moshatari.Text, txt_tozih_moshatari.Text);

                dataGridView1.DataSource = d.show_moshatri();
                txt_tozih_moshatari.Text = "";
                txt_tel_moshatari.Text = "";
                txt_name_moshatari.Text = "";
                txt_Id_moshatari.Text = "";
                txt_fax_moshatari.Text = "";
                txt_address_moshatari.Text = "";



                MessageBox.Show("یک مشتری جدید ثبت شد" );

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
            try
            {




                double fax;


                if (txt_fax_moshatari.Text == "")


               fax   = Convert.ToDouble("0");
                else
                
            fax    = Convert.ToDouble(txt_fax_moshatari.Text);




                double tel;


                if (txt_tel_moshatari.Text == "")


                    tel = Convert.ToDouble("0");
                else

                    tel = Convert.ToDouble(txt_tel_moshatari.Text);



                d.Edit_moshatri(  int.Parse(txt_Id_moshatari.Text), txt_name_moshatari.Text, fax,   tel, txt_address_moshatari.Text, txt_tozih_moshatari.Text);

                dataGridView1.DataSource = d.show_moshatri();
                MessageBox.Show("  مشتری   انتخابی  ویرایش  شد " );
                btn_insert.Visible = true;
                btn_edite.Visible = false;
                txt_tozih_moshatari.Text = "";
                txt_tel_moshatari.Text = "";
                txt_name_moshatari.Text = "";
                txt_Id_moshatari.Text = "";
                txt_fax_moshatari.Text = "";
                txt_address_moshatari.Text = "";
                txt_Id_moshatari.Enabled = true;

            }

            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = d.show_search_moshatri(txt_search.Text.ToString());
            txt_Id_moshatari.Enabled = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try{
            if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
            {


                int i = int.Parse(dataGridView1.CurrentRow.Cells[2].Value.ToString());
                string i1 = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                d.delete_moshatri(i);
                dataGridView1.DataSource = d.show_moshatri();
                MessageBox.Show("  مشتری  انتخابی   " + i1 + " حذف  شد " );

            }

            else if (e.ColumnIndex == 1 && e.RowIndex < dataGridView1.RowCount - 1)
            {

                txt_Id_moshatari .Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txt_name_moshatari .Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                txt_tel_moshatari .Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

                txt_fax_moshatari.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                txt_address_moshatari.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                txt_tozih_moshatari.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();

                
                txt_Id_moshatari.Enabled = false;
                btn_edite.Visible = true;
                btn_insert.Visible = false;

            }

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }

        private void txt_Id_moshatari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_tel_moshatari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_name_moshatari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_fax_moshatari_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

         
    }
}
