﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.paye
{
    public partial class f_anbar : Form
    {
        public f_anbar()
        {
            InitializeComponent();
        }
        abzar.classes.paye d = new classes.paye();



        private void txt_fax_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
         
        }

        private void f_anbar_Load(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = d.show_anbar();

                dataGridView1.Columns[2].Width = 5;
                dataGridView1.Columns[3].Width = 170;
                dataGridView1.Columns[4].Width = 110;
                dataGridView1.Columns[5].Width = 110;
                dataGridView1.Columns[6].Width = 128;
                dataGridView1.Columns[7].Width = 120;
                
                btn_edite.Visible = false;


            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            try
            {
                Double kharid = Convert.ToDouble(txt_kharid.Text);
                Double frosh = Convert.ToDouble(txt_frosh.Text);
                if (frosh >= kharid)
                {

                    try
                    {




                        string st1 = null;

                        DataTable dt = new DataTable();
                        dt = d.count_kala( txt_name_kala.Text);
                        st1 = dt.Rows[0][0].ToString();

                        if (st1 != null)
                        {
                            MessageBox.Show(" این اجناس قبلا در انبار وارد شده است   ");




                        }

                    }
                    catch (Exception)
                    {
                        d.Add_anbar( txt_name_kala.Text, txtx_vahed.Text, int.Parse(txt_mojodi.Text), Convert.ToDouble(txt_kharid.Text), Convert.ToDouble(txt_frosh.Text));

                        dataGridView1.DataSource = d.show_anbar();
                        txt_id_kala.Text = "";
                        txt_name_kala.Text = "";
                        txtx_vahed.Text = "";
                        txt_mojodi.Text = "";
                        txt_kharid.Text = "";
                        txt_frosh.Text = "";


                        MessageBox.Show("یک اجناسی جدید ثبت شد");

                    }
                }
                else
                {

                    MessageBox.Show(" قیمت اجناسی فروش کمتر از قیمت خرید می باشد دوباره بررسی کنید");


                }
            }
            catch(Exception a)

            { MessageBox.Show(a.Message); }
        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
            try{
            Double kharid= Convert.ToDouble(txt_kharid.Text);
                Double frosh= Convert.ToDouble(txt_frosh.Text);
                if (frosh >= kharid)
                {
                    //try
                    //{
                        //int id = int.Parse(lb_id.Text);

                        d.Edit_anbar( int.Parse(txt_id_kala.Text), txt_name_kala.Text, txtx_vahed.Text, int.Parse(txt_mojodi.Text), Convert.ToDouble(txt_kharid.Text), Convert.ToDouble(txt_frosh.Text));

                        dataGridView1.DataSource = d.show_anbar();
                        MessageBox.Show(" اجناسی انتخابی ویرایش شد " );
                        btn_insert.Visible = true;
                        btn_edite.Visible = false;
                        txt_id_kala.Text = "";
                        txt_name_kala.Text = "";
                        txtx_vahed.Text = "";
                        txt_mojodi.Text = "";
                        txt_kharid.Text = "";
                        txt_frosh.Text = "";

                    //}

                    //catch (Exception a)
                    //{

                    //    MessageBox.Show(a.Message );
                    //}
                }

                else
                {

                    MessageBox.Show(" قیمت اجناسی فروش کمتر از قیمت خرید می باشد دوباره بررسی کنید" );


                }



            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int i = int.Parse(dataGridView1.CurrentRow.Cells[2].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    d.delete_anbar(i);
                    dataGridView1.DataSource = d.show_anbar();
                    MessageBox.Show(" اجناسی انتخابی به نام   " + i1 + " حذف  شد " );

                }

                else if (e.ColumnIndex == 1 && e.RowIndex < dataGridView1.RowCount - 1)
                {

                   
                    txt_id_kala.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    txt_name_kala.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    txtx_vahed.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    txt_mojodi.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    txt_kharid.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                    txt_frosh.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();

                 


                    btn_edite.Visible = true;
                    btn_insert.Visible = false;
                }
               
            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void txt_search_name_kala_TextChanged(object sender, EventArgs e)
        {

            try
            {
                dataGridView1.DataSource = d.show_search_name_kala( txt_search_name_kala.Text);
                txt_search_name_kala.BackColor = Color.Azure; ;





            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void txt_search_id_kala_TextChanged(object sender, EventArgs e)
        {

            
        }

        private void txt_search_name_kala_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9')
                e.Handled = true;
            else
                e.Handled = false;

        }

        private void txt_mojodi_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_kharid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_frosh_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void txt_search_id_kala_KeyPress(object sender, KeyPressEventArgs e)
        {
         
        }

        private void txt_mojodi_Leave(object sender, EventArgs e)
        {
            txt_mojodi.BackColor = Color.White;
        }

        private void txt_kharid_Leave(object sender, EventArgs e)
        {
            txt_kharid.BackColor = Color.White;
        }

        private void txt_frosh_Leave(object sender, EventArgs e)
        {
            txt_frosh.BackColor = Color.White;
        }

        private void txt_mojodi_TextChanged(object sender, EventArgs e)
        {
            txt_mojodi.BackColor = Color.Azure;
        }

        private void txt_kharid_TextChanged(object sender, EventArgs e)
        {
            txt_kharid.BackColor = Color.Azure;
        }

        private void txt_frosh_TextChanged(object sender, EventArgs e)
        {
            txt_frosh.BackColor = Color.Azure;
        }

        private void f_anbar_Load_1(object sender, EventArgs e)
        {

        }

        

        

        
        }

       

       
    }
 
