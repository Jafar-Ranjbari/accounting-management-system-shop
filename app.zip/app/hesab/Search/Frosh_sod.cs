﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class Frosh_sod : Form
    {
        public Frosh_sod()
        {
            InitializeComponent();
        }
   abzar.classes.Search d = new classes.Search();
        private void Frosh_sod_Load(object sender, EventArgs e)
        {

            try
            {

                DataTable dt = new DataTable();
                dt = d.frosh_sod();
                abzar.bin.Cr_frosh_sod mycr = new bin.Cr_frosh_sod();
                mycr.SetDataSource(dt);
                crystalReportViewer1.ReportSource = mycr;

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }







        }

        private void r_tarikh_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = true;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = false;
        }

        private void r_kala_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = true;
        }

        private void r_sh_faktor_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = true;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = false;
        }

        private void r_name_moshtari_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = true;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = false;
        }

        private void r_moshtari_AND_tarikh_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = true;
            group_name_kala.Visible = false;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {

                if (r_tarikh.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.frosh_by_tarikh_sod(txt_tarikhh.Text);
                    abzar.bin.Cr_frosh_sod mycr = new bin.Cr_frosh_sod();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;



                }

                else if (r_sh_faktor.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.frosh_by_sh_faktor_sod(int.Parse(txt_sh_faktor.Text));
                    abzar.bin.Cr_frosh_sod mycr = new bin.Cr_frosh_sod();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }
                else if (r_name_moshtari.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.frosh_by_id_moshtari_sod(int.Parse(txt_id_Froshande.Text));
                    abzar.bin.Cr_frosh_sod mycr = new bin.Cr_frosh_sod();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }
                else if (r_moshtari_AND_tarikh.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.frosh_by_id_moshtari_and_tarikh_sod(int.Parse(txt_id_Froshnde_and.Text), txt_tarikh_and.Text);
                    abzar.bin.Cr_frosh_sod mycr = new bin.Cr_frosh_sod();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }

                else if (r_kala.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.frosh_by_id_kala_sod(int.Parse(txt_id_kala.Text));
                    abzar.bin.Cr_frosh_sod mycr = new bin.Cr_frosh_sod();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }
            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            abzar.Search.show_kala_frosh_sod f = new show_kala_frosh_sod();
            f.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            abzar.Search.f_show_moshtari_frosh_sod f = new f_show_moshtari_frosh_sod();
            f.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            abzar.Search.f_show_moshtari_frosh_AND_sod f = new f_show_moshtari_frosh_AND_sod();
            f.Show();
            this.Close();

        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
