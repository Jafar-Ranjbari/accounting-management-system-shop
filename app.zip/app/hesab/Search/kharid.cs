﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class kharid : Form
    {
        public kharid()
        {
            InitializeComponent();
        }
        abzar.classes.Search d = new classes.Search();
        private void kharid_Load(object sender, EventArgs e)
        {
            try
            {

                DataTable dt = new DataTable();
                dt = d.kharid();
                abzar.bin.Cr_kharid mycr = new bin.Cr_kharid();
                mycr.SetDataSource(dt);
                crystalReportViewer1.ReportSource = mycr;

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
 
        }

        private void r_tarikh_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = true;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = false;
        }

        private void r_kala_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = true;
        }

        private void r_sh_faktor_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = true;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = false;
        }

        private void r_name_moshtari_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = true;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = false;
            group_name_kala.Visible = false;
        }

        private void r_moshtari_AND_tarikh_CheckedChanged(object sender, EventArgs e)
        {
            group_name_moshtari.Visible = false;
            group_sh_faktor.Visible = false;
            group_tarikh.Visible = false;
            group_tarikh_and_name_moshtari.Visible = true;
            group_name_kala.Visible = false;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {

            try
            {

                if (r_tarikh.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.kharid_by_tarikh(txt_tarikhh.Text);
                    abzar.bin.Cr_kharid mycr = new bin.Cr_kharid();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;



                }

             else   if (r_sh_faktor.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.kharid_by_sh_faktor( int.Parse(txt_sh_faktor.Text));
                    abzar.bin.Cr_kharid mycr = new bin.Cr_kharid();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }
                else if (r_name_moshtari.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.kharid_by_id_froshande(int.Parse(txt_id_Froshande.Text) );
                    abzar.bin.Cr_kharid mycr = new bin.Cr_kharid();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }
                else if (r_moshtari_AND_tarikh.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.kharid_by_id_froshande_and_tarikh(int.Parse(txt_id_Froshnde_and.Text),txt_tarikh_and.Text);
                    abzar.bin.Cr_kharid mycr = new bin.Cr_kharid();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }

                else if (r_kala.Checked)
                {

                    DataTable dt = new DataTable();
                    dt = d.kharid_by_id_kala(int.Parse(txt_id_kala.Text) );
                    abzar.bin.Cr_kharid mycr = new bin.Cr_kharid();
                    mycr.SetDataSource(dt);
                    crystalReportViewer1.ReportSource = mycr;

                }
            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            abzar.Search.f_show_id_froshande_kharid f = new  f_show_id_froshande_kharid();
            f.Show();
            this.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            abzar.Search.id_froshande_AND_tarikh_kharid f = new id_froshande_AND_tarikh_kharid();
            f.Show();
            this.Close();

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            abzar.Search.show_kala_kharid f = new show_kala_kharid();
            f.Show();
            this.Close();

        }
    }
}
