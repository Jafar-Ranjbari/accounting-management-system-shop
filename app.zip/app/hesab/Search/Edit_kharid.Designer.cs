﻿namespace abzar.Search
{
    partial class Edit_kharid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.حذف = new System.Windows.Forms.DataGridViewImageColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_search = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_moshtari = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.btn_sabt = new System.Windows.Forms.Button();
            this.txt_takhfif_frosh = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txt_id_moshtari = new System.Windows.Forms.ComboBox();
            this.txt_date = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_pri_kol_frosh = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_ID_frosh = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_gabel_pardakht = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_nagd_frosh = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_mande_frosh = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btn_mande = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txt_hazine_frosh = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_pardakht_nahayi_frosh = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel_name_kala = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel_name_kala.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // حذف
            // 
            this.حذف.HeaderText = "حذف";
            this.حذف.Image = global::abzar.Properties.Resources.delete;
            this.حذف.Name = "حذف";
            this.حذف.Width = 60;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txt_search);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Location = new System.Drawing.Point(98, 8);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(438, 57);
            this.groupBox3.TabIndex = 243;
            this.groupBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(241, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 26);
            this.label3.TabIndex = 223;
            this.label3.Text = "جستجوی سریع تاریخ فاکتور خرید\r\n         ";
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("B Mitra", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_search.Location = new System.Drawing.Point(124, 19);
            this.txt_search.Mask = "0000/00/00";
            this.txt_search.Name = "txt_search";
            this.txt_search.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_search.Size = new System.Drawing.Size(108, 28);
            this.txt_search.TabIndex = 202;
            this.txt_search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button1.Image = global::abzar.Properties.Resources._0335;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(21, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 37);
            this.button1.TabIndex = 204;
            this.button1.Text = "جستجو  ";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::abzar.Properties.Resources.Picture3;
            this.pictureBox1.Location = new System.Drawing.Point(12, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 47);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 244;
            this.pictureBox1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(696, 34);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 99;
            this.label8.Text = " تخفیف ویژه  :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(548, 34);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label16.Size = new System.Drawing.Size(30, 13);
            this.label16.TabIndex = 85;
            this.label16.Text = "ریال  ";
            // 
            // txt_moshtari
            // 
            this.txt_moshtari.AutoSize = true;
            this.txt_moshtari.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_moshtari.Location = new System.Drawing.Point(542, 35);
            this.txt_moshtari.Name = "txt_moshtari";
            this.txt_moshtari.Size = new System.Drawing.Size(19, 13);
            this.txt_moshtari.TabIndex = 242;
            this.txt_moshtari.Text = "....";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ویرایش  ";
            this.Column1.Image = global::abzar.Properties.Resources.edit1;
            this.Column1.Name = "Column1";
            this.Column1.Width = 60;
            // 
            // btn_sabt
            // 
            this.btn_sabt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_sabt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sabt.Enabled = false;
            this.btn_sabt.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_sabt.Image = global::abzar.Properties.Resources.edit;
            this.btn_sabt.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_sabt.Location = new System.Drawing.Point(75, 391);
            this.btn_sabt.Name = "btn_sabt";
            this.btn_sabt.Size = new System.Drawing.Size(192, 51);
            this.btn_sabt.TabIndex = 235;
            this.btn_sabt.Text = "ویرایش حساب فاکتور  خرید   ";
            this.btn_sabt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sabt.UseVisualStyleBackColor = true;
            this.btn_sabt.Click += new System.EventHandler(this.btn_sabt_Click);
            // 
            // txt_takhfif_frosh
            // 
            this.txt_takhfif_frosh.Location = new System.Drawing.Point(582, 31);
            this.txt_takhfif_frosh.Name = "txt_takhfif_frosh";
            this.txt_takhfif_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_takhfif_frosh.Size = new System.Drawing.Size(108, 21);
            this.txt_takhfif_frosh.TabIndex = 116;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.حذف,
            this.Column1});
            this.dataGridView1.Location = new System.Drawing.Point(13, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(774, 211);
            this.dataGridView1.TabIndex = 232;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txt_id_moshtari
            // 
            this.txt_id_moshtari.FormattingEnabled = true;
            this.txt_id_moshtari.Location = new System.Drawing.Point(67, 14);
            this.txt_id_moshtari.Name = "txt_id_moshtari";
            this.txt_id_moshtari.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_id_moshtari.Size = new System.Drawing.Size(17, 21);
            this.txt_id_moshtari.TabIndex = 233;
            this.txt_id_moshtari.Visible = false;
            // 
            // txt_date
            // 
            this.txt_date.Font = new System.Drawing.Font("B Mitra", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_date.Location = new System.Drawing.Point(605, 288);
            this.txt_date.Mask = "0000/00/00";
            this.txt_date.Name = "txt_date";
            this.txt_date.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_date.Size = new System.Drawing.Size(108, 28);
            this.txt_date.TabIndex = 234;
            this.txt_date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(39, 299);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label18.Size = new System.Drawing.Size(30, 13);
            this.label18.TabIndex = 226;
            this.label18.Text = "ریال  ";
            // 
            // txt_pri_kol_frosh
            // 
            this.txt_pri_kol_frosh.Location = new System.Drawing.Point(75, 291);
            this.txt_pri_kol_frosh.Name = "txt_pri_kol_frosh";
            this.txt_pri_kol_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_pri_kol_frosh.Size = new System.Drawing.Size(143, 21);
            this.txt_pri_kol_frosh.TabIndex = 231;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(233, 294);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label10.Size = new System.Drawing.Size(100, 13);
            this.label10.TabIndex = 227;
            this.label10.Text = "  جمع فاکتور فروش :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_ID_frosh
            // 
            this.txt_ID_frosh.AutoSize = true;
            this.txt_ID_frosh.Location = new System.Drawing.Point(12, 23);
            this.txt_ID_frosh.Name = "txt_ID_frosh";
            this.txt_ID_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_ID_frosh.Size = new System.Drawing.Size(49, 13);
            this.txt_ID_frosh.TabIndex = 228;
            this.txt_ID_frosh.Text = "id_frosh ";
            this.txt_ID_frosh.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(746, 294);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 229;
            this.label13.Text = "  تاریخ  :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(316, 34);
            this.label17.Name = "label17";
            this.label17.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label17.Size = new System.Drawing.Size(30, 13);
            this.label17.TabIndex = 84;
            this.label17.Text = "ریال  ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(780, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(10, 13);
            this.label5.TabIndex = 239;
            this.label5.Text = " ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(454, 34);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(84, 13);
            this.label9.TabIndex = 89;
            this.label9.Text = "  هزینه متفرقه  :";
            // 
            // btn_gabel_pardakht
            // 
            this.btn_gabel_pardakht.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_gabel_pardakht.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_gabel_pardakht.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_gabel_pardakht.Location = new System.Drawing.Point(201, 26);
            this.btn_gabel_pardakht.Name = "btn_gabel_pardakht";
            this.btn_gabel_pardakht.Size = new System.Drawing.Size(82, 28);
            this.btn_gabel_pardakht.TabIndex = 122;
            this.btn_gabel_pardakht.Text = "قابل  پرداخت ";
            this.btn_gabel_pardakht.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_gabel_pardakht.UseVisualStyleBackColor = true;
            this.btn_gabel_pardakht.Click += new System.EventHandler(this.btn_gabel_pardakht_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txt_nagd_frosh);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txt_mande_frosh);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.btn_mande);
            this.groupBox2.Location = new System.Drawing.Point(322, 388);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(471, 54);
            this.groupBox2.TabIndex = 237;
            this.groupBox2.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(397, 28);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(78, 13);
            this.label11.TabIndex = 95;
            this.label11.Text = "  پرداخت نقدی:";
            // 
            // txt_nagd_frosh
            // 
            this.txt_nagd_frosh.Location = new System.Drawing.Point(283, 24);
            this.txt_nagd_frosh.Name = "txt_nagd_frosh";
            this.txt_nagd_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_nagd_frosh.Size = new System.Drawing.Size(108, 21);
            this.txt_nagd_frosh.TabIndex = 114;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(249, 28);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label19.Size = new System.Drawing.Size(30, 13);
            this.label19.TabIndex = 94;
            this.label19.Text = "ریال  ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(155, 27);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label12.Size = new System.Drawing.Size(10, 13);
            this.label12.TabIndex = 91;
            this.label12.Text = " ";
            // 
            // txt_mande_frosh
            // 
            this.txt_mande_frosh.Location = new System.Drawing.Point(56, 24);
            this.txt_mande_frosh.Name = "txt_mande_frosh";
            this.txt_mande_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_mande_frosh.Size = new System.Drawing.Size(97, 21);
            this.txt_mande_frosh.TabIndex = 109;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(17, 28);
            this.label20.Name = "label20";
            this.label20.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label20.Size = new System.Drawing.Size(30, 13);
            this.label20.TabIndex = 90;
            this.label20.Text = "ریال  ";
            // 
            // btn_mande
            // 
            this.btn_mande.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_mande.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_mande.Enabled = false;
            this.btn_mande.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_mande.Location = new System.Drawing.Point(166, 20);
            this.btn_mande.Name = "btn_mande";
            this.btn_mande.Size = new System.Drawing.Size(77, 29);
            this.btn_mande.TabIndex = 122;
            this.btn_mande.Text = "مانده حساب";
            this.btn_mande.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mande.UseVisualStyleBackColor = true;
            this.btn_mande.Click += new System.EventHandler(this.btn_mande_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewImageColumn1});
            this.dataGridView3.Location = new System.Drawing.Point(20, 74);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(209, 331);
            this.dataGridView3.TabIndex = 240;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "انتخاب  ";
            this.dataGridViewImageColumn1.Image = global::abzar.Properties.Resources.file_apply;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.Width = 50;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(16, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(148, 21);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Location = new System.Drawing.Point(63, 9);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(170, 54);
            this.groupBox5.TabIndex = 241;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "جستجوی سریع نام فروشنده       ";
            // 
            // txt_hazine_frosh
            // 
            this.txt_hazine_frosh.Location = new System.Drawing.Point(345, 31);
            this.txt_hazine_frosh.Name = "txt_hazine_frosh";
            this.txt_hazine_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_hazine_frosh.Size = new System.Drawing.Size(107, 21);
            this.txt_hazine_frosh.TabIndex = 107;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_takhfif_frosh);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_hazine_frosh);
            this.groupBox1.Controls.Add(this.txt_pardakht_nahayi_frosh);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.btn_gabel_pardakht);
            this.groupBox1.Location = new System.Drawing.Point(23, 318);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(770, 64);
            this.groupBox1.TabIndex = 236;
            this.groupBox1.TabStop = false;
            // 
            // txt_pardakht_nahayi_frosh
            // 
            this.txt_pardakht_nahayi_frosh.Enabled = false;
            this.txt_pardakht_nahayi_frosh.Location = new System.Drawing.Point(52, 31);
            this.txt_pardakht_nahayi_frosh.Name = "txt_pardakht_nahayi_frosh";
            this.txt_pardakht_nahayi_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_pardakht_nahayi_frosh.Size = new System.Drawing.Size(143, 21);
            this.txt_pardakht_nahayi_frosh.TabIndex = 113;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 34);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 86;
            this.label15.Text = "ریال  ";
            // 
            // panel_name_kala
            // 
            this.panel_name_kala.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel_name_kala.Controls.Add(this.pictureBox2);
            this.panel_name_kala.Controls.Add(this.groupBox5);
            this.panel_name_kala.Controls.Add(this.dataGridView3);
            this.panel_name_kala.Location = new System.Drawing.Point(242, 8);
            this.panel_name_kala.Name = "panel_name_kala";
            this.panel_name_kala.Size = new System.Drawing.Size(242, 419);
            this.panel_name_kala.TabIndex = 245;
            this.panel_name_kala.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::abzar.Properties.Resources.Picture11;
            this.pictureBox2.Location = new System.Drawing.Point(3, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 28);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 191;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button2.Image = global::abzar.Properties.Resources.file_apply;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.Location = new System.Drawing.Point(677, 27);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 25);
            this.button2.TabIndex = 246;
            this.button2.Text = "انتخاب فروشنده  ";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Edit_kharid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(805, 455);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel_name_kala);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txt_moshtari);
            this.Controls.Add(this.btn_sabt);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_id_moshtari);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txt_pri_kol_frosh);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_ID_frosh);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Edit_kharid";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ویرایش  حساب  خرید  ";
            this.Load += new System.EventHandler(this.Edit_kharid_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_name_kala.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewImageColumn حذف;
        private System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.MaskedTextBox txt_search;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label txt_moshtari;
        private System.Windows.Forms.DataGridViewImageColumn Column1;
        private System.Windows.Forms.Button btn_sabt;
        public System.Windows.Forms.TextBox txt_takhfif_frosh;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.ComboBox txt_id_moshtari;
        public System.Windows.Forms.MaskedTextBox txt_date;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.TextBox txt_pri_kol_frosh;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label txt_ID_frosh;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_gabel_pardakht;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox txt_nagd_frosh;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox txt_mande_frosh;
        public System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btn_mande;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        public System.Windows.Forms.TextBox txt_hazine_frosh;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox txt_pardakht_nahayi_frosh;
        public System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel_name_kala;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button2;
    }
}