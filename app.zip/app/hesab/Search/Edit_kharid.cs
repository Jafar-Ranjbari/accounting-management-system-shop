﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class Edit_kharid : Form
    {
        public Edit_kharid()
        {
            InitializeComponent();
        }
        abzar.classes.sabt d = new classes.sabt();
        abzar.classes.Search dd = new classes.Search();
        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = dd.search_edit_hesab_kharid(int.Parse(txt_id_moshtari.Text), txt_search.Text);
        }

        private void btn_sabt_Click(object sender, EventArgs e)
        {
            try
            {




                btn_sabt.Enabled = false;



                int id_frosh = int.Parse(txt_ID_frosh.Text);


                string date_frosh = txt_date.Text;
                //  DateTime date_frosh = TodayMorning;
                int id_moshtari = int.Parse(txt_id_moshtari.Text);
                Double price_kol_kala_frosh = Convert.ToDouble(txt_pri_kol_frosh.Text);
                Double discount_frosh = Convert.ToDouble(txt_takhfif_frosh.Text);
                Double sundries_frosh = Convert.ToDouble(txt_hazine_frosh.Text);
                Double price_kol_faktor_frosh = Convert.ToDouble(txt_pardakht_nahayi_frosh.Text);
                Double pay_nagd_frosh = Convert.ToDouble(txt_nagd_frosh.Text);
                Double pay_mande_frosh = Convert.ToDouble(txt_mande_frosh.Text);
                d.Edit_sabt_koli_kharid(id_frosh, date_frosh, id_moshtari, price_kol_kala_frosh, discount_frosh, sundries_frosh, price_kol_faktor_frosh, pay_nagd_frosh, pay_mande_frosh);
                MessageBox.Show("  فاکتورخرید ثبت شد ");








                dataGridView1.DataSource = dd.edit_hesab_kharid(int.Parse(txt_id_moshtari.Text));

                btn_sabt.Enabled = false;
                btn_mande.Enabled = false;




                txt_date.Text = "";
                txt_pri_kol_frosh.Text = "";
                txt_takhfif_frosh.Text = "";
                txt_hazine_frosh.Text = "";
                txt_pardakht_nahayi_frosh.Text = "";
                txt_nagd_frosh.Text = "";
                txt_mande_frosh.Text = "";

            }
            catch (Exception a)

            { MessageBox.Show(a.Message); }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int i = int.Parse(dataGridView1.CurrentRow.Cells[2].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    dd.delete_edit_hesab_kharid(i);
                 
                    MessageBox.Show(" شماره فاکتور انتخابی به نام   " + i1 + " حذف  شد ");

                    dataGridView1.DataSource = dd.edit_hesab_kharid(int.Parse(txt_id_moshtari.Text));

                }

                else if (e.ColumnIndex == 1 && e.RowIndex < dataGridView1.RowCount - 1)
                {

                    txt_ID_frosh.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    txt_date.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    txt_pri_kol_frosh.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    txt_takhfif_frosh.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    txt_hazine_frosh.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                    txt_pardakht_nahayi_frosh.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                    txt_nagd_frosh.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
                    txt_mande_frosh.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
                }

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void btn_gabel_pardakht_Click(object sender, EventArgs e)
        {

            try
            {
                btn_mande.Enabled = true;
                txt_nagd_frosh.Enabled = true;
                txt_mande_frosh.Enabled = true;
                Double price = Convert.ToDouble(txt_pri_kol_frosh.Text);
                Double takhfif = Convert.ToDouble(txt_takhfif_frosh.Text);
                Double motafarege = Convert.ToDouble(txt_hazine_frosh.Text);
                txt_pardakht_nahayi_frosh.Text = Convert.ToDouble(price + motafarege - takhfif).ToString();
            }

            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }
        }

        private void btn_mande_Click(object sender, EventArgs e)
        {

            try
            {

                btn_sabt.Enabled = true;
                Double pardakht = Convert.ToDouble(txt_pardakht_nahayi_frosh.Text);
                Double nagd = Convert.ToDouble(txt_nagd_frosh.Text);
                Double motafarege = Convert.ToDouble(pardakht - nagd);
                txt_mande_frosh.Text = motafarege.ToString();
            }
            catch (Exception a)


            { MessageBox.Show(a.Message); }
        }

        private void Edit_kharid_Load(object sender, EventArgs e)
        {
            dataGridView3.DataSource = d.show_froshande();
            dataGridView3.Columns[1].Width = 2;
            dataGridView3.Columns[2].Width = 145;

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView3.RowCount - 1)
                {


                    int id_moshatri = int.Parse(dataGridView3.CurrentRow.Cells[1].Value.ToString());
                    string name_moshatri = dataGridView3.CurrentRow.Cells[2].Value.ToString();

                    string i1 = dataGridView3.CurrentRow.Cells[2].Value.ToString();


                    MessageBox.Show("فروشنده    " + i1 + " انتخاب   شد ");
                    txt_id_moshtari.Text = id_moshatri.ToString();

                    txt_moshtari.Text = i1.ToString();



                    dataGridView1.DataSource = dd.edit_hesab_kharid(int.Parse(txt_id_moshtari.Text));
                    panel_name_kala.Visible = false;
                }
            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);
            }

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            dataGridView3.DataSource = d.show_search_froshande(textBox1.Text);
            dataGridView3.Columns[1].Width = 3;
            dataGridView3.Columns[2].Width = 145;
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel_name_kala.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel_name_kala.Visible = false;
        }
    }
}
