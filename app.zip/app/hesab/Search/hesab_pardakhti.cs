﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class hesab_pardakhti : Form
    {
        public hesab_pardakhti()
        {
            InitializeComponent();
        }
        abzar.classes.Search d = new classes.Search();
        private void hesab_pardakhti_Load(object sender, EventArgs e)
        {
            try
            {

                DataTable dt = new DataTable();
                dt = d.hesab_pardakhti(); 
                abzar.bin. cr_hesab_pardakhti mycr = new bin.cr_hesab_pardakhti();
                mycr.SetDataSource(dt);
                crystalReportViewer1.ReportSource = mycr;




            }
            catch (Exception a)
            {
                
                FMessegeBox.FarsiMessegeBox.Show(a.Message, "", FMessegeBox.FMessegeBoxButtons.Ok, FMessegeBox.FMessegeBoxIcons.Error);
            }


        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {

                DataTable dt = new DataTable();
                dt = d.hesab_pardakhti_by_id(int.Parse(txt_id_froshade.Text));
                abzar.bin.cr_hesab_pardakhti mycr = new bin.cr_hesab_pardakhti();
                mycr.SetDataSource(dt);
                crystalReportViewer1.ReportSource = mycr;




            }
            catch (Exception a)
            {

                FMessegeBox.FarsiMessegeBox.Show(a.Message, "", FMessegeBox.FMessegeBoxButtons.Ok, FMessegeBox.FMessegeBoxIcons.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                abzar.Search.f_show_id_froshande_search f = new  f_show_id_froshande_search();

                f.Show();

                this.Close();





            }
            catch (Exception a)
            {

                FMessegeBox.FarsiMessegeBox.Show(a.Message, "", FMessegeBox.FMessegeBoxButtons.Ok, FMessegeBox.FMessegeBoxIcons.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
