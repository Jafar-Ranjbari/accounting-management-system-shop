﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class f_show_moshtari_frosh_sod : Form
    {
        public f_show_moshtari_frosh_sod()
        {
            InitializeComponent();
        }
        abzar.classes.Search d = new classes.Search();
        private void f_show_moshtari_frosh_sod_Load(object sender, EventArgs e)
        {
            try
            {
              dataGridView1.DataSource = d.showc_id_moshatriiii();

                dataGridView1.Columns[1].Width = 1;
                dataGridView1.Columns[2].Width = 155;


            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = d.show_search_moshatriiii(txt_search.Text);
            dataGridView1.Columns[1].Width = 1;
            dataGridView1.Columns[2].Width = 155;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {
                    int i = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();

                    MessageBox.Show("   فروشنده   " + i1 + " انتخاب   شد ");
                    abzar.Search.Frosh_sod f = new Frosh_sod();
                    f.txt_id_Froshnde_and.Text = i.ToString();
                    f.txt_name_Froshande_and.Text = i1.ToString();
                    f.r_moshtari_AND_tarikh.Checked = true;
                    f.Show();
                    this.Close();

                }




            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }
    }
}
