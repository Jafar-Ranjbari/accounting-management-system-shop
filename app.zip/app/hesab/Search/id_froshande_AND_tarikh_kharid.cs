﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class id_froshande_AND_tarikh_kharid : Form
    {
        public id_froshande_AND_tarikh_kharid()
        {
            InitializeComponent();
        }
  abzar.classes.paye d = new classes.paye();
        private void btn_edite_Click(object sender, EventArgs e)
        {
           
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = d.show_search_moshatri(txt_search.Text);
            dataGridView1.Columns[1].Width = 135;
            dataGridView1.Columns[2].Width = 155;
        }

        private void id_froshande_AND_tarikh_kharid_Load(object sender, EventArgs e)
        {
            try
            {
                classes.Search dd = new classes.Search();
                 dataGridView1.DataSource = dd.showc_id_froshande();

                dataGridView1.Columns[1].Width = 1;
                dataGridView1.Columns[2].Width = 155;


            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int i = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();


                    MessageBox.Show(" شماره  فروشنده   " + i1 + " انتخاب   شد ");
                    abzar.Search.kharid f = new kharid();
                    f.txt_id_Froshnde_and.Text = i.ToString();
                    f.txt_name_Froshande_and.Text = i1.ToString();
                    f.r_moshtari_AND_tarikh.Checked = true;
                    f.Show();
                    this.Close();

                }




            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }
    }
}
