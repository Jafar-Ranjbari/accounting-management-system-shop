﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class show_kala_kharid : Form
    {
        public show_kala_kharid()
        {
            InitializeComponent();
        }

        abzar.classes.paye d = new classes.paye();

        private void show_kala_kharid_Load(object sender, EventArgs e)
        {
            try {
            dataGridView1.DataSource = d.show_kala();
            dataGridView1.Columns[1].Width = 1;
            dataGridView1.Columns[2].Width = 155;
            dataGridView1.Columns[3].Width = 1;


            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = d.show_search_Kala(txt_search.Text);
                txt_search.BackColor = Color.Azure; ;





            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int id_kala = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string name_kala = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    string vahed_kala = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();


                    MessageBox.Show("   اجناس   " + i1 + " انتخاب   شد ");
                    abzar.Search.kharid f = new kharid();
                    f.txt_id_kala.Text = id_kala.ToString();
                    f.txt_name_kala.Text = name_kala.ToString();
                    f.r_kala.Checked = true;
                    f.Show();

                     

                    this.Close();

                }




            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }
    }
}
