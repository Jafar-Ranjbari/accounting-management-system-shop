﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.Search
{
    public partial class f_show_id_moshtari_search : Form
    {
        public f_show_id_moshtari_search()
        {
            InitializeComponent();
        }
        abzar.classes.Search d = new classes.Search();
        private void f_show_id_moshtari_search_Load(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = d.showc_id_moshatriiii();

                dataGridView1.Columns[1].Width = 1;
                dataGridView1.Columns[2].Width = 155;


            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = d.show_search_moshatriiii(txt_search.Text);
            dataGridView1.Columns[1].Width = 1;
            dataGridView1.Columns[2].Width = 155;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {
                    int i = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();

                   MessageBox.Show("  فروشنده  " + i1 + " انتخاب   شد " );
                    abzar.Search.hesab_daryafti f = new hesab_daryafti();
                    f.txt_id_froshade.Text = i.ToString();
                    f.txt_name.Text = i1.ToString();
                    f.btn_search.Enabled = true;
                    f.Show();
                    this.Close();

                }




            }
            catch (Exception a)
            {

                MessageBox.Show (a.Message );
            }
        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
            abzar.paye.f_sabt_moshtari f = new paye.f_sabt_moshtari();
            f.Show();
            this.Close();
        }
    }
}
