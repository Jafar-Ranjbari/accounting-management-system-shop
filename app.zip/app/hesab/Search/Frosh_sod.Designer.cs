﻿namespace abzar.Search
{
    partial class Frosh_sod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_tarikh_and = new System.Windows.Forms.MaskedTextBox();
            this.txt_id_Froshnde_and = new System.Windows.Forms.Label();
            this.group_tarikh_and_name_moshtari = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.txt_name_Froshande_and = new System.Windows.Forms.Label();
            this.group_sh_faktor = new System.Windows.Forms.GroupBox();
            this.txt_sh_faktor = new System.Windows.Forms.TextBox();
            this.r_tarikh = new System.Windows.Forms.RadioButton();
            this.txt_id_kala = new System.Windows.Forms.Label();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.group_name_kala = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_name_kala = new System.Windows.Forms.Label();
            this.txt_tarikhh = new System.Windows.Forms.MaskedTextBox();
            this.group_name_moshtari = new System.Windows.Forms.GroupBox();
            this.txt_id_Froshande = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_name_Frooshnde = new System.Windows.Forms.Label();
            this.r_sh_faktor = new System.Windows.Forms.RadioButton();
            this.r_kala = new System.Windows.Forms.RadioButton();
            this.r_moshtari_AND_tarikh = new System.Windows.Forms.RadioButton();
            this.r_name_moshtari = new System.Windows.Forms.RadioButton();
            this.group_tarikh = new System.Windows.Forms.GroupBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.group_tarikh_and_name_moshtari.SuspendLayout();
            this.group_sh_faktor.SuspendLayout();
            this.group_name_kala.SuspendLayout();
            this.group_name_moshtari.SuspendLayout();
            this.group_tarikh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_tarikh_and
            // 
            this.txt_tarikh_and.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txt_tarikh_and.Location = new System.Drawing.Point(6, 20);
            this.txt_tarikh_and.Mask = "0000/00/00";
            this.txt_tarikh_and.Name = "txt_tarikh_and";
            this.txt_tarikh_and.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_tarikh_and.Size = new System.Drawing.Size(104, 21);
            this.txt_tarikh_and.TabIndex = 203;
            this.txt_tarikh_and.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_id_Froshnde_and
            // 
            this.txt_id_Froshnde_and.AutoSize = true;
            this.txt_id_Froshnde_and.Location = new System.Drawing.Point(486, 35);
            this.txt_id_Froshnde_and.Name = "txt_id_Froshnde_and";
            this.txt_id_Froshnde_and.Size = new System.Drawing.Size(11, 13);
            this.txt_id_Froshnde_and.TabIndex = 211;
            this.txt_id_Froshnde_and.Text = ".";
            // 
            // group_tarikh_and_name_moshtari
            // 
            this.group_tarikh_and_name_moshtari.BackColor = System.Drawing.SystemColors.Window;
            this.group_tarikh_and_name_moshtari.Controls.Add(this.txt_tarikh_and);
            this.group_tarikh_and_name_moshtari.Controls.Add(this.txt_id_Froshnde_and);
            this.group_tarikh_and_name_moshtari.Controls.Add(this.button3);
            this.group_tarikh_and_name_moshtari.Controls.Add(this.txt_name_Froshande_and);
            this.group_tarikh_and_name_moshtari.Location = new System.Drawing.Point(270, 540);
            this.group_tarikh_and_name_moshtari.Name = "group_tarikh_and_name_moshtari";
            this.group_tarikh_and_name_moshtari.Size = new System.Drawing.Size(385, 50);
            this.group_tarikh_and_name_moshtari.TabIndex = 233;
            this.group_tarikh_and_name_moshtari.TabStop = false;
            this.group_tarikh_and_name_moshtari.Text = "لطفا  نام  مشتری  و  تاریخ را انتخاب و وارد  کنید  ";
            this.group_tarikh_and_name_moshtari.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(280, 18);
            this.button3.Name = "button3";
            this.button3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.button3.Size = new System.Drawing.Size(99, 28);
            this.button3.TabIndex = 177;
            this.button3.Text = "لطفا  انتخاب کنید  ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txt_name_Froshande_and
            // 
            this.txt_name_Froshande_and.AutoSize = true;
            this.txt_name_Froshande_and.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_name_Froshande_and.Location = new System.Drawing.Point(133, 26);
            this.txt_name_Froshande_and.Name = "txt_name_Froshande_and";
            this.txt_name_Froshande_and.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_name_Froshande_and.Size = new System.Drawing.Size(19, 13);
            this.txt_name_Froshande_and.TabIndex = 179;
            this.txt_name_Froshande_and.Text = "   :";
            // 
            // group_sh_faktor
            // 
            this.group_sh_faktor.BackColor = System.Drawing.SystemColors.Window;
            this.group_sh_faktor.Controls.Add(this.txt_sh_faktor);
            this.group_sh_faktor.Location = new System.Drawing.Point(124, 540);
            this.group_sh_faktor.Name = "group_sh_faktor";
            this.group_sh_faktor.Size = new System.Drawing.Size(140, 46);
            this.group_sh_faktor.TabIndex = 235;
            this.group_sh_faktor.TabStop = false;
            this.group_sh_faktor.Text = "شماره فاکتور  را وارد کنید  ";
            this.group_sh_faktor.Visible = false;
            // 
            // txt_sh_faktor
            // 
            this.txt_sh_faktor.Location = new System.Drawing.Point(22, 18);
            this.txt_sh_faktor.Name = "txt_sh_faktor";
            this.txt_sh_faktor.Size = new System.Drawing.Size(101, 21);
            this.txt_sh_faktor.TabIndex = 0;
            // 
            // r_tarikh
            // 
            this.r_tarikh.AutoSize = true;
            this.r_tarikh.Location = new System.Drawing.Point(1185, 569);
            this.r_tarikh.Name = "r_tarikh";
            this.r_tarikh.Size = new System.Drawing.Size(52, 17);
            this.r_tarikh.TabIndex = 227;
            this.r_tarikh.TabStop = true;
            this.r_tarikh.Text = "تاریخ  ";
            this.r_tarikh.UseVisualStyleBackColor = true;
            this.r_tarikh.CheckedChanged += new System.EventHandler(this.r_tarikh_CheckedChanged);
            // 
            // txt_id_kala
            // 
            this.txt_id_kala.AutoSize = true;
            this.txt_id_kala.Location = new System.Drawing.Point(321, 28);
            this.txt_id_kala.Name = "txt_id_kala";
            this.txt_id_kala.Size = new System.Drawing.Size(11, 13);
            this.txt_id_kala.TabIndex = 211;
            this.txt_id_kala.Text = ".";
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.crystalReportViewer1.Location = new System.Drawing.Point(5, 5);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(1250, 529);
            this.crystalReportViewer1.TabIndex = 224;
            this.crystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // group_name_kala
            // 
            this.group_name_kala.BackColor = System.Drawing.SystemColors.Window;
            this.group_name_kala.Controls.Add(this.txt_id_kala);
            this.group_name_kala.Controls.Add(this.button2);
            this.group_name_kala.Controls.Add(this.txt_name_kala);
            this.group_name_kala.Location = new System.Drawing.Point(276, 600);
            this.group_name_kala.Name = "group_name_kala";
            this.group_name_kala.Size = new System.Drawing.Size(268, 49);
            this.group_name_kala.TabIndex = 232;
            this.group_name_kala.TabStop = false;
            this.group_name_kala.Text = "لطفا  نام  اجناس را انتخاب کنید  ";
            this.group_name_kala.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(158, 16);
            this.button2.Name = "button2";
            this.button2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.button2.Size = new System.Drawing.Size(99, 28);
            this.button2.TabIndex = 177;
            this.button2.Text = "لطفا  انتخاب کنید  ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txt_name_kala
            // 
            this.txt_name_kala.AutoSize = true;
            this.txt_name_kala.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_name_kala.Location = new System.Drawing.Point(22, 24);
            this.txt_name_kala.Name = "txt_name_kala";
            this.txt_name_kala.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_name_kala.Size = new System.Drawing.Size(19, 13);
            this.txt_name_kala.TabIndex = 179;
            this.txt_name_kala.Text = "   :";
            // 
            // txt_tarikhh
            // 
            this.txt_tarikhh.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txt_tarikhh.Location = new System.Drawing.Point(19, 20);
            this.txt_tarikhh.Mask = "0000/00/00";
            this.txt_tarikhh.Name = "txt_tarikhh";
            this.txt_tarikhh.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_tarikhh.Size = new System.Drawing.Size(104, 21);
            this.txt_tarikhh.TabIndex = 203;
            this.txt_tarikhh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // group_name_moshtari
            // 
            this.group_name_moshtari.BackColor = System.Drawing.SystemColors.Window;
            this.group_name_moshtari.Controls.Add(this.txt_id_Froshande);
            this.group_name_moshtari.Controls.Add(this.button1);
            this.group_name_moshtari.Controls.Add(this.txt_name_Frooshnde);
            this.group_name_moshtari.Location = new System.Drawing.Point(550, 598);
            this.group_name_moshtari.Name = "group_name_moshtari";
            this.group_name_moshtari.Size = new System.Drawing.Size(280, 50);
            this.group_name_moshtari.TabIndex = 231;
            this.group_name_moshtari.TabStop = false;
            this.group_name_moshtari.Text = "لطفا  نام  مشتری را انتخاب کنید  ";
            this.group_name_moshtari.Visible = false;
            // 
            // txt_id_Froshande
            // 
            this.txt_id_Froshande.AutoSize = true;
            this.txt_id_Froshande.Location = new System.Drawing.Point(321, 31);
            this.txt_id_Froshande.Name = "txt_id_Froshande";
            this.txt_id_Froshande.Size = new System.Drawing.Size(11, 13);
            this.txt_id_Froshande.TabIndex = 211;
            this.txt_id_Froshande.Text = ".";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(150, 16);
            this.button1.Name = "button1";
            this.button1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.button1.Size = new System.Drawing.Size(99, 28);
            this.button1.TabIndex = 177;
            this.button1.Text = "لطفا  انتخاب کنید  ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_name_Frooshnde
            // 
            this.txt_name_Frooshnde.AutoSize = true;
            this.txt_name_Frooshnde.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_name_Frooshnde.Location = new System.Drawing.Point(16, 24);
            this.txt_name_Frooshnde.Name = "txt_name_Frooshnde";
            this.txt_name_Frooshnde.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_name_Frooshnde.Size = new System.Drawing.Size(19, 13);
            this.txt_name_Frooshnde.TabIndex = 179;
            this.txt_name_Frooshnde.Text = "   :";
            // 
            // r_sh_faktor
            // 
            this.r_sh_faktor.AutoSize = true;
            this.r_sh_faktor.Location = new System.Drawing.Point(997, 569);
            this.r_sh_faktor.Name = "r_sh_faktor";
            this.r_sh_faktor.Size = new System.Drawing.Size(90, 17);
            this.r_sh_faktor.TabIndex = 228;
            this.r_sh_faktor.TabStop = true;
            this.r_sh_faktor.Text = "شماره فاکتور  ";
            this.r_sh_faktor.UseVisualStyleBackColor = true;
            this.r_sh_faktor.CheckedChanged += new System.EventHandler(this.r_sh_faktor_CheckedChanged);
            // 
            // r_kala
            // 
            this.r_kala.AutoSize = true;
            this.r_kala.Location = new System.Drawing.Point(1107, 569);
            this.r_kala.Name = "r_kala";
            this.r_kala.Size = new System.Drawing.Size(62, 17);
            this.r_kala.TabIndex = 226;
            this.r_kala.TabStop = true;
            this.r_kala.Text = "نام اجناس  ";
            this.r_kala.UseVisualStyleBackColor = true;
            this.r_kala.CheckedChanged += new System.EventHandler(this.r_kala_CheckedChanged);
            // 
            // r_moshtari_AND_tarikh
            // 
            this.r_moshtari_AND_tarikh.AutoSize = true;
            this.r_moshtari_AND_tarikh.Location = new System.Drawing.Point(754, 569);
            this.r_moshtari_AND_tarikh.Name = "r_moshtari_AND_tarikh";
            this.r_moshtari_AND_tarikh.Size = new System.Drawing.Size(119, 17);
            this.r_moshtari_AND_tarikh.TabIndex = 229;
            this.r_moshtari_AND_tarikh.TabStop = true;
            this.r_moshtari_AND_tarikh.Text = "نام  مشتری و تاریخ  ";
            this.r_moshtari_AND_tarikh.UseVisualStyleBackColor = true;
            this.r_moshtari_AND_tarikh.CheckedChanged += new System.EventHandler(this.r_moshtari_AND_tarikh_CheckedChanged);
            // 
            // r_name_moshtari
            // 
            this.r_name_moshtari.AutoSize = true;
            this.r_name_moshtari.Location = new System.Drawing.Point(894, 569);
            this.r_name_moshtari.Name = "r_name_moshtari";
            this.r_name_moshtari.Size = new System.Drawing.Size(87, 17);
            this.r_name_moshtari.TabIndex = 230;
            this.r_name_moshtari.TabStop = true;
            this.r_name_moshtari.Text = "نام  مشتری  ";
            this.r_name_moshtari.UseVisualStyleBackColor = true;
            this.r_name_moshtari.CheckedChanged += new System.EventHandler(this.r_name_moshtari_CheckedChanged);
            // 
            // group_tarikh
            // 
            this.group_tarikh.BackColor = System.Drawing.SystemColors.Window;
            this.group_tarikh.Controls.Add(this.txt_tarikhh);
            this.group_tarikh.Location = new System.Drawing.Point(124, 598);
            this.group_tarikh.Name = "group_tarikh";
            this.group_tarikh.Size = new System.Drawing.Size(129, 57);
            this.group_tarikh.TabIndex = 234;
            this.group_tarikh.TabStop = false;
            this.group_tarikh.Text = "لطفا  تاریخ را وارد کنید  ";
            this.group_tarikh.Visible = false;
            // 
            // btn_search
            // 
            this.btn_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_search.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Image = global::abzar.Properties.Resources._0335;
            this.btn_search.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_search.Location = new System.Drawing.Point(12, 562);
            this.btn_search.Name = "btn_search";
            this.btn_search.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_search.Size = new System.Drawing.Size(106, 77);
            this.btn_search.TabIndex = 225;
            this.btn_search.Text = "جستجو  ";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::abzar.Properties.Resources.Picture3;
            this.pictureBox1.Location = new System.Drawing.Point(661, 541);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 51);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 236;
            this.pictureBox1.TabStop = false;
            // 
            // Frosh_sod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1261, 661);
            this.Controls.Add(this.group_tarikh_and_name_moshtari);
            this.Controls.Add(this.group_sh_faktor);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.r_tarikh);
            this.Controls.Add(this.crystalReportViewer1);
            this.Controls.Add(this.group_name_kala);
            this.Controls.Add(this.group_name_moshtari);
            this.Controls.Add(this.r_sh_faktor);
            this.Controls.Add(this.r_kala);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.r_moshtari_AND_tarikh);
            this.Controls.Add(this.r_name_moshtari);
            this.Controls.Add(this.group_tarikh);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.Name = "Frosh_sod";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "گزارش سود فروش";
            this.Load += new System.EventHandler(this.Frosh_sod_Load);
            this.group_tarikh_and_name_moshtari.ResumeLayout(false);
            this.group_tarikh_and_name_moshtari.PerformLayout();
            this.group_sh_faktor.ResumeLayout(false);
            this.group_sh_faktor.PerformLayout();
            this.group_name_kala.ResumeLayout(false);
            this.group_name_kala.PerformLayout();
            this.group_name_moshtari.ResumeLayout(false);
            this.group_name_moshtari.PerformLayout();
            this.group_tarikh.ResumeLayout(false);
            this.group_tarikh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.MaskedTextBox txt_tarikh_and;
        public System.Windows.Forms.Label txt_id_Froshnde_and;
        public System.Windows.Forms.GroupBox group_tarikh_and_name_moshtari;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Label txt_name_Froshande_and;
        private System.Windows.Forms.GroupBox group_sh_faktor;
        public System.Windows.Forms.TextBox txt_sh_faktor;
        public System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.RadioButton r_tarikh;
        public System.Windows.Forms.Label txt_id_kala;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        public System.Windows.Forms.GroupBox group_name_kala;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Label txt_name_kala;
        public System.Windows.Forms.MaskedTextBox txt_tarikhh;
        public System.Windows.Forms.GroupBox group_name_moshtari;
        public System.Windows.Forms.Label txt_id_Froshande;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label txt_name_Frooshnde;
        public System.Windows.Forms.RadioButton r_sh_faktor;
        public System.Windows.Forms.RadioButton r_kala;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.RadioButton r_moshtari_AND_tarikh;
        public System.Windows.Forms.RadioButton r_name_moshtari;
        private System.Windows.Forms.GroupBox group_tarikh;
    }
}