﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace abzar
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {


            DateTime CurrentDateTime = DateTime.Now;
            PersianCalendar PC = new PersianCalendar();




            int PersianYear = PC.GetYear(CurrentDateTime);
            int PersianMonth = PC.GetMonth(CurrentDateTime);
            int PersianDay = PC.GetDayOfMonth(CurrentDateTime);
         //   string time = PersianYear.ToString() + "/" + PersianMonth.ToString() + "/" + PersianDay.ToString();




            ///////////////////
            PersianCalendar jc = new PersianCalendar();
            DateTime date = new DateTime(jc.GetYear(CurrentDateTime), jc.GetMonth(CurrentDateTime), jc.GetDayOfMonth(CurrentDateTime));
            string print = string.Format("{0:0000}/{1:00}/{2:00}", date.Year, date.Month, date.Day);


            ///////////////////


 

                MessageBox.Show(" امروز  مورخه   " +  print.ToString()   +" است به برنامه خوش امدید   " );

         
            }

        private void ثبتدورهآموزشیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.paye.f_sabt_kala f = new paye.f_sabt_kala();
            f.ShowDialog();

        }

        private void ثبتمشتریToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.paye.f_sabt_moshtari f = new paye.f_sabt_moshtari();
            f.ShowDialog();
        }

        private void ثبتفروشندهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.paye.f_sabt_froshande f = new paye.f_sabt_froshande();
            f.ShowDialog();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            abzar.paye.f_anbar f = new paye.f_anbar();



            f.ShowDialog();

        }

        private void iconits1_Click(object sender, EventArgs e)
        {
            abzar.paye.f_anbar f = new paye.f_anbar();
            f.ShowDialog();

        }

        private void ثبتشمارهكاردكسToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.sabt_Faktor.f_frosh2 f = new sabt_Faktor.f_frosh2();
            f.ShowDialog();
        }

        private void فاکتورخریدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.sabt_Faktor.kharid f = new sabt_Faktor.kharid();
            f.ShowDialog();

        }

       
        private void گزارشمالیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.Search.hesab_pardakhti f = new Search.hesab_pardakhti();
            f.ShowDialog();
        }

        private void حضورغیابToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.Search.hesab_daryafti f = new Search.hesab_daryafti();
            f.ShowDialog();
        }

      
        private void فروشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.Search.kharid f = new Search.kharid();
            f.ShowDialog();
        }

        private void فروشToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            abzar.Search.frosh f = new Search.frosh();
            f.ShowDialog();
        }

        private void iconits2_Click(object sender, EventArgs e)
        {
            abzar.sabt_Faktor.f_frosh2 f = new sabt_Faktor.f_frosh2();
            f.ShowDialog();
        }

        private void iconits3_Click(object sender, EventArgs e)
        {
            abzar.Search.hesab_daryafti f = new Search.hesab_daryafti();
            f.ShowDialog();
        }

        private void iconits4_Click(object sender, EventArgs e)
        {
            abzar.Search.hesab_pardakhti f = new Search.hesab_pardakhti();
            f.ShowDialog();

        }

  

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

            Application.Exit();

           
           
        }

         public void close_form()
        {
            

        
        
        }
       

       

        private void ماشینحسابToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc");
        }

        private void خریدToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            abzar.Search.Edit_kharid f = new Search.Edit_kharid();
            f.ShowDialog();
        }

        private void فروشToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            abzar.Search.Edit_frosh f = new Search.Edit_frosh();
            f.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void گزارشسودفروشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.Search.Frosh_sod f = new Search.Frosh_sod();
            f.ShowDialog();
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void ثبتکارمندToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.paye.f_sabt_user f = new paye.f_sabt_user();
            f.ShowDialog();
        }

        private void مدیریتاجناسهاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abzar.sabt_Faktor.f_manger_kala f = new sabt_Faktor.f_manger_kala();
            f.ShowDialog();
        }
    }
}
