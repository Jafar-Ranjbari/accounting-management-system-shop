﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.sabt_Faktor
{
    public partial class f_show_id_froshande : Form
    {
        public f_show_id_froshande()
        {
            InitializeComponent();
        }
      //  abzar.classes.chek d = new classes.chek();
        private void f_show_id_froshande_Load(object sender, EventArgs e)
        {
            try
            {
            //    dataGridView1.DataSource = d.showc_id_froshande();

                dataGridView1.Columns[1].Width = 5;
                dataGridView1.Columns[2].Width = 155;


            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


           
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int i = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();


                   MessageBox.Show(" شماره  فروشنده   " + i1 + " انتخاب   شد "  );
               
                    this.Close();

                }




            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
         
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
           // dataGridView1.DataSource = d.show_search_moshatri(txt_search.Text);
        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
            try{
            abzar.paye.f_sabt_froshande f = new paye.f_sabt_froshande();
            f.Show();
            this.Close();

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }
    }
}
