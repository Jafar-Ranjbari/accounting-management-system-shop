﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.sabt_Faktor
{
    public partial class show_kala : Form
    {
        public show_kala()
        {
            InitializeComponent();
        }

        abzar.classes.paye d = new classes.paye();

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = d.show_search_Kala(txt_search.Text);
                txt_search.BackColor = Color.Azure; ;





            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int id_kala = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string name_kala = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    string vahed_kala = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();


                   MessageBox.Show(" شماره  اجناس   " + i1 + " انتخاب   شد "  );
                    abzar.sabt_Faktor.f_frosh2 f = new f_frosh2();
                    f.txt_id_kala.Text = id_kala.ToString();
                    f.txt_name_kala.Text = name_kala.ToString();
                    f.txt_vahed.Text = vahed_kala.ToString();

                    abzar.classes.sabt dd = new classes.sabt();
                    
                    DataTable dt = new DataTable();
                    dt = dd.price_frosh(id_kala);
                    f.txt_price.Text = dt.Rows[0][0].ToString();
                    
                    this.Close();

                }




            }
            catch (Exception a)
            {

             MessageBox.Show(a.Message );
            }
        }

        private void show_kala_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = d.show_kala();
        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
            try{
            abzar.paye.show_kala f = new paye.show_kala();
            f.Show();
            this.Close();

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }
    }
}
