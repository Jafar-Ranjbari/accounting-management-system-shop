﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.sabt_Faktor
{
    public partial class F_report_frosh : Form
    {
        public F_report_frosh()
        {
            InitializeComponent();
        }
      
        private void F_report_frosh_Load(object sender, EventArgs e)
        {
            try
            {
                abzar.classes.sabt d = new classes.sabt();
                DataTable dt = new DataTable();
                dt = d.test_report(int.Parse( d.Getmax_id_frosh()));
                abzar.bin.cr_report_frosh_tak mycr = new bin.cr_report_frosh_tak();
                mycr.SetDataSource(dt);
                crystalReportViewer1.ReportSource = mycr;

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
             
        }
    }
}
