﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.sabt_Faktor
{
    public partial class kharid : Form
    {
        public kharid()
        {
            InitializeComponent();
        }
        abzar.classes.sabt d = new classes.sabt();
        int id_kharid;
        private void kharid_Load(object sender, EventArgs e)
        {

            try
            {

                dataGridView2.DataSource = d.show_kala();
                dataGridView3.DataSource = d.show_froshande();




                dataGridView2.Columns[1].Width = 2;
                dataGridView2.Columns[2].Width = 145;
                dataGridView2.Columns[3].Width = 2;



                dataGridView3.Columns[1].Width = 2;
                dataGridView3.Columns[2].Width = 145;


                // dataGridView1.Columns[1].Width = 2;
                //  dataGridView1.Columns[2].Width = 2;
                //dataGridView1.Columns[3].Width = 150;


                // id_frosh    جستجوی  


                DataTable dt = new DataTable();
                dt = d.max_ID_kharid();
                if (dt.Rows[0][0].ToString() == "")

                    id_kharid = 1;
                else
                {

                    int x = int.Parse(dt.Rows[0][0].ToString());
                    int y = x + 1;
                    id_kharid = y;
                }


                //////////

                txt_ID.Text = id_kharid.ToString();
                dataGridView1.DataSource = d.show_kharid_Kala(int.Parse(txt_ID.Text));
                d.Add_faktor_kharid(int.Parse(txt_ID.Text));


            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }



        }

        private void btn_ADD_Click(object sender, EventArgs e)
        {
             try
             {

            dataGridView1.Columns[1].Width = 2;
            dataGridView1.Columns[2].Width = 180;
            dataGridView1.Columns[3].Width = 150;

                btn_gabel_pardakht.Enabled = true;


                // اضافه کردن    id_frosh  to  tbl_faktor  


                abzar.classes.sabt d = new classes.sabt();





                Double tedad = Convert.ToDouble(txt_tedad.Text);
                Double vahed = Convert.ToDouble(txt_price.Text);


                Double price_kol_kala_frosh = Convert.ToDouble(tedad * vahed);


                d.Add_kharid_kala(int.Parse(txt_id_kala.Text), txt_name_kala.Text, txt_vahed.Text, int.Parse(txt_tedad.Text), Convert.ToDouble(txt_price.Text), price_kol_kala_frosh, int.Parse(txt_ID.Text));


           

                txt_id_kala.Text = "";
                txt_name_kala.Text = "";
                txt_vahed.Text = "";
                txt_tedad.Text = "";
                txt_price.Text = "";
                dataGridView1.DataSource = d.show_kharid_Kala(int.Parse(txt_ID.Text));

                ///   sum_frosh_Kala 

                DataTable dt1 = new DataTable();
                dt1 = d.sum_kharid_Kala(int.Parse(txt_ID.Text));
                txt_pri_kol_frosh.Text = dt1.Rows[0][0].ToString();
                MessageBox.Show("   اجناس  با موفقیت به فاکتور خرید اضافه شد");



             }
             catch (Exception a)
             {
                 MessageBox.Show(a.Message);


             }


           
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            try
            {
                abzar.classes.paye d = new classes.paye();
                dataGridView2.DataSource = d.show_search_Kala(txt_search.Text);
                txt_search.BackColor = Color.Azure; ;

                dataGridView2.Columns[1].Width = 2;
                dataGridView2.Columns[2].Width = 145;
                dataGridView2.Columns[3].Width = 2;



            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message );
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try{
            if (e.ColumnIndex == 0 && e.RowIndex < dataGridView2.RowCount - 1)
            {


                int id_kala = int.Parse(dataGridView2.CurrentRow.Cells[1].Value.ToString());
                string name_kala = dataGridView2.CurrentRow.Cells[2].Value.ToString();
                string vahed_kala = dataGridView2.CurrentRow.Cells[3].Value.ToString();
                string i1 = dataGridView2.CurrentRow.Cells[2].Value.ToString();


                MessageBox.Show(" شماره  اجناس   " + i1 + " انتخاب   شد " );

                txt_id_kala.Text = id_kala.ToString();
                txt_name_kala.Text = name_kala.ToString();
                txt_vahed.Text = vahed_kala.ToString();
                panel_name_kala.Visible = false;

            }

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }

        private void btn_edite_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {try{

            if (e.ColumnIndex == 0 && e.RowIndex < dataGridView3.RowCount - 1)
            {


                int id_moshatri = int.Parse(dataGridView3.CurrentRow.Cells[1].Value.ToString());
                string name_moshatri = dataGridView3.CurrentRow.Cells[2].Value.ToString();

                string i1 = dataGridView3.CurrentRow.Cells[2].Value.ToString();


                MessageBox.Show(" شماره فروشنده    " + i1 + " انتخاب   شد " );
                txt_id_moshtari.Text = id_moshatri.ToString();

                txt_moshtari.Text = i1.ToString();
                panel_moshtari.Visible = false;
            }

        }
        catch (Exception a)
        {
            MessageBox.Show(a.Message);


        }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dataGridView3.DataSource = d.show_search_froshande(textBox1.Text);
            dataGridView3.Columns[1].Width = 3;
            dataGridView3.Columns[2].Width = 145;
        }

        private void txt_search_name_kala_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try{
            if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
            {


                int i = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                d.delete_kharid_kala(i);
                dataGridView1.DataSource = d.show_kharid_Kala(int.Parse(txt_ID.Text));
                MessageBox.Show("  اجناسی  انتخابی   " + i1 + " حذف  شد " );

                DataTable dt1 = new DataTable();
                dt1 = d.sum_kharid_Kala(int.Parse(txt_ID.Text));
               
                txt_pri_kol_frosh.Text = dt1.Rows[0][0].ToString();

            }

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }

        private void btn_gabel_pardakht_Click(object sender, EventArgs e)
        {
            try{
            btn_mande.Enabled = true;
            txt_nagd_frosh.Enabled = true;
            txt_mande_frosh.Enabled = true;
            Double price = Convert.ToDouble(txt_pri_kol_frosh.Text);
            Double takhfif = Convert.ToDouble(txt_takhfif_frosh.Text);
            Double motafarege = Convert.ToDouble(txt_hazine_frosh.Text);
            txt_pardakht_frosh.Text = Convert.ToDouble(price + motafarege - takhfif).ToString();

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }


        }

        private void btn_mande_Click(object sender, EventArgs e)
        {try{
               btn_sabt.Enabled = true;
            Double pardakht = Convert.ToDouble(txt_pardakht_frosh.Text);
            Double nagd = Convert.ToDouble(txt_nagd_frosh.Text);
            Double motafarege = Convert.ToDouble(pardakht-nagd );
            txt_mande_frosh.Text = motafarege.ToString();

        }
        catch (Exception a)
        {
            MessageBox.Show(a.Message);


        }


        }


        DateTime TodayMorning
        {
            get { return new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day); }
        }
        private void btn_sabt_Click(object sender, EventArgs e)
        {try{

           
            btn_sabt.Enabled = false;



            int id_frosh = int.Parse(txt_ID.Text);


            string date_frosh = txt_date.Text; 
         
            int id_moshtari = int.Parse(txt_id_moshtari.Text);
            Double price_kol_kala_frosh = Convert.ToDouble(txt_pri_kol_frosh.Text);
            Double discount_frosh = Convert.ToDouble(txt_takhfif_frosh.Text);
            Double sundries_frosh = Convert.ToDouble(txt_hazine_frosh.Text);
            Double price_kol_faktor_frosh = Convert.ToDouble(txt_pardakht_frosh.Text);
            Double pay_nagd_frosh = Convert.ToDouble(txt_nagd_frosh.Text);
            Double pay_mande_frosh = Convert.ToDouble(txt_mande_frosh.Text);
            d.Edit_sabt_koli_kharid(id_frosh, date_frosh, id_moshtari, price_kol_kala_frosh, discount_frosh, sundries_frosh, price_kol_faktor_frosh, pay_nagd_frosh, pay_mande_frosh);
            MessageBox.Show("  فاکتورخرید ثبت شد " );

        }
        catch (Exception a)
        {
            MessageBox.Show(a.Message);


        }


        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            panel_name_kala.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel_name_kala.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            panel_moshtari.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel_moshtari.Visible = true;
        }
    }
}
