﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar.sabt_Faktor
{
    public partial class f_manger_kala : Form
    {
        public f_manger_kala()
        {
            InitializeComponent();
        }
        classes.paye d = new classes.paye(); classes.sabt dd = new classes.sabt();
        private void f_manger_kala_Load(object sender, EventArgs e)
        {
            combo_kala.DataSource = d.showKala1();
            combo_kala.DisplayMember = "name_kala";
            combo_kala.ValueMember = "id_kala";



            combo_karmand.DataSource = d.show_user1();
            combo_karmand.DisplayMember = "user_name";
            combo_karmand.ValueMember = "id_user";
        }

        private void button1_Click(object sender, EventArgs e)
        {


            dd.Add_kala_and_user(int.Parse(combo_karmand.SelectedValue.ToString()), int.Parse(combo_kala.SelectedValue.ToString()));

            dataGridView1.DataSource = dd.show_kala_and_user(int.Parse(combo_karmand.SelectedValue.ToString()));
        }

        private void btn_ADD_Click(object sender, EventArgs e)
        {
           dataGridView1.DataSource=  dd.show_kala_and_user(int.Parse(combo_karmand.SelectedValue.ToString()));
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {try
             {
                if (e.ColumnIndex == 0 && e.RowIndex < dataGridView1.RowCount - 1)
                {


                    int i = int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                    string i1 = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    dd.delete_kala_and_user(i);
                    dataGridView1.DataSource = dd.show_kala_and_user(int.Parse(combo_karmand.SelectedValue.ToString()));
                    MessageBox.Show("  اجناسی    انتخابی   " + i1 + " حذف  شد ");

                }

                

            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);


            }
        }
    }
}
