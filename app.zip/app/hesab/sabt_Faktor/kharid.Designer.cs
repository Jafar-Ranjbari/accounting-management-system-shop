﻿namespace abzar.sabt_Faktor
{
    partial class kharid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label16 = new System.Windows.Forms.Label();
            this.txt_tedad = new System.Windows.Forms.TextBox();
            this.txt_vahed = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.txt_takhfif_frosh = new System.Windows.Forms.TextBox();
            this.txt_name_kala = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_hazine_frosh = new System.Windows.Forms.TextBox();
            this.txt_id_kala = new System.Windows.Forms.ComboBox();
            this.txt_date = new System.Windows.Forms.MaskedTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_ADD = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.txt_pardakht_frosh = new System.Windows.Forms.TextBox();
            this.txt_ID = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_pri_kol_frosh = new System.Windows.Forms.TextBox();
            this.txt_id_moshtari = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.حذف = new System.Windows.Forms.DataGridViewImageColumn();
            this.txt_nagd_frosh = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_mande_frosh = new System.Windows.Forms.TextBox();
            this.btn_mande = new System.Windows.Forms.Button();
            this.btn_gabel_pardakht = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_sabt = new System.Windows.Forms.Button();
            this.txt_moshtari = new System.Windows.Forms.Label();
            this.panel_name_kala = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel_moshtari = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel_name_kala.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel_moshtari.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(548, 34);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label16.Size = new System.Drawing.Size(30, 13);
            this.label16.TabIndex = 85;
            this.label16.Text = "ریال  ";
            // 
            // txt_tedad
            // 
            this.txt_tedad.Location = new System.Drawing.Point(200, 21);
            this.txt_tedad.Name = "txt_tedad";
            this.txt_tedad.Size = new System.Drawing.Size(49, 21);
            this.txt_tedad.TabIndex = 1;
            // 
            // txt_vahed
            // 
            this.txt_vahed.AutoSize = true;
            this.txt_vahed.Location = new System.Drawing.Point(223, 48);
            this.txt_vahed.Name = "txt_vahed";
            this.txt_vahed.Size = new System.Drawing.Size(52, 13);
            this.txt_vahed.TabIndex = 213;
            this.txt_vahed.Text = "واحد اجناس  ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(454, 34);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(84, 13);
            this.label9.TabIndex = 89;
            this.label9.Text = "  هزینه متفرقه  :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(466, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 13);
            this.label6.TabIndex = 215;
            this.label6.Text = " قیمت واحد خرید  : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(696, 34);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 99;
            this.label8.Text = " تخفیف ویژه  :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(316, 34);
            this.label17.Name = "label17";
            this.label17.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label17.Size = new System.Drawing.Size(30, 13);
            this.label17.TabIndex = 84;
            this.label17.Text = "ریال  ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(327, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 11);
            this.label4.TabIndex = 210;
            this.label4.Text = "ریال  ";
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(359, 21);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(105, 21);
            this.txt_price.TabIndex = 0;
            // 
            // txt_takhfif_frosh
            // 
            this.txt_takhfif_frosh.Location = new System.Drawing.Point(582, 31);
            this.txt_takhfif_frosh.Name = "txt_takhfif_frosh";
            this.txt_takhfif_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_takhfif_frosh.Size = new System.Drawing.Size(108, 21);
            this.txt_takhfif_frosh.TabIndex = 4;
            // 
            // txt_name_kala
            // 
            this.txt_name_kala.Location = new System.Drawing.Point(560, 21);
            this.txt_name_kala.Name = "txt_name_kala";
            this.txt_name_kala.ReadOnly = true;
            this.txt_name_kala.Size = new System.Drawing.Size(145, 21);
            this.txt_name_kala.TabIndex = 218;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(744, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(10, 13);
            this.label5.TabIndex = 212;
            this.label5.Text = " ";
            // 
            // txt_hazine_frosh
            // 
            this.txt_hazine_frosh.Location = new System.Drawing.Point(345, 31);
            this.txt_hazine_frosh.Name = "txt_hazine_frosh";
            this.txt_hazine_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_hazine_frosh.Size = new System.Drawing.Size(107, 21);
            this.txt_hazine_frosh.TabIndex = 5;
            // 
            // txt_id_kala
            // 
            this.txt_id_kala.FormattingEnabled = true;
            this.txt_id_kala.Location = new System.Drawing.Point(12, 422);
            this.txt_id_kala.Name = "txt_id_kala";
            this.txt_id_kala.Size = new System.Drawing.Size(12, 21);
            this.txt_id_kala.TabIndex = 209;
            this.txt_id_kala.Visible = false;
            // 
            // txt_date
            // 
            this.txt_date.Font = new System.Drawing.Font("B Mitra", 11F);
            this.txt_date.Location = new System.Drawing.Point(357, 283);
            this.txt_date.Mask = "0000/00/00";
            this.txt_date.Name = "txt_date";
            this.txt_date.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_date.Size = new System.Drawing.Size(108, 28);
            this.txt_date.TabIndex = 2;
            this.txt_date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(255, 24);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 13);
            this.label21.TabIndex = 211;
            this.label21.Text = " تعداد  :";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewImageColumn1});
            this.dataGridView3.Location = new System.Drawing.Point(15, 78);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(209, 325);
            this.dataGridView3.TabIndex = 220;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "انتخاب  ";
            this.dataGridViewImageColumn1.Image = global::abzar.Properties.Resources.file_apply;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.Width = 50;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Location = new System.Drawing.Point(54, 10);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(170, 54);
            this.groupBox5.TabIndex = 222;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "جستجوی سریع نام  فروشنده         ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(16, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(148, 21);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txt_search);
            this.groupBox4.Location = new System.Drawing.Point(64, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(156, 54);
            this.groupBox4.TabIndex = 223;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "جستجوی سریع نام اجناس       ";
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(24, 20);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(126, 21);
            this.txt_search.TabIndex = 8;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // btn_ADD
            // 
            this.btn_ADD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_ADD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ADD.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_ADD.Image = global::abzar.Properties.Resources.shopping_cart_full1;
            this.btn_ADD.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_ADD.Location = new System.Drawing.Point(50, 9);
            this.btn_ADD.Name = "btn_ADD";
            this.btn_ADD.Size = new System.Drawing.Size(132, 43);
            this.btn_ADD.TabIndex = 219;
            this.btn_ADD.Text = " اضافه کردن به فاکتور  ";
            this.btn_ADD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ADD.UseVisualStyleBackColor = true;
            this.btn_ADD.Click += new System.EventHandler(this.btn_ADD_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dataGridView2.Location = new System.Drawing.Point(10, 79);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(210, 325);
            this.dataGridView2.TabIndex = 221;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "انتخاب  ";
            this.Column1.Image = global::abzar.Properties.Resources.file_apply;
            this.Column1.Name = "Column1";
            this.Column1.Width = 50;
            // 
            // txt_pardakht_frosh
            // 
            this.txt_pardakht_frosh.Enabled = false;
            this.txt_pardakht_frosh.Location = new System.Drawing.Point(52, 31);
            this.txt_pardakht_frosh.Name = "txt_pardakht_frosh";
            this.txt_pardakht_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_pardakht_frosh.Size = new System.Drawing.Size(143, 21);
            this.txt_pardakht_frosh.TabIndex = 6;
            // 
            // txt_ID
            // 
            this.txt_ID.AutoSize = true;
            this.txt_ID.Location = new System.Drawing.Point(25, 407);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_ID.Size = new System.Drawing.Size(49, 13);
            this.txt_ID.TabIndex = 195;
            this.txt_ID.Text = "id_frosh ";
            this.txt_ID.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 34);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 86;
            this.label15.Text = "ریال  ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(397, 28);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(78, 13);
            this.label11.TabIndex = 95;
            this.label11.Text = "  پرداخت نقدی:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(20, 289);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label18.Size = new System.Drawing.Size(30, 13);
            this.label18.TabIndex = 193;
            this.label18.Text = "ریال  ";
            // 
            // txt_pri_kol_frosh
            // 
            this.txt_pri_kol_frosh.Enabled = false;
            this.txt_pri_kol_frosh.Location = new System.Drawing.Point(64, 286);
            this.txt_pri_kol_frosh.Name = "txt_pri_kol_frosh";
            this.txt_pri_kol_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_pri_kol_frosh.Size = new System.Drawing.Size(143, 21);
            this.txt_pri_kol_frosh.TabIndex = 3;
            // 
            // txt_id_moshtari
            // 
            this.txt_id_moshtari.FormattingEnabled = true;
            this.txt_id_moshtari.Location = new System.Drawing.Point(357, 283);
            this.txt_id_moshtari.Name = "txt_id_moshtari";
            this.txt_id_moshtari.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_id_moshtari.Size = new System.Drawing.Size(13, 21);
            this.txt_id_moshtari.TabIndex = 200;
            this.txt_id_moshtari.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.حذف});
            this.dataGridView1.Location = new System.Drawing.Point(25, 68);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(764, 205);
            this.dataGridView1.TabIndex = 199;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // حذف
            // 
            this.حذف.HeaderText = "حذف";
            this.حذف.Image = global::abzar.Properties.Resources.delete;
            this.حذف.Name = "حذف";
            this.حذف.Width = 60;
            // 
            // txt_nagd_frosh
            // 
            this.txt_nagd_frosh.Location = new System.Drawing.Point(283, 24);
            this.txt_nagd_frosh.Name = "txt_nagd_frosh";
            this.txt_nagd_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_nagd_frosh.Size = new System.Drawing.Size(108, 21);
            this.txt_nagd_frosh.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(213, 291);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label10.Size = new System.Drawing.Size(100, 13);
            this.label10.TabIndex = 194;
            this.label10.Text = "  جمع فاکتور فروش :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(477, 291);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 196;
            this.label13.Text = "  تاریخ  :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(155, 27);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label12.Size = new System.Drawing.Size(10, 13);
            this.label12.TabIndex = 91;
            this.label12.Text = " ";
            // 
            // txt_mande_frosh
            // 
            this.txt_mande_frosh.Location = new System.Drawing.Point(56, 24);
            this.txt_mande_frosh.Name = "txt_mande_frosh";
            this.txt_mande_frosh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_mande_frosh.Size = new System.Drawing.Size(97, 21);
            this.txt_mande_frosh.TabIndex = 8;
            // 
            // btn_mande
            // 
            this.btn_mande.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_mande.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_mande.Enabled = false;
            this.btn_mande.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_mande.Location = new System.Drawing.Point(166, 20);
            this.btn_mande.Name = "btn_mande";
            this.btn_mande.Size = new System.Drawing.Size(77, 29);
            this.btn_mande.TabIndex = 122;
            this.btn_mande.Text = "مانده حساب";
            this.btn_mande.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mande.UseVisualStyleBackColor = true;
            this.btn_mande.Click += new System.EventHandler(this.btn_mande_Click);
            // 
            // btn_gabel_pardakht
            // 
            this.btn_gabel_pardakht.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_gabel_pardakht.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_gabel_pardakht.Enabled = false;
            this.btn_gabel_pardakht.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_gabel_pardakht.Location = new System.Drawing.Point(201, 26);
            this.btn_gabel_pardakht.Name = "btn_gabel_pardakht";
            this.btn_gabel_pardakht.Size = new System.Drawing.Size(82, 28);
            this.btn_gabel_pardakht.TabIndex = 122;
            this.btn_gabel_pardakht.Text = "قابل  پرداخت ";
            this.btn_gabel_pardakht.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_gabel_pardakht.UseVisualStyleBackColor = true;
            this.btn_gabel_pardakht.Click += new System.EventHandler(this.btn_gabel_pardakht_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txt_nagd_frosh);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txt_mande_frosh);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.btn_mande);
            this.groupBox2.Location = new System.Drawing.Point(311, 380);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(478, 54);
            this.groupBox2.TabIndex = 206;
            this.groupBox2.TabStop = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(249, 28);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label19.Size = new System.Drawing.Size(30, 13);
            this.label19.TabIndex = 94;
            this.label19.Text = "ریال  ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(17, 28);
            this.label20.Name = "label20";
            this.label20.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label20.Size = new System.Drawing.Size(30, 13);
            this.label20.TabIndex = 90;
            this.label20.Text = "ریال  ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_takhfif_frosh);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_hazine_frosh);
            this.groupBox1.Controls.Add(this.txt_pardakht_frosh);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.btn_gabel_pardakht);
            this.groupBox1.Location = new System.Drawing.Point(12, 310);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(777, 64);
            this.groupBox1.TabIndex = 205;
            this.groupBox1.TabStop = false;
            // 
            // btn_sabt
            // 
            this.btn_sabt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_sabt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sabt.Enabled = false;
            this.btn_sabt.Image = global::abzar.Properties.Resources.save_as_2;
            this.btn_sabt.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_sabt.Location = new System.Drawing.Point(99, 393);
            this.btn_sabt.Name = "btn_sabt";
            this.btn_sabt.Size = new System.Drawing.Size(131, 42);
            this.btn_sabt.TabIndex = 10;
            this.btn_sabt.Text = "ثبت فاکتور  ";
            this.btn_sabt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sabt.UseVisualStyleBackColor = true;
            this.btn_sabt.Click += new System.EventHandler(this.btn_sabt_Click);
            // 
            // txt_moshtari
            // 
            this.txt_moshtari.AutoSize = true;
            this.txt_moshtari.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_moshtari.Location = new System.Drawing.Point(594, 286);
            this.txt_moshtari.Name = "txt_moshtari";
            this.txt_moshtari.Size = new System.Drawing.Size(19, 13);
            this.txt_moshtari.TabIndex = 225;
            this.txt_moshtari.Text = "....";
            // 
            // panel_name_kala
            // 
            this.panel_name_kala.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel_name_kala.Controls.Add(this.pictureBox2);
            this.panel_name_kala.Controls.Add(this.groupBox4);
            this.panel_name_kala.Controls.Add(this.dataGridView2);
            this.panel_name_kala.Location = new System.Drawing.Point(430, 20);
            this.panel_name_kala.Name = "panel_name_kala";
            this.panel_name_kala.Size = new System.Drawing.Size(242, 419);
            this.panel_name_kala.TabIndex = 226;
            this.panel_name_kala.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::abzar.Properties.Resources.Picture11;
            this.pictureBox2.Location = new System.Drawing.Point(3, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 28);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 191;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button1.Image = global::abzar.Properties.Resources.file_apply;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(711, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 25);
            this.button1.TabIndex = 227;
            this.button1.Text = " انتخاب اجناس  ";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // panel_moshtari
            // 
            this.panel_moshtari.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel_moshtari.Controls.Add(this.pictureBox1);
            this.panel_moshtari.Controls.Add(this.groupBox5);
            this.panel_moshtari.Controls.Add(this.dataGridView3);
            this.panel_moshtari.Location = new System.Drawing.Point(119, 15);
            this.panel_moshtari.Name = "panel_moshtari";
            this.panel_moshtari.Size = new System.Drawing.Size(242, 419);
            this.panel_moshtari.TabIndex = 226;
            this.panel_moshtari.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::abzar.Properties.Resources.Picture11;
            this.pictureBox1.Location = new System.Drawing.Point(8, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 191;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button2.Image = global::abzar.Properties.Resources.adim;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.Location = new System.Drawing.Point(678, 283);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 28);
            this.button2.TabIndex = 227;
            this.button2.Text = "انتخاب  فروشنده ";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // kharid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 455);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel_moshtari);
            this.Controls.Add(this.panel_name_kala);
            this.Controls.Add(this.txt_moshtari);
            this.Controls.Add(this.txt_tedad);
            this.Controls.Add(this.txt_vahed);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.txt_name_kala);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_id_kala);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.btn_ADD);
            this.Controls.Add(this.txt_ID);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txt_pri_kol_frosh);
            this.Controls.Add(this.txt_id_moshtari);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_sabt);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "kharid";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ثبت فاکتور  خرید  ";
            this.Load += new System.EventHandler(this.kharid_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_name_kala.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel_moshtari.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_tedad;
        public System.Windows.Forms.Label txt_vahed;
        public System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txt_price;
        public System.Windows.Forms.TextBox txt_takhfif_frosh;
        public System.Windows.Forms.TextBox txt_name_kala;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txt_hazine_frosh;
        public System.Windows.Forms.ComboBox txt_id_kala;
        public System.Windows.Forms.MaskedTextBox txt_date;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Button btn_ADD;
        private System.Windows.Forms.DataGridView dataGridView2;
        public System.Windows.Forms.TextBox txt_pardakht_frosh;
        public System.Windows.Forms.Label txt_ID;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.TextBox txt_pri_kol_frosh;
        public System.Windows.Forms.ComboBox txt_id_moshtari;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.TextBox txt_nagd_frosh;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox txt_mande_frosh;
        private System.Windows.Forms.Button btn_mande;
        private System.Windows.Forms.Button btn_gabel_pardakht;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_sabt;
        public System.Windows.Forms.Label txt_moshtari;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewImageColumn Column1;
        private System.Windows.Forms.DataGridViewImageColumn حذف;
        private System.Windows.Forms.Panel panel_name_kala;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel_moshtari;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
    }
}