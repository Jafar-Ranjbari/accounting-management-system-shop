﻿namespace abzar
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.qToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتمشتریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتفروشندهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتکارمندToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بخشآزمايشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.فاکتورخریدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.مدیریتاجناسهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بخشحسابداريToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پروندهاساتیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشمالیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.حضورغیابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.فروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.فروشToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.گزارشسودفروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.ویرایشحسابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خریدToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.فروشToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.iconits1 = new yojanahanif.Iconits();
            this.iconits3 = new yojanahanif.Iconits();
            this.iconits4 = new yojanahanif.Iconits();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Thistle;
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 12F);
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(25, 25);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.qToolStripMenuItem,
            this.بخشآزمايشToolStripMenuItem,
            this.بخشحسابداريToolStripMenuItem,
            this.toolStripMenuItem2});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(1344, 33);
            this.menuStrip1.Stretch = false;
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical270;
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // qToolStripMenuItem
            // 
            this.qToolStripMenuItem.Checked = true;
            this.qToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.qToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripSeparator4,
            this.ثبتمشتریToolStripMenuItem,
            this.toolStripSeparator3,
            this.ثبتفروشندهToolStripMenuItem,
            this.toolStripSeparator2,
            this.ثبتکارمندToolStripMenuItem});
            this.qToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qToolStripMenuItem.Image = global::abzar.Properties.Resources.cubos;
            this.qToolStripMenuItem.Name = "qToolStripMenuItem";
            this.qToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.qToolStripMenuItem.Text = "اطلاعات پایه";
            this.qToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = global::abzar.Properties.Resources.large_icons;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(169, 22);
            this.toolStripMenuItem3.Text = "انبارداری";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(166, 6);
            // 
            // ثبتمشتریToolStripMenuItem
            // 
            this.ثبتمشتریToolStripMenuItem.Image = global::abzar.Properties.Resources.users;
            this.ثبتمشتریToolStripMenuItem.Name = "ثبتمشتریToolStripMenuItem";
            this.ثبتمشتریToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.ثبتمشتریToolStripMenuItem.Text = "ثبت  مشتری  ";
            this.ثبتمشتریToolStripMenuItem.Click += new System.EventHandler(this.ثبتمشتریToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(166, 6);
            // 
            // ثبتفروشندهToolStripMenuItem
            // 
            this.ثبتفروشندهToolStripMenuItem.Image = global::abzar.Properties.Resources.user;
            this.ثبتفروشندهToolStripMenuItem.Name = "ثبتفروشندهToolStripMenuItem";
            this.ثبتفروشندهToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.ثبتفروشندهToolStripMenuItem.Text = "ثبت  فروشنده  ";
            this.ثبتفروشندهToolStripMenuItem.Click += new System.EventHandler(this.ثبتفروشندهToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(166, 6);
            // 
            // ثبتکارمندToolStripMenuItem
            // 
            this.ثبتکارمندToolStripMenuItem.Image = global::abzar.Properties.Resources.adim;
            this.ثبتکارمندToolStripMenuItem.Name = "ثبتکارمندToolStripMenuItem";
            this.ثبتکارمندToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.ثبتکارمندToolStripMenuItem.Text = "ثبت  ویزیتور";
            this.ثبتکارمندToolStripMenuItem.Click += new System.EventHandler(this.ثبتکارمندToolStripMenuItem_Click);
            // 
            // بخشآزمايشToolStripMenuItem
            // 
            this.بخشآزمايشToolStripMenuItem.Checked = true;
            this.بخشآزمايشToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.بخشآزمايشToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator6,
            this.فاکتورخریدToolStripMenuItem,
            this.toolStripSeparator1,
            this.مدیریتاجناسهاToolStripMenuItem});
            this.بخشآزمايشToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.بخشآزمايشToolStripMenuItem.Image = global::abzar.Properties.Resources.chip2;
            this.بخشآزمايشToolStripMenuItem.Name = "بخشآزمايشToolStripMenuItem";
            this.بخشآزمايشToolStripMenuItem.Size = new System.Drawing.Size(75, 29);
            this.بخشآزمايشToolStripMenuItem.Text = "ثبت  ";
            this.بخشآزمايشToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(182, 6);
            // 
            // فاکتورخریدToolStripMenuItem
            // 
            this.فاکتورخریدToolStripMenuItem.Image = global::abzar.Properties.Resources.money;
            this.فاکتورخریدToolStripMenuItem.Name = "فاکتورخریدToolStripMenuItem";
            this.فاکتورخریدToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.فاکتورخریدToolStripMenuItem.Text = "ثبت  دستور خرید  ";
            this.فاکتورخریدToolStripMenuItem.Click += new System.EventHandler(this.فاکتورخریدToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(182, 6);
            // 
            // مدیریتاجناسهاToolStripMenuItem
            // 
            this.مدیریتاجناسهاToolStripMenuItem.Image = global::abzar.Properties.Resources.applications;
            this.مدیریتاجناسهاToolStripMenuItem.Name = "مدیریتاجناسهاToolStripMenuItem";
            this.مدیریتاجناسهاToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.مدیریتاجناسهاToolStripMenuItem.Text = "مدیریت  اجناس";
            this.مدیریتاجناسهاToolStripMenuItem.Click += new System.EventHandler(this.مدیریتاجناسهاToolStripMenuItem_Click);
            // 
            // بخشحسابداريToolStripMenuItem
            // 
            this.بخشحسابداريToolStripMenuItem.BackColor = System.Drawing.Color.Thistle;
            this.بخشحسابداريToolStripMenuItem.Checked = true;
            this.بخشحسابداريToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.بخشحسابداريToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.پروندهاساتیدToolStripMenuItem,
            this.toolStripSeparator9,
            this.فروشToolStripMenuItem,
            this.toolStripSeparator10,
            this.فروشToolStripMenuItem1,
            this.toolStripSeparator5,
            this.گزارشسودفروشToolStripMenuItem,
            this.toolStripSeparator16,
            this.ویرایشحسابToolStripMenuItem});
            this.بخشحسابداريToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.بخشحسابداريToolStripMenuItem.Image = global::abzar.Properties.Resources.investigacion;
            this.بخشحسابداريToolStripMenuItem.Name = "بخشحسابداريToolStripMenuItem";
            this.بخشحسابداريToolStripMenuItem.Size = new System.Drawing.Size(157, 29);
            this.بخشحسابداريToolStripMenuItem.Text = "گزارش و جستجو  ";
            this.بخشحسابداريToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // پروندهاساتیدToolStripMenuItem
            // 
            this.پروندهاساتیدToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.گزارشمالیToolStripMenuItem,
            this.toolStripSeparator12,
            this.حضورغیابToolStripMenuItem});
            this.پروندهاساتیدToolStripMenuItem.Image = global::abzar.Properties.Resources.Wincal;
            this.پروندهاساتیدToolStripMenuItem.Name = "پروندهاساتیدToolStripMenuItem";
            this.پروندهاساتیدToolStripMenuItem.Size = new System.Drawing.Size(192, 32);
            this.پروندهاساتیدToolStripMenuItem.Text = "حسابداری";
            // 
            // گزارشمالیToolStripMenuItem
            // 
            this.گزارشمالیToolStripMenuItem.Image = global::abzar.Properties.Resources.undo;
            this.گزارشمالیToolStripMenuItem.Name = "گزارشمالیToolStripMenuItem";
            this.گزارشمالیToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.گزارشمالیToolStripMenuItem.Text = "پرداختی";
            this.گزارشمالیToolStripMenuItem.Click += new System.EventHandler(this.گزارشمالیToolStripMenuItem_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(128, 6);
            // 
            // حضورغیابToolStripMenuItem
            // 
            this.حضورغیابToolStripMenuItem.Image = global::abzar.Properties.Resources.redo;
            this.حضورغیابToolStripMenuItem.Name = "حضورغیابToolStripMenuItem";
            this.حضورغیابToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.حضورغیابToolStripMenuItem.Text = "دریافتی  ";
            this.حضورغیابToolStripMenuItem.Click += new System.EventHandler(this.حضورغیابToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(189, 6);
            // 
            // فروشToolStripMenuItem
            // 
            this.فروشToolStripMenuItem.Image = global::abzar.Properties.Resources.money;
            this.فروشToolStripMenuItem.Name = "فروشToolStripMenuItem";
            this.فروشToolStripMenuItem.Size = new System.Drawing.Size(192, 32);
            this.فروشToolStripMenuItem.Text = "گزارش خرید شده";
            this.فروشToolStripMenuItem.Click += new System.EventHandler(this.فروشToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(189, 6);
            // 
            // فروشToolStripMenuItem1
            // 
            this.فروشToolStripMenuItem1.Image = global::abzar.Properties.Resources.shopping_cart_full;
            this.فروشToolStripMenuItem1.Name = "فروشToolStripMenuItem1";
            this.فروشToolStripMenuItem1.Size = new System.Drawing.Size(192, 32);
            this.فروشToolStripMenuItem1.Text = "سفارش اجناس";
            this.فروشToolStripMenuItem1.Click += new System.EventHandler(this.فروشToolStripMenuItem1_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(189, 6);
            // 
            // گزارشسودفروشToolStripMenuItem
            // 
            this.گزارشسودفروشToolStripMenuItem.Image = global::abzar.Properties.Resources.chart;
            this.گزارشسودفروشToolStripMenuItem.Name = "گزارشسودفروشToolStripMenuItem";
            this.گزارشسودفروشToolStripMenuItem.Size = new System.Drawing.Size(192, 32);
            this.گزارشسودفروشToolStripMenuItem.Text = "گزارش سود  ";
            this.گزارشسودفروشToolStripMenuItem.Click += new System.EventHandler(this.گزارشسودفروشToolStripMenuItem_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(189, 6);
            // 
            // ویرایشحسابToolStripMenuItem
            // 
            this.ویرایشحسابToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.خریدToolStripMenuItem1,
            this.toolStripSeparator15,
            this.فروشToolStripMenuItem2});
            this.ویرایشحسابToolStripMenuItem.Image = global::abzar.Properties.Resources.edit;
            this.ویرایشحسابToolStripMenuItem.Name = "ویرایشحسابToolStripMenuItem";
            this.ویرایشحسابToolStripMenuItem.Size = new System.Drawing.Size(192, 32);
            this.ویرایشحسابToolStripMenuItem.Text = "ویرایش  حساب";
            // 
            // خریدToolStripMenuItem1
            // 
            this.خریدToolStripMenuItem1.Name = "خریدToolStripMenuItem1";
            this.خریدToolStripMenuItem1.Size = new System.Drawing.Size(181, 22);
            this.خریدToolStripMenuItem1.Text = "خرید  ";
            this.خریدToolStripMenuItem1.Click += new System.EventHandler(this.خریدToolStripMenuItem1_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(178, 6);
            // 
            // فروشToolStripMenuItem2
            // 
            this.فروشToolStripMenuItem2.Name = "فروشToolStripMenuItem2";
            this.فروشToolStripMenuItem2.Size = new System.Drawing.Size(181, 22);
            this.فروشToolStripMenuItem2.Text = "سفارشات ویزیتور";
            this.فروشToolStripMenuItem2.Click += new System.EventHandler(this.فروشToolStripMenuItem2_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Checked = true;
            this.toolStripMenuItem2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripMenuItem2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem2.Image = global::abzar.Properties.Resources.exit;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(78, 29);
            this.toolStripMenuItem2.Text = "خروج";
            this.toolStripMenuItem2.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // iconits1
            // 
            this.iconits1.BackColor = System.Drawing.Color.LavenderBlush;
            this.iconits1.Blur = true;
            this.iconits1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconits1.Icon = global::abzar.Properties.Resources.anbar;
            this.iconits1.IconSize = new System.Drawing.Size(80, 64);
            this.iconits1.Location = new System.Drawing.Point(1223, 484);
            this.iconits1.Margin = new System.Windows.Forms.Padding(4);
            this.iconits1.Name = "iconits1";
            this.iconits1.Size = new System.Drawing.Size(88, 81);
            this.iconits1.TabIndex = 74;
            this.iconits1.TooltipText = "";
            this.iconits1.Click += new System.EventHandler(this.iconits1_Click);
            // 
            // iconits3
            // 
            this.iconits3.BackColor = System.Drawing.Color.LavenderBlush;
            this.iconits3.Blur = true;
            this.iconits3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconits3.Icon = global::abzar.Properties.Resources.daryafti;
            this.iconits3.IconSize = new System.Drawing.Size(80, 64);
            this.iconits3.Location = new System.Drawing.Point(1223, 251);
            this.iconits3.Margin = new System.Windows.Forms.Padding(4);
            this.iconits3.Name = "iconits3";
            this.iconits3.Size = new System.Drawing.Size(88, 81);
            this.iconits3.TabIndex = 74;
            this.iconits3.TooltipText = "";
            this.iconits3.Click += new System.EventHandler(this.iconits3_Click);
            // 
            // iconits4
            // 
            this.iconits4.BackColor = System.Drawing.Color.LavenderBlush;
            this.iconits4.Blur = true;
            this.iconits4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconits4.Icon = global::abzar.Properties.Resources.PARDAKHTI;
            this.iconits4.IconSize = new System.Drawing.Size(80, 64);
            this.iconits4.Location = new System.Drawing.Point(1223, 354);
            this.iconits4.Margin = new System.Windows.Forms.Padding(4);
            this.iconits4.Name = "iconits4";
            this.iconits4.Size = new System.Drawing.Size(88, 81);
            this.iconits4.TabIndex = 74;
            this.iconits4.TooltipText = "";
            this.iconits4.Click += new System.EventHandler(this.iconits4_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::abzar.Properties.Resources._3D_Pack__18_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1344, 696);
            this.Controls.Add(this.iconits4);
            this.Controls.Add(this.iconits3);
            this.Controls.Add(this.iconits1);
            this.Controls.Add(this.menuStrip1);
            this.MaximizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form3_FormClosed);
            this.Load += new System.EventHandler(this.Form3_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem qToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem ثبتمشتریToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem ثبتفروشندهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem بخشآزمايشToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem فاکتورخریدToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem بخشحسابداريToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پروندهاساتیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشمالیToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem حضورغیابToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem فروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem فروشToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private yojanahanif.Iconits iconits1;
        private yojanahanif.Iconits iconits3;
        private yojanahanif.Iconits iconits4;
        private System.Windows.Forms.ToolStripMenuItem ویرایشحسابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خریدToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripMenuItem فروشToolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem گزارشسودفروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripMenuItem ثبتکارمندToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem مدیریتاجناسهاToolStripMenuItem;
    }
}