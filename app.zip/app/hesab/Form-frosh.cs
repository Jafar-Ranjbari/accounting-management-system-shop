﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar
{
    public partial class Form_frosh : Form
    {
        public Form_frosh()
        {
            InitializeComponent();
        }

        private void iconits3_Click(object sender, EventArgs e)
        {
            sabt_Faktor.f_frosh2 f = new sabt_Faktor.f_frosh2();
            f.label2.Text = lb_name.Text;
            f.ShowDialog();

        }

        private void Form_frosh_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void iconits3_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel_name_kala.Visible = false;
        }

        private void Form_frosh_Load(object sender, EventArgs e)
        {

            classes.sabt d = new classes.sabt();
            string s = lb_name.Text;

            dataGridView2.DataSource = d.select_kala1(s);  
        }
    }
}
