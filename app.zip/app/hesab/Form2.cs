﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;
 

namespace hesabdari
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public classes.MaftooxCalendar.MaftooxPersianCalendar.TimeWork prdTime = new classes.MaftooxCalendar.MaftooxPersianCalendar.TimeWork();
        public classes. MaftooxCalendar.MaftooxPersianCalendar.DateWork prd = new classes.MaftooxCalendar.MaftooxPersianCalendar.DateWork(); 

        private void ثبتدورهآموزشیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.paye.f_sabt_kala f = new paye.f_sabt_kala();
            f.ShowDialog();
        }

       

        private void ثبتمشتریToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.paye.f_sabt_moshtari f = new paye.f_sabt_moshtari();
            f.ShowDialog();
        }

        private void ثبتفروشندهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.paye.f_sabt_froshande f = new paye.f_sabt_froshande();
            f.ShowDialog();
        }

        private void ثبتشمارهكاردكسToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.sabt_Faktor.f_frosh2 f = new sabt_Faktor.f_frosh2();
            f.ShowDialog();
        }

        private void فاکتورخریدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.sabt_Faktor.kharid f = new sabt_Faktor.kharid();
            f.ShowDialog();
        }

        private void معرفیفاکتورخریدبهانبارToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void ثبتچکپرداختیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.sabt_Faktor.f_chek_pardakhti f = new sabt_Faktor.f_chek_pardakhti();
            f.ShowDialog();
        }

        private void ثبتچکبرداشتیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.sabt_Faktor.f_chek_daryafti f = new sabt_Faktor.f_chek_daryafti();
            f.ShowDialog();

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            hesabdari.paye.f_anbar f = new paye.f_anbar();
            f.ShowDialog();
        }

        private void حضورغیابToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.Search.hesab_daryafti f = new Search.hesab_daryafti();
            f.ShowDialog();

        }

        private void گزارشمالیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.Search.hesab_pardakhti f = new Search.hesab_pardakhti();
            f.ShowDialog();
        }

        private void پرداختیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.Search.chek_pardakhti f = new Search.chek_pardakhti();
            f.ShowDialog();
        }

        private void دریافتیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.Search.chek_daryafti f = new Search.chek_daryafti();
            f.ShowDialog();
        }

        private void فروشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hesabdari.Search.kharid f = new Search.kharid();
            f.ShowDialog();
        }

        private void فروشToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            hesabdari.Search.frosh f = new Search.frosh();
            f.ShowDialog();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            hesabdari.classes.paye d5 = new classes.paye();
            DataTable dt = new DataTable();
            dt = d5.name_froshgah();
            string s = dt.Rows[0][0].ToString();
            Form2.ActiveForm.Text = "نرم افزار مدیریت  حسابداری  " + s;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void مديريتكاربرانToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            prdTime.Upate();
            String stry = prd.GetNameMonth() + prd.GetNameDayInMonth();
            //lbl_tarikh.Text = prd.GetNameDayInMonth() + "   " + prd.GetNumberDayInMonth().ToString() + "   " + prd.GetNameMonth() + "  سال  " + prd.GetNumberYear().ToString();
          //  lb_clock.Text = prdTime.GetNumberHour() + ":" + prdTime.GetNumberMinute() + ":" + prdTime.GetNumberSecond();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            hesabdari.ma f = new ma();
            f.ShowDialog();
        }
    }
}
