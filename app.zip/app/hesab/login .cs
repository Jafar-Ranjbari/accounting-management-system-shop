﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void login_Load(object sender, EventArgs e)
        {
            classes.paye d = new classes.paye();

            txtuser.DataSource = d.show_user1();
            txtuser.DisplayMember = "user_name";
            txtuser.ValueMember = "id_user";

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
           
           
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
           
        }

        private void btnlogin_Click_1(object sender, EventArgs e)
        {

            try
            {

                abzar.classes.Admin d = new classes.Admin();
              

                if (txtuser.Text == "1" && txtpass.Text == "1")

                {

                    Form f = new Form3();

                    this.Hide();
                     
                    f.Show();
                
                }

                else if (d.Login(txtuser.Text, txtpass.Text).Rows.Count > 0)
                {
                    Form_frosh f = new Form_frosh();
                 
                    this.Hide();
                    f.lb_name.Text = txtuser.Text;
                    f.Show();

                }
                else
                {
                    MessageBox.Show("نام کاربری یا رمز عبور جهت ورود به مدیریت سیستم معتبر نیست", "", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            
        }

        private void btnexit_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
