﻿namespace abzar
{
    partial class Form_frosh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.iconits3 = new yojanahanif.Iconits();
            this.lb_name = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_name_kala = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel_name_kala.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // iconits3
            // 
            this.iconits3.BackColor = System.Drawing.Color.LavenderBlush;
            this.iconits3.Blur = true;
            this.iconits3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconits3.Icon = global::abzar.Properties.Resources.frosh;
            this.iconits3.IconSize = new System.Drawing.Size(80, 64);
            this.iconits3.Location = new System.Drawing.Point(776, 63);
            this.iconits3.Margin = new System.Windows.Forms.Padding(4);
            this.iconits3.Name = "iconits3";
            this.iconits3.Size = new System.Drawing.Size(94, 91);
            this.iconits3.TabIndex = 75;
            this.iconits3.TooltipText = "";
            this.iconits3.Load += new System.EventHandler(this.iconits3_Load);
            this.iconits3.Click += new System.EventHandler(this.iconits3_Click);
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.Location = new System.Drawing.Point(972, 9);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(100, 23);
            this.lb_name.TabIndex = 76;
            this.lb_name.Text = "...............";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1127, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 23);
            this.label2.TabIndex = 76;
            this.label2.Text = "ویزیتور محترم ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(592, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(367, 23);
            this.label3.TabIndex = 76;
            this.label3.Text = "به بخش  مدیریت  سفارش اجناس  خوش آمدید  ";
            // 
            // panel_name_kala
            // 
            this.panel_name_kala.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel_name_kala.Controls.Add(this.label1);
            this.panel_name_kala.Controls.Add(this.pictureBox2);
            this.panel_name_kala.Controls.Add(this.dataGridView2);
            this.panel_name_kala.Location = new System.Drawing.Point(921, 50);
            this.panel_name_kala.Name = "panel_name_kala";
            this.panel_name_kala.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panel_name_kala.Size = new System.Drawing.Size(326, 370);
            this.panel_name_kala.TabIndex = 196;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 18);
            this.label1.TabIndex = 192;
            this.label1.Text = "اطلاعات  مربوط  به  اجناس برای سفارش  ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::abzar.Properties.Resources.Picture11;
            this.pictureBox2.Location = new System.Drawing.Point(293, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 28);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 191;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(24, 41);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(274, 318);
            this.dataGridView2.TabIndex = 189;
            // 
            // Form_frosh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::abzar.Properties.Resources._3D_Pack__18_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1259, 560);
            this.Controls.Add(this.panel_name_kala);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.iconits3);
            this.MaximizeBox = false;
            this.Name = "Form_frosh";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_frosh_FormClosed);
            this.Load += new System.EventHandler(this.Form_frosh_Load);
            this.panel_name_kala.ResumeLayout(false);
            this.panel_name_kala.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private yojanahanif.Iconits iconits3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Panel panel_name_kala;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label1;
    }
}