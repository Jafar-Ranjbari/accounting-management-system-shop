﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace abzar
{
    public partial class ss : Form
    {
        public ss()
        {
            InitializeComponent();
        }

        private void ss_Load(object sender, EventArgs e)
        {
         
            
            
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            abzar.login f = new login();
            f.Show();
            this.Hide();
          //  this.Close();
        }
    }
}
