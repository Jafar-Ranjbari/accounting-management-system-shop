﻿namespace hesabdari
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.analogClock1 = new AnalogClock.AnalogClock();
            this.qToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتدورهآموزشیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتمشتریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتفروشندهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.بخشآزمايشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتشمارهكاردكسToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.فاکتورخریدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتچکپرداختیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبتچکبرداشتیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بخشحسابداريToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پروندهاساتیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشمالیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.حضورغیابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.خریدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پرداختیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.دریافتیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.فروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.فروشToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.بخشامكاناتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مديريتكاربرانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.تهيهپشتيبانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.بازيابياطلاعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 12F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.qToolStripMenuItem,
            this.بخشآزمايشToolStripMenuItem,
            this.بخشحسابداريToolStripMenuItem,
            this.بخشامكاناتToolStripMenuItem,
            this.toolStripMenuItem5,
            this.toolStripMenuItem2});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(1264, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical270;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // analogClock1
            // 
            this.analogClock1.AccessibleRole = System.Windows.Forms.AccessibleRole.Clock;
            this.analogClock1.AllowDrop = true;
            this.analogClock1.BackColor = System.Drawing.Color.Transparent;
            this.analogClock1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("analogClock1.BackgroundImage")));
            this.analogClock1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.analogClock1.Draw1MinuteTicks = true;
            this.analogClock1.Draw5MinuteTicks = true;
            this.analogClock1.HourHandColor = System.Drawing.Color.DarkMagenta;
            this.analogClock1.Location = new System.Drawing.Point(1082, 30);
            this.analogClock1.MinuteHandColor = System.Drawing.Color.Green;
            this.analogClock1.Name = "analogClock1";
            this.analogClock1.SecondHandColor = System.Drawing.Color.Red;
            this.analogClock1.Size = new System.Drawing.Size(170, 204);
            this.analogClock1.TabIndex = 71;
            this.analogClock1.TicksColor = System.Drawing.Color.Black;
            // 
            // qToolStripMenuItem
            // 
            this.qToolStripMenuItem.Checked = true;
            this.qToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.qToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتدورهآموزشیToolStripMenuItem,
            this.toolStripSeparator4,
            this.ثبتمشتریToolStripMenuItem,
            this.toolStripSeparator3,
            this.ثبتفروشندهToolStripMenuItem,
            this.toolStripSeparator5,
            this.toolStripMenuItem3});
            this.qToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qToolStripMenuItem.Image = global::hesabdari.Properties.Resources.cubos;
            this.qToolStripMenuItem.Name = "qToolStripMenuItem";
            this.qToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.qToolStripMenuItem.Text = "اطلاعات پایه";
            this.qToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // ثبتدورهآموزشیToolStripMenuItem
            // 
            this.ثبتدورهآموزشیToolStripMenuItem.Image = global::hesabdari.Properties.Resources.add;
            this.ثبتدورهآموزشیToolStripMenuItem.Name = "ثبتدورهآموزشیToolStripMenuItem";
            this.ثبتدورهآموزشیToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.ثبتدورهآموزشیToolStripMenuItem.Text = "ثبت کالا  ";
            this.ثبتدورهآموزشیToolStripMenuItem.Click += new System.EventHandler(this.ثبتدورهآموزشیToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(189, 6);
            // 
            // ثبتمشتریToolStripMenuItem
            // 
            this.ثبتمشتریToolStripMenuItem.Image = global::hesabdari.Properties.Resources.users;
            this.ثبتمشتریToolStripMenuItem.Name = "ثبتمشتریToolStripMenuItem";
            this.ثبتمشتریToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.ثبتمشتریToolStripMenuItem.Text = "ثبت  مشتری  ";
            this.ثبتمشتریToolStripMenuItem.Click += new System.EventHandler(this.ثبتمشتریToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(189, 6);
            // 
            // ثبتفروشندهToolStripMenuItem
            // 
            this.ثبتفروشندهToolStripMenuItem.Image = global::hesabdari.Properties.Resources.user;
            this.ثبتفروشندهToolStripMenuItem.Name = "ثبتفروشندهToolStripMenuItem";
            this.ثبتفروشندهToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.ثبتفروشندهToolStripMenuItem.Text = "ثبت  فروشنده  ";
            this.ثبتفروشندهToolStripMenuItem.Click += new System.EventHandler(this.ثبتفروشندهToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(189, 6);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = global::hesabdari.Properties.Resources.large_icons;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(192, 22);
            this.toolStripMenuItem3.Text = "معرفی کالا به انبار ";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // بخشآزمايشToolStripMenuItem
            // 
            this.بخشآزمايشToolStripMenuItem.Checked = true;
            this.بخشآزمايشToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.بخشآزمايشToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator6,
            this.ثبتشمارهكاردكسToolStripMenuItem,
            this.toolStripSeparator8,
            this.فاکتورخریدToolStripMenuItem,
            this.toolStripSeparator1,
            this.ثبتچکپرداختیToolStripMenuItem,
            this.toolStripSeparator7,
            this.ثبتچکبرداشتیToolStripMenuItem});
            this.بخشآزمايشToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.بخشآزمايشToolStripMenuItem.Image = global::hesabdari.Properties.Resources.chip2;
            this.بخشآزمايشToolStripMenuItem.Name = "بخشآزمايشToolStripMenuItem";
            this.بخشآزمايشToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.بخشآزمايشToolStripMenuItem.Text = "ثبت  ";
            this.بخشآزمايشToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(190, 6);
            // 
            // ثبتشمارهكاردكسToolStripMenuItem
            // 
            this.ثبتشمارهكاردكسToolStripMenuItem.Image = global::hesabdari.Properties.Resources.shopping_cart_full;
            this.ثبتشمارهكاردكسToolStripMenuItem.Name = "ثبتشمارهكاردكسToolStripMenuItem";
            this.ثبتشمارهكاردكسToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.ثبتشمارهكاردكسToolStripMenuItem.Text = "ثبت فاکتور فروش  ";
            this.ثبتشمارهكاردكسToolStripMenuItem.Click += new System.EventHandler(this.ثبتشمارهكاردكسToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(190, 6);
            // 
            // فاکتورخریدToolStripMenuItem
            // 
            this.فاکتورخریدToolStripMenuItem.Image = global::hesabdari.Properties.Resources.money;
            this.فاکتورخریدToolStripMenuItem.Name = "فاکتورخریدToolStripMenuItem";
            this.فاکتورخریدToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.فاکتورخریدToolStripMenuItem.Text = "ثبت فاکتور خرید  ";
            this.فاکتورخریدToolStripMenuItem.Click += new System.EventHandler(this.فاکتورخریدToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(190, 6);
            // 
            // ثبتچکپرداختیToolStripMenuItem
            // 
            this.ثبتچکپرداختیToolStripMenuItem.Image = global::hesabdari.Properties.Resources.go;
            this.ثبتچکپرداختیToolStripMenuItem.Name = "ثبتچکپرداختیToolStripMenuItem";
            this.ثبتچکپرداختیToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.ثبتچکپرداختیToolStripMenuItem.Text = "ثبت  چک پرداختی  ";
            this.ثبتچکپرداختیToolStripMenuItem.Click += new System.EventHandler(this.ثبتچکپرداختیToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(190, 6);
            // 
            // ثبتچکبرداشتیToolStripMenuItem
            // 
            this.ثبتچکبرداشتیToolStripMenuItem.Image = global::hesabdari.Properties.Resources.back;
            this.ثبتچکبرداشتیToolStripMenuItem.Name = "ثبتچکبرداشتیToolStripMenuItem";
            this.ثبتچکبرداشتیToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.ثبتچکبرداشتیToolStripMenuItem.Text = "ثبت  چک  دریافتی  ";
            this.ثبتچکبرداشتیToolStripMenuItem.Click += new System.EventHandler(this.ثبتچکبرداشتیToolStripMenuItem_Click);
            // 
            // بخشحسابداريToolStripMenuItem
            // 
            this.بخشحسابداريToolStripMenuItem.BackColor = System.Drawing.Color.LightSkyBlue;
            this.بخشحسابداريToolStripMenuItem.Checked = true;
            this.بخشحسابداريToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.بخشحسابداريToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.پروندهاساتیدToolStripMenuItem,
            this.toolStripSeparator9,
            this.خریدToolStripMenuItem,
            this.toolStripSeparator2,
            this.فروشToolStripMenuItem,
            this.toolStripSeparator10,
            this.فروشToolStripMenuItem1});
            this.بخشحسابداريToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.بخشحسابداريToolStripMenuItem.Image = global::hesabdari.Properties.Resources.investigacion;
            this.بخشحسابداريToolStripMenuItem.Name = "بخشحسابداريToolStripMenuItem";
            this.بخشحسابداريToolStripMenuItem.Size = new System.Drawing.Size(148, 20);
            this.بخشحسابداريToolStripMenuItem.Text = "گزارش و جستجو  ";
            this.بخشحسابداريToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // پروندهاساتیدToolStripMenuItem
            // 
            this.پروندهاساتیدToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.گزارشمالیToolStripMenuItem,
            this.toolStripSeparator12,
            this.حضورغیابToolStripMenuItem});
            this.پروندهاساتیدToolStripMenuItem.Image = global::hesabdari.Properties.Resources.calendar;
            this.پروندهاساتیدToolStripMenuItem.Name = "پروندهاساتیدToolStripMenuItem";
            this.پروندهاساتیدToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.پروندهاساتیدToolStripMenuItem.Text = "حسابداری";
            // 
            // گزارشمالیToolStripMenuItem
            // 
            this.گزارشمالیToolStripMenuItem.Image = global::hesabdari.Properties.Resources.undo;
            this.گزارشمالیToolStripMenuItem.Name = "گزارشمالیToolStripMenuItem";
            this.گزارشمالیToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.گزارشمالیToolStripMenuItem.Text = "پرداختی";
            this.گزارشمالیToolStripMenuItem.Click += new System.EventHandler(this.گزارشمالیToolStripMenuItem_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(128, 6);
            // 
            // حضورغیابToolStripMenuItem
            // 
            this.حضورغیابToolStripMenuItem.Image = global::hesabdari.Properties.Resources.redo;
            this.حضورغیابToolStripMenuItem.Name = "حضورغیابToolStripMenuItem";
            this.حضورغیابToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.حضورغیابToolStripMenuItem.Text = "دریافتی  ";
            this.حضورغیابToolStripMenuItem.Click += new System.EventHandler(this.حضورغیابToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(136, 6);
            // 
            // خریدToolStripMenuItem
            // 
            this.خریدToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.پرداختیToolStripMenuItem,
            this.toolStripSeparator11,
            this.دریافتیToolStripMenuItem});
            this.خریدToolStripMenuItem.Image = global::hesabdari.Properties.Resources.app;
            this.خریدToolStripMenuItem.Name = "خریدToolStripMenuItem";
            this.خریدToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.خریدToolStripMenuItem.Text = "چک  ";
            // 
            // پرداختیToolStripMenuItem
            // 
            this.پرداختیToolStripMenuItem.Image = global::hesabdari.Properties.Resources.undo1;
            this.پرداختیToolStripMenuItem.Name = "پرداختیToolStripMenuItem";
            this.پرداختیToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.پرداختیToolStripMenuItem.Text = "پرداختی  ";
            this.پرداختیToolStripMenuItem.Click += new System.EventHandler(this.پرداختیToolStripMenuItem_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(132, 6);
            // 
            // دریافتیToolStripMenuItem
            // 
            this.دریافتیToolStripMenuItem.Image = global::hesabdari.Properties.Resources.redo;
            this.دریافتیToolStripMenuItem.Name = "دریافتیToolStripMenuItem";
            this.دریافتیToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.دریافتیToolStripMenuItem.Text = "دریافتی  ";
            this.دریافتیToolStripMenuItem.Click += new System.EventHandler(this.دریافتیToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(136, 6);
            // 
            // فروشToolStripMenuItem
            // 
            this.فروشToolStripMenuItem.Image = global::hesabdari.Properties.Resources.money;
            this.فروشToolStripMenuItem.Name = "فروشToolStripMenuItem";
            this.فروشToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.فروشToolStripMenuItem.Text = "خرید  ";
            this.فروشToolStripMenuItem.Click += new System.EventHandler(this.فروشToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(136, 6);
            // 
            // فروشToolStripMenuItem1
            // 
            this.فروشToolStripMenuItem1.Image = global::hesabdari.Properties.Resources.shopping_cart_full;
            this.فروشToolStripMenuItem1.Name = "فروشToolStripMenuItem1";
            this.فروشToolStripMenuItem1.Size = new System.Drawing.Size(139, 22);
            this.فروشToolStripMenuItem1.Text = "فروش  ";
            this.فروشToolStripMenuItem1.Click += new System.EventHandler(this.فروشToolStripMenuItem1_Click);
            // 
            // بخشامكاناتToolStripMenuItem
            // 
            this.بخشامكاناتToolStripMenuItem.Checked = true;
            this.بخشامكاناتToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.بخشامكاناتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مديريتكاربرانToolStripMenuItem,
            this.toolStripSeparator13,
            this.تهيهپشتيبانToolStripMenuItem,
            this.toolStripSeparator14,
            this.بازيابياطلاعاتToolStripMenuItem});
            this.بخشامكاناتToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.بخشامكاناتToolStripMenuItem.Image = global::hesabdari.Properties.Resources.engrane;
            this.بخشامكاناتToolStripMenuItem.Name = "بخشامكاناتToolStripMenuItem";
            this.بخشامكاناتToolStripMenuItem.Size = new System.Drawing.Size(120, 20);
            this.بخشامكاناتToolStripMenuItem.Text = "بخش  ابزارها ";
            this.بخشامكاناتToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // مديريتكاربرانToolStripMenuItem
            // 
            this.مديريتكاربرانToolStripMenuItem.Image = global::hesabdari.Properties.Resources.key1;
            this.مديريتكاربرانToolStripMenuItem.Name = "مديريتكاربرانToolStripMenuItem";
            this.مديريتكاربرانToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.مديريتكاربرانToolStripMenuItem.Text = "تغییر کلمه عبور  ";
            this.مديريتكاربرانToolStripMenuItem.Click += new System.EventHandler(this.مديريتكاربرانToolStripMenuItem_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(175, 6);
            // 
            // تهيهپشتيبانToolStripMenuItem
            // 
            this.تهيهپشتيبانToolStripMenuItem.Image = global::hesabdari.Properties.Resources.data;
            this.تهيهپشتيبانToolStripMenuItem.Name = "تهيهپشتيبانToolStripMenuItem";
            this.تهيهپشتيبانToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.تهيهپشتيبانToolStripMenuItem.Text = " تهيه پشتيبان ";
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(175, 6);
            // 
            // بازيابياطلاعاتToolStripMenuItem
            // 
            this.بازيابياطلاعاتToolStripMenuItem.Image = global::hesabdari.Properties.Resources.applications;
            this.بازيابياطلاعاتToolStripMenuItem.Name = "بازيابياطلاعاتToolStripMenuItem";
            this.بازيابياطلاعاتToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.بازيابياطلاعاتToolStripMenuItem.Text = "بازيابي اطلاعات";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Checked = true;
            this.toolStripMenuItem5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripMenuItem5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem5.Image = global::hesabdari.Properties.Resources.amor;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(95, 20);
            this.toolStripMenuItem5.Text = "درباره ما  ";
            this.toolStripMenuItem5.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Checked = true;
            this.toolStripMenuItem2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripMenuItem2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem2.Image = global::hesabdari.Properties.Resources.mantenimiento;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(69, 20);
            this.toolStripMenuItem2.Text = "خروج";
            this.toolStripMenuItem2.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1264, 595);
            this.ControlBox = false;
            this.Controls.Add(this.analogClock1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.Name = "Form2";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem qToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتدورهآموزشیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتمشتریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتفروشندهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem بخشآزمايشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتشمارهكاردكسToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فاکتورخریدToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem ثبتچکپرداختیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتچکبرداشتیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بخشحسابداريToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پروندهاساتیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشمالیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حضورغیابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خریدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پرداختیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem دریافتیToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem فروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فروشToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem بخشامكاناتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مديريتكاربرانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تهيهپشتيبانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بازيابياطلاعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Timer timer1;
        private AnalogClock.AnalogClock analogClock1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
    }
}