﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace hesabdari.classes
{
    public class ConDBMS
    {
        private SqlCommand cmd;
        public SqlConnection con;

        private SqlDataAdapter dba;
        private DataTable dt;
        public CommandType TypeCommand;
        private DataSet ds;

        public ConDBMS()
        {
            createConectionString();
            //if (typeConnection=="NoDB")
            //{
            //    createConectionStringNoDB();
            //}
            //else
            //{
            //    createConectionString();
            //}

        }
        protected virtual void createConectionStringNoDB()
        {
            this.createConectionString(@"data source=(local);initial catalog=HESABDARI.MDF;user id=sa;password=123;MultipleActiveResultSets=True");

           

        }

        protected virtual void createConectionString()
        {
            this.createConectionString(@"data source=(local);initial catalog=HESABDARI.MDF;user id=sa;password=123;MultipleActiveResultSets=True");
        }

        protected virtual void createConectionString(string constring)
        {

            if (!(string.IsNullOrEmpty(constring)))
            {
                this.con = new SqlConnection(constring);
            }
            else
            {
                throw new ApplicationException((constring + " parameter not defined "));

            }
        }



        protected virtual void CallStoreProcedure(string query)
        {
            if ((string.IsNullOrEmpty(query)))
            {
                throw new ApplicationException("No StoreProcedure");
            }

            else if (this.con == null)
            {
                throw new ApplicationException("Call CreateConnection method before using the connection.");
            }
            else
            {
                this.cmd = new SqlCommand(query, this.con);
                this.cmd.CommandType = TypeCommand;
            }

        }


        protected virtual void AddParametr(string name, object value, ParameterDirection direction)//7
        {
            if (this.cmd == null)
            {
                throw new ApplicationException("no Cmd");
            }
            if (string.IsNullOrEmpty(name))
            {
                throw new ApplicationException("No  Filed");
            }
            SqlParameter parametr = new SqlParameter(name, value);

            parametr.Direction = direction;

            this.cmd.Parameters.Add(parametr);
        }



        protected void ConOpen()
        {
            if (this.con.State == ConnectionState.Closed)
            {
                this.con.Open();
            }
        }

        protected void ConClose()
        {
            if (this.con.State == ConnectionState.Open)
            {
                this.con.Close();
            }
        }

        protected virtual int cmdExeNonQuery()
        {
            if (this.cmd == null)
            {
                throw new ApplicationException("No command");
            }
            if (this.con == null)
            {
                throw new ApplicationException("No CreateConnection");
            }

            int Count = 0;

            if (this.con.State == ConnectionState.Closed)
            {
                this.ConOpen();
            }

            Count = this.cmd.ExecuteNonQuery();

            if (this.con.State == ConnectionState.Open)
            {
                this.ConClose();
            }

            return (Count);

        }

        protected void disponsee()
        {
            if (this.cmd != null)
            {
                this.cmd.Dispose();
            }
            if (this.con != null)
            {
                this.con.Dispose();
            }
        }

        protected String cmdExcuteScalar()
        {
            if (this.cmd == null)
            {
                throw new ApplicationException("No command");
            }
            if (this.con == null)
            {
                throw new ApplicationException("No CreateConnection");
            }

            string Output = string.Empty;

            if (this.con.State == ConnectionState.Closed)
            {
                this.ConOpen();
            }

            Output = this.cmd.ExecuteScalar().ToString();

            if (this.con.State == ConnectionState.Open)
            {
                this.ConClose();
            }

            return (Output);
        }
        protected DataTable ExecuteDataTable()
        {
            if (this.cmd == null)
            {
                throw new ApplicationException("No command");
            }
            if (this.con == null)
            {
                throw new ApplicationException("No CreateConnection");
            }

            this.dba = new SqlDataAdapter(this.cmd);
            this.dt = new DataTable();
            this.dba.Fill(this.dt);


            return (this.dt);
        }
        public DataSet ExecuteDataSet()
        {
            if (this.cmd == null)
            {
                throw new ApplicationException("No command");
            }
            if (this.con == null)
            {
                throw new ApplicationException("No CreateConnection");
            }

            this.dba = new SqlDataAdapter(this.cmd);
            this.ds = new DataSet();
            this.dba.Fill(this.ds, "tmp");


            return (this.ds);
        }

    }
}
