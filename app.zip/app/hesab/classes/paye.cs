﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using hesabdari.classes;

namespace abzar.classes
{
   public class paye : ConDBMS
    {

        // ثبت  اجناس  

    

        public virtual int Add_sabt_kala(int id_kala, string name_kala, string name_vahed_kala)
        {
            CallStoreProcedure("Insert Into tbl_kala( id_kala, name_kala, name_vahed_kala ) Values(@id_kala, @name_kala, @name_vahed_kala)");

            AddParametr("@id_kala", id_kala, ParameterDirection.Input);
            AddParametr("@name_kala", name_kala, ParameterDirection.Input);
            AddParametr("@name_vahed_kala", name_vahed_kala, ParameterDirection.Input);
            return cmdExeNonQuery();

        }
        public DataTable show_search_Kala(string st)
        {
            CallStoreProcedure("SELECT     id_kala AS [شماره اجناس], name_kala AS [نام اجناس], name_vahed_kala AS [واحد اجناس] FROM         dbo.tbl_kala   where (name_kala LIKE N'%" + st + "%')  ");



            return ExecuteDataTable();

        }

        public DataTable showKala()
        {
            CallStoreProcedure("SELECT     id_kala AS [شماره اجناس], name_kala AS [نام اجناس], name_vahed_kala AS [واحد اجناس] FROM         dbo.tbl_kala ");



            return ExecuteDataTable();
        }


        public DataTable showKala1()
        {
            CallStoreProcedure("SELECT     * FROM         dbo.tbl_kala ");



            return ExecuteDataTable();
        }

        public virtual int delete_kala(int id_kala)
        {
            CallStoreProcedure("Delete from tbl_kala  Where  id_kala=@id_kala");

            AddParametr("@id_kala", id_kala, ParameterDirection.Input);
            return cmdExeNonQuery();


        }


        public virtual int Edit_Kala( int id_kala, string name_kala, string name_vahed_kala)
        {
            CallStoreProcedure("Update  tbl_kala Set   name_kala=@name_kala, name_vahed_kala=@name_vahed_kala  Where  id_kala=@id_kala");

            AddParametr("@id_kala", id_kala, ParameterDirection.Input);
            AddParametr("@name_kala", name_kala, ParameterDirection.Input);
            AddParametr("@name_vahed_kala", name_vahed_kala, ParameterDirection.Input);
            return cmdExeNonQuery();
        }


       // ثبت فروشنده  


        public virtual int Add_sabt_froshande( int id_froshande,string name_froshande,Double tel_froshande,string address_froshande,Double fax_froshande,string tozih_froshande)
        {
            CallStoreProcedure("Insert Into tbl_froshande( id_froshande, name_froshande, tel_froshande, address_froshande, fax_froshande, tozih_froshande ) Values(@id_froshande, @name_froshande, @tel_froshande, @address_froshande, @fax_froshande, @tozih_froshande)");

            AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);
            AddParametr("@name_froshande", name_froshande, ParameterDirection.Input);
            AddParametr("@tel_froshande", tel_froshande, ParameterDirection.Input);

            
            AddParametr("@address_froshande", address_froshande, ParameterDirection.Input);
            AddParametr("@fax_froshande", fax_froshande, ParameterDirection.Input);
            AddParametr("@tozih_froshande", tozih_froshande, ParameterDirection.Input);
            return cmdExeNonQuery();

        }
        public DataTable show_search_froshande(string st)
        {
            CallStoreProcedure("SELECT     id_froshande AS [شماره فروشنده], name_froshande AS [نام و نام خاوادگی], tel_froshande AS تلفن, fax_froshande AS فکس, address_froshande AS آدرس,   " +
                     "   tozih_froshande AS توضیحات   FROM         dbo.tbl_froshande  where (name_froshande LIKE N'%" + st + "%')  ");

            return ExecuteDataTable();
        }

        public DataTable show_Froshande()
        {
            CallStoreProcedure(" SELECT     id_froshande AS [شماره فروشنده], name_froshande AS [نام و نام خاوادگی], tel_froshande AS تلفن, fax_froshande AS فکس, address_froshande AS آدرس,    "+
                 "     tozih_froshande AS توضیحات    FROM         dbo.tbl_froshande ");

            return ExecuteDataTable();
        }


        public virtual int delete_Froshande(int id_froshande)
        {
            CallStoreProcedure("Delete from tbl_froshande  Where  id_froshande=@id_froshande");

            AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);
            return cmdExeNonQuery();


        }


        public virtual int Edit_Froshande(int id_froshande, string name_froshande, Double tel_froshande, string address_froshande, Double fax_froshande, string tozih_froshande)
        {
            CallStoreProcedure("Update  tbl_froshande  Set    name_froshande=@name_froshande, tel_froshande=@tel_froshande, address_froshande=@address_froshande, fax_froshande=@fax_froshande, tozih_froshande=@tozih_froshande where  id_froshande=@id_froshande");

        AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);
            AddParametr("@name_froshande", name_froshande, ParameterDirection.Input);
            AddParametr("@tel_froshande", tel_froshande, ParameterDirection.Input);
            AddParametr("@address_froshande", address_froshande, ParameterDirection.Input);
            AddParametr("@fax_froshande", fax_froshande, ParameterDirection.Input);
            AddParametr("@tozih_froshande", tozih_froshande, ParameterDirection.Input);
            return cmdExeNonQuery();
        }


        // ثبت مشتری  


        public virtual int Add_sabt_moshatri(int id_moshtari, string name_moshtari, Double fax_moshtari, Double tel_moshtari, string address_moshtari, string tozihat_moshtari)
        {
            CallStoreProcedure("Insert Into tbl_moshtari( id_moshtari, name_moshtari, fax_moshtari, tel_moshtari, address_moshtari, tozihat_moshtari) Values(@id_moshtari, @name_moshtari, @fax_moshtari, @tel_moshtari, @address_moshtari, @tozihat_moshtari)");

            AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);
            AddParametr("@name_moshtari", name_moshtari, ParameterDirection.Input);
            AddParametr("@fax_moshtari", fax_moshtari, ParameterDirection.Input);


            AddParametr("@tel_moshtari", tel_moshtari, ParameterDirection.Input);
            AddParametr("@address_moshtari", address_moshtari, ParameterDirection.Input);
            AddParametr("@tozihat_moshtari", tozihat_moshtari, ParameterDirection.Input);
            return cmdExeNonQuery();

        }
        public DataTable show_search_moshatri(string st)
        {
            CallStoreProcedure("SELECT     id_moshtari AS [شماره مشتری], name_moshtari AS [نام مشتری], fax_moshtari AS فکس, tel_moshtari AS تلفن, address_moshtari AS آدرس, tozihat_moshtari AS توضیحات   " +
    "        FROM         dbo.tbl_moshtari where (name_moshtari LIKE N'%" + st + "%')  ");




            return ExecuteDataTable();

        }

        public DataTable show_moshatri()
        {
            CallStoreProcedure("SELECT     id_moshtari AS [شماره مشتری], name_moshtari AS [نام مشتری], fax_moshtari AS فکس, tel_moshtari AS تلفن, address_moshtari AS آدرس, tozihat_moshtari AS توضیحات   " +
             "        FROM         dbo.tbl_moshtari ");




            return ExecuteDataTable();
        }


        public virtual int delete_moshatri(int id_moshtari)
        {
            CallStoreProcedure("Delete from tbl_moshtari  Where  id_moshtari=@id_moshtari");

            AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);
            return cmdExeNonQuery();


        }


        public virtual int Edit_moshatri(int id_moshtari, string name_moshtari, Double fax_moshtari, Double tel_moshtari, string address_moshtari, string tozihat_moshtari)
        {
            CallStoreProcedure("Update  tbl_moshtari  Set name_moshtari=@name_moshtari, fax_moshtari=@fax_moshtari, tel_moshtari=@tel_moshtari, address_moshtari=@address_moshtari, tozihat_moshtari =@tozihat_moshtari   where  id_moshtari=@id_moshtari");



            AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);
            AddParametr("@name_moshtari", name_moshtari, ParameterDirection.Input);
            AddParametr("@fax_moshtari", fax_moshtari, ParameterDirection.Input);


            AddParametr("@tel_moshtari", tel_moshtari, ParameterDirection.Input);
            AddParametr("@address_moshtari", address_moshtari, ParameterDirection.Input);
            AddParametr("@tozihat_moshtari", tozihat_moshtari, ParameterDirection.Input);
            return cmdExeNonQuery();
        }


        // معرفی  اجناس به انبار   
 

        public virtual int Add_anbar(   string name_kala,string name_vahed_kala,int megdar,Double final_price_kharid,Double final_price_frosh)
        {
            CallStoreProcedure("Insert Into tbl_kala(  name_kala, name_vahed_kala, megdar, final_price_kharid, final_price_frosh ) Values( @name_kala, @name_vahed_kala, @megdar, @final_price_kharid, @final_price_frosh )");

            
            AddParametr("@name_kala", name_kala, ParameterDirection.Input);
            AddParametr("@name_vahed_kala", name_vahed_kala, ParameterDirection.Input);

            AddParametr("@megdar", megdar, ParameterDirection.Input);
            AddParametr("@final_price_kharid", final_price_kharid, ParameterDirection.Input);
            AddParametr("@final_price_frosh", final_price_frosh, ParameterDirection.Input);

           
            return cmdExeNonQuery();


        }


        public DataTable show_anbar()
        {
            CallStoreProcedure("SELECT     id_kala AS [ش اجناس], name_kala AS [نام اجناس], name_vahed_kala AS [واحد اجناس], megdar AS [مقدار موجودی], final_price_kharid AS [قیمت  خرید],   "+
                   "   final_price_frosh AS [قیمت فروش]     " +
                 "      FROM         dbo.tbl_kala ");



            return ExecuteDataTable();
        }
        public virtual int delete_anbar(int id_kala)
        {
            CallStoreProcedure("Delete from tbl_kala  Where  id_kala=@id_kala");

            AddParametr("@id_kala", id_kala, ParameterDirection.Input);
            return cmdExeNonQuery();


        }


        public virtual int Edit_anbar(     int id_kala, string name_kala, string name_vahed_kala, int megdar, Double final_price_kharid, Double final_price_frosh)
        {
            CallStoreProcedure("Update  tbl_kala Set name_kala=@name_kala, name_vahed_kala=@name_vahed_kala, megdar=@megdar,final_price_kharid=@final_price_kharid,final_price_frosh=@final_price_frosh  Where   id_kala=@id_kala");
            AddParametr("@id_kala", id_kala, ParameterDirection.Input);
            AddParametr("@name_kala", name_kala, ParameterDirection.Input);
            AddParametr("@name_vahed_kala", name_vahed_kala, ParameterDirection.Input);

            AddParametr("@megdar", megdar, ParameterDirection.Input);
            AddParametr("@final_price_kharid", final_price_kharid, ParameterDirection.Input);
            AddParametr("@final_price_frosh", final_price_frosh, ParameterDirection.Input);
            

            return cmdExeNonQuery();
        }



        public DataTable show_search_name_kala(string name_kala)
        {
            CallStoreProcedure("SELECT      id_kala AS [ش اجناس], name_kala AS [نام اجناس], name_vahed_kala AS [واحد اجناس], megdar AS [مقدار موجودی], final_price_kharid AS [قیمت  خرید],   "+
                "      final_price_frosh AS [قیمت فروش]  "+
               "       FROM         dbo.tbl_kala " +
               "     WHERE   (name_kala LIKE N'%" + name_kala + "%')  ");

            AddParametr("@name_kala", name_kala, ParameterDirection.Input);


            return ExecuteDataTable();

        }

        public DataTable show_search_id_kala(int id_kala)
        {
            CallStoreProcedure("SELECT      id_kala AS [ش اجناس], name_kala AS [نام اجناس], name_vahed_kala AS [واحد اجناس], megdar AS [مقدار موجودی], final_price_kharid AS [قیمت  خرید],   " +
                "      final_price_frosh AS [قیمت فروش]  " +
               "       FROM         dbo.tbl_kala " +
               "     WHERE   (id_kala LIKE N'%" + id_kala + "%')  ");
            AddParametr("@id", id_kala, ParameterDirection.Input);




            return ExecuteDataTable();

        }


       // انتخاب  اجناس  برای اضافه کردن  انبار  




        public DataTable show_kala()
        {
            CallStoreProcedure("SELECT     id_kala AS [ش اجناس], name_kala AS [نام اجناس], name_vahed_kala AS [واحد اجناس]   "+
              "   FROM         dbo.tbl_kala    ");




            return ExecuteDataTable();

        }


      // تشخیص  وضیعت تکراری  نبودن  ورود اجناس به انبار  


        public DataTable count_kala(string name_kala)
        {
            CallStoreProcedure("     SELECT     COUNT(*) AS count  "+
         "  FROM         dbo.tbl_kala  "+
    "       GROUP BY name_kala "+
          "     HAVING      (name_kala = @name_kala)  ");





            AddParametr("@name_kala", name_kala, ParameterDirection.Input);


            return ExecuteDataTable();
        }

       

        


       ////////////////////////////////////////////////////


        //   SELECT     user_name, user_pass
        //  FROM         dbo.Tbl_user



        public virtual int Add_user(string user_name, string user_pass)
        {
            CallStoreProcedure("Insert Into Tbl_user(  user_name, user_pass  ) Values( @user_name, @user_pass  )");


            AddParametr("@user_name", user_name, ParameterDirection.Input);
            AddParametr("@user_pass", user_pass, ParameterDirection.Input);
 

            return cmdExeNonQuery();


        }


        public DataTable show_user()
        {
            CallStoreProcedure("  SELECT     id_user AS شماره, user_name AS [نام کارمند], user_pass AS پسورد      " + 
                 "      FROM         dbo.Tbl_user");



            return ExecuteDataTable();
        }



        public DataTable show_user1()
        {
            CallStoreProcedure("  SELECT     *    " +
                 "      FROM         dbo.Tbl_user");



            return ExecuteDataTable();
        }
        public virtual int delete_user(int id_user)
        {
            CallStoreProcedure("Delete from Tbl_user  Where    id_user=@id_user");

            AddParametr("id_user", id_user, ParameterDirection.Input);
            return cmdExeNonQuery();


        }

    }
}