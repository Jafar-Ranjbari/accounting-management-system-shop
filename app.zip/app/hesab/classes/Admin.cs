﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using hesabdari.classes;

namespace abzar.classes
{


    //   SELECT     user_name, user_pass
   //  FROM         dbo.Tbl_user
   public class Admin:ConDBMS
    {
       public DataTable Login(string user_name, string user_pass)
        {
            CallStoreProcedure("Select * From Tbl_user Where user_name=@user_name And user_pass=@user_pass");

            AddParametr("@user_name", user_name, ParameterDirection.Input);
            AddParametr("@user_pass", user_pass, ParameterDirection.Input);
            return ExecuteDataTable();

        }
       public virtual int ChangePass(string user_pass)
        {
            CallStoreProcedure("Update Tbl_user Set user_pass=@user_pass");

            AddParametr("@user_pass", user_pass, ParameterDirection.Input);
            return cmdExeNonQuery();
        }
        public string GetPass()
        {
            CallStoreProcedure("Select user_pass from Tbl_user");
            return cmdExcuteScalar();
        }
      

    }
}
