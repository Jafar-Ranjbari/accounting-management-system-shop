﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using hesabdari.classes;

namespace abzar.classes
{
 public   class Search:ConDBMS
 {
     public DataTable hesab_daryafti()
     {
         CallStoreProcedure(" SELECT     dbo.tbl_moshtari.name_moshtari AS [نام مشتری], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_frosh.id_frosh AS [شماره فاکتور],   " +
             "      dbo.tbl_frosh.price_kol_faktor_frosh AS [مجموع کل فاکتور], dbo.tbl_frosh.pay_nagd_frosh AS [پرداخت  نقدی], dbo.tbl_frosh.pay_mande_frosh AS [پول  مانده]   " +
                 " FROM        dbo.tbl_frosh INNER JOIN   " +
           "        dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN   " +
             "      dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN   " +
             "     dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari ");




         return ExecuteDataTable();

     }

       public DataTable hesab_daryafti_by_id (int id_moshtari)
       {
           CallStoreProcedure(" SELECT     dbo.tbl_moshtari.name_moshtari AS [نام مشتری], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_frosh.id_frosh AS [شماره فاکتور],   "+
                 "     dbo.tbl_frosh.price_kol_faktor_frosh AS [مجموع کل فاکتور], dbo.tbl_frosh.pay_nagd_frosh AS [پرداخت  نقدی], dbo.tbl_frosh.pay_mande_frosh AS [پول  مانده]   "+
           "     FROM         dbo.tbl_frosh INNER JOIN   "+
               "       dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN   "+
                 "     dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN   "+
                "      dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari   "+
             "   WHERE     (dbo.tbl_frosh.id_moshtari = @id_moshtari)   ");



           AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);


           return ExecuteDataTable();
       }



       public DataTable hesab_pardakhti()
       {
           CallStoreProcedure("   SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS تاریخ, dbo.tbl_kharid.id_kharid AS [ش فاکتور],   " +
                     "   dbo.tbl_kharid.price_kol_faktor_kharid AS [جمع کل فاکتور], dbo.tbl_kharid.pay_nagd_kharid AS [پرداخت نقدی], dbo.tbl_kharid.pay_mande_kharid AS [مانده حساب]   " +
                "        FROM         dbo.tbl_kharid INNER JOIN   " +
                   "     dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN  " +
                   "     dbo.tbl_kala ON dbo.tbl_kharid_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN   " +
                    "    dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande ");

           return ExecuteDataTable();
       }

     //}

       public DataTable show_search_moshatriiii(string st)
       {
           CallStoreProcedure("  SELECT     id_moshtari AS [ش مشتری], name_moshtari AS [نام و نام خانوادگی]   " +
             "     FROM         dbo.tbl_moshtari   " +
              "     WHERE   (name_moshtari LIKE N'%" + st + "%')  ");




           return ExecuteDataTable();

       }

           public DataTable showc_id_moshatriiii()
          {
              CallStoreProcedure("     SELECT     id_moshtari AS [ش مشتری], name_moshtari AS [نام و نام خانوادگی]   " + 
                "     FROM         dbo.tbl_moshtari");



              return ExecuteDataTable();
          }

      public DataTable showc_id_froshande()
      {
          CallStoreProcedure("      SELECT     id_froshande AS [شماره فروشنده], name_froshande AS [نام و نام خانوادگی] " +
        "    FROM         dbo.tbl_froshande");



          return ExecuteDataTable();
      }

      public DataTable show_search_moshatri(string st)
      {
          CallStoreProcedure("SELECT     id_froshande AS [شماره فروشنده], name_froshande AS [نام و نام خاوادگی]   " +
         "       FROM         dbo.tbl_froshande   " +
             "     WHERE   (name_froshande LIKE N'%" + st + "%')  ");




          return ExecuteDataTable();

      }



      public DataTable show_search_id_froshande1(string name_froshande)
      {
          CallStoreProcedure("  SELECT     dbo.tbl_chek_pardakhti.id_pardakht_chek AS ش, dbo.tbl_chek_pardakhti.id_froshande AS [ش گیرنده چک], dbo.tbl_froshande.name_froshande AS [نام چک گیرنده],   " +
                 "    dbo.tbl_chek_pardakhti.serial_pardakht_chek AS [ش سریال چک], dbo.tbl_chek_pardakhti.date_sodor_pardakht_chek AS [تاریخ  صدور],   " +
                 "    dbo.tbl_chek_pardakhti.date_sarresid_pardakht_chek AS [تاریخ سر رسید], dbo.tbl_chek_pardakhti.bank_pardakht_chek AS [نام بانک],   " +
                "     dbo.tbl_chek_pardakhti.mablagh_pardakht_chek AS [مبلغ چک], dbo.tbl_chek_pardakhti.tozih_pardakht_chek AS توضیحات   " +
       "        FROM         dbo.tbl_chek_pardakhti INNER JOIN   " +
          "           dbo.tbl_froshande ON dbo.tbl_chek_pardakhti.id_froshande = dbo.tbl_froshande.id_froshande  " +


             "    where (dbo.tbl_froshande.name_froshande LIKE N'%" + name_froshande + "%') ");
          AddParametr("@name_froshande", name_froshande, ParameterDirection.Input);



          return ExecuteDataTable();
      }
      public DataTable hesab_pardakhti_by_id(int id_froshande)
       {
           CallStoreProcedure(" SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS تاریخ, dbo.tbl_kharid.id_kharid AS [ش فاکتور],    "+
                  "    dbo.tbl_kharid.price_kol_faktor_kharid AS [جمع کل فاکتور], dbo.tbl_kharid.pay_nagd_kharid AS [پرداخت نقدی], dbo.tbl_kharid.pay_mande_kharid AS [مانده حساب]   "+
                  "    FROM         dbo.tbl_kharid INNER JOIN   "+
                 "     dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN   "+
                  "    dbo.tbl_kala ON dbo.tbl_kharid_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN   "+
                  "    dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande   "+
                "        WHERE     (dbo.tbl_kharid.id_froshande = @id_froshande) ");



           AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);


           return ExecuteDataTable();
       }

 


   





      

 


    


     



 


     
  
    




  

 
     

 

      


    

     //    خریییییییییییییییییییییییییییییییییییی از فروشنده 


     
      public DataTable kharid()
     {
         CallStoreProcedure("      SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS [تاریخ خرید], dbo.tbl_kharid.id_kharid AS [ش فاکتور], "+
                   "   dbo.tbl_kharid_by_kala.name_kala_kharid AS [نام اجناس], dbo.tbl_kharid_by_kala.vahed_kala_kharid AS واحد, dbo.tbl_kharid_by_kala.megdar_kharid AS تعداد,   "+
                   "   dbo.tbl_kharid_by_kala.price_vahed_kharid AS [قیمت واحد], dbo.tbl_kharid_by_kala.price_kol_kala_kharid AS [قیمت کل] "+
                 "     FROM         dbo.tbl_kharid INNER JOIN   "+
                 "     dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN   "+
                  "    dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande   "+
                "    GROUP BY dbo.tbl_froshande.name_froshande, dbo.tbl_kharid.date_kharid, dbo.tbl_kharid.id_kharid, dbo.tbl_kharid_by_kala.name_kala_kharid,  "+
                "      dbo.tbl_kharid_by_kala.vahed_kala_kharid, dbo.tbl_kharid_by_kala.megdar_kharid, dbo.tbl_kharid_by_kala.price_vahed_kharid,  "+
                "      dbo.tbl_kharid_by_kala.price_kol_kala_kharid");

         return ExecuteDataTable();

     }




     




      public DataTable kharid_by_tarikh(string date_kharid)
       {
           CallStoreProcedure("      SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS [تاریخ خرید], dbo.tbl_kharid.id_kharid AS [ش فاکتور], " +
                   "   dbo.tbl_kharid_by_kala.name_kala_kharid AS [نام اجناس], dbo.tbl_kharid_by_kala.vahed_kala_kharid AS واحد, dbo.tbl_kharid_by_kala.megdar_kharid AS تعداد,   " +
                   "   dbo.tbl_kharid_by_kala.price_vahed_kharid AS [قیمت واحد], dbo.tbl_kharid_by_kala.price_kol_kala_kharid AS [قیمت کل] " +
                 "     FROM         dbo.tbl_kharid INNER JOIN   " +
                 "     dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN   " +
                  "    dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande   " +
                "    GROUP BY dbo.tbl_froshande.name_froshande, dbo.tbl_kharid.date_kharid, dbo.tbl_kharid.id_kharid, dbo.tbl_kharid_by_kala.name_kala_kharid,  " +
                "      dbo.tbl_kharid_by_kala.vahed_kala_kharid, dbo.tbl_kharid_by_kala.megdar_kharid, dbo.tbl_kharid_by_kala.price_vahed_kharid,  " +
                "      dbo.tbl_kharid_by_kala.price_kol_kala_kharid     " +
           "         HAVING      (dbo.tbl_kharid.date_kharid =  @date_kharid) ");



           AddParametr("@date_kharid", date_kharid, ParameterDirection.Input);


           return ExecuteDataTable();
       }



      public DataTable kharid_by_sh_faktor(int id_kharid)
       {
           CallStoreProcedure("        SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS [تاریخ خرید], dbo.tbl_kharid.id_kharid AS [ش فاکتور], " +
                   "   dbo.tbl_kharid_by_kala.name_kala_kharid AS [نام اجناس], dbo.tbl_kharid_by_kala.vahed_kala_kharid AS واحد, dbo.tbl_kharid_by_kala.megdar_kharid AS تعداد,   " +
                   "   dbo.tbl_kharid_by_kala.price_vahed_kharid AS [قیمت واحد], dbo.tbl_kharid_by_kala.price_kol_kala_kharid AS [قیمت کل] " +
                 "     FROM         dbo.tbl_kharid INNER JOIN   " +
                 "     dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN   " +
                  "    dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande   " +
                "    GROUP BY dbo.tbl_froshande.name_froshande, dbo.tbl_kharid.date_kharid, dbo.tbl_kharid.id_kharid, dbo.tbl_kharid_by_kala.name_kala_kharid,  " +
                "      dbo.tbl_kharid_by_kala.vahed_kala_kharid, dbo.tbl_kharid_by_kala.megdar_kharid, dbo.tbl_kharid_by_kala.price_vahed_kharid,  " +
                "      dbo.tbl_kharid_by_kala.price_kol_kala_kharid     " +
                  "       HAVING      (dbo.tbl_kharid.id_kharid = @id_kharid) ");



           AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);


           return ExecuteDataTable();
       }


      public DataTable kharid_by_id_froshande(int id_froshande)
       {
           CallStoreProcedure("    SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS [تاریخ خرید], dbo.tbl_kharid.id_kharid AS [ش فاکتور],  "+
                  "    dbo.tbl_kharid_by_kala.name_kala_kharid AS [نام اجناس], dbo.tbl_kharid_by_kala.vahed_kala_kharid AS واحد, dbo.tbl_kharid_by_kala.megdar_kharid AS تعداد,   "+
                 "     dbo.tbl_kharid_by_kala.price_vahed_kharid AS [قیمت واحد], dbo.tbl_kharid_by_kala.price_kol_kala_kharid AS [قیمت کل]   "+
                 "   FROM         dbo.tbl_kharid INNER JOIN   "+
                "      dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN     "+
                  "    dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande  "+
        "          GROUP BY dbo.tbl_froshande.name_froshande, dbo.tbl_kharid.date_kharid, dbo.tbl_kharid.id_kharid, dbo.tbl_kharid_by_kala.name_kala_kharid,   "+
             "         dbo.tbl_kharid_by_kala.vahed_kala_kharid, dbo.tbl_kharid_by_kala.megdar_kharid, dbo.tbl_kharid_by_kala.price_vahed_kharid,    "+
                "      dbo.tbl_kharid_by_kala.price_kol_kala_kharid, dbo.tbl_froshande.id_froshande     "+
        "           HAVING      (dbo.tbl_froshande.id_froshande = @id_froshande)   ");



           AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);


           return ExecuteDataTable();
       }




      public DataTable kharid_by_id_froshande_and_tarikh(int id_froshande, string date_kharid)
       {
           CallStoreProcedure("     SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS [تاریخ خرید], dbo.tbl_kharid.id_kharid AS [ش فاکتور],   "+
                 "     dbo.tbl_kharid_by_kala.name_kala_kharid AS [نام اجناس], dbo.tbl_kharid_by_kala.vahed_kala_kharid AS واحد, dbo.tbl_kharid_by_kala.megdar_kharid AS تعداد,    "+
                "      dbo.tbl_kharid_by_kala.price_vahed_kharid AS [قیمت واحد], dbo.tbl_kharid_by_kala.price_kol_kala_kharid AS [قیمت کل]     "+
          "       FROM         dbo.tbl_kharid INNER JOIN      "+
                "      dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN     "+
              "        dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande   "+
        "        GROUP BY dbo.tbl_froshande.name_froshande, dbo.tbl_kharid.date_kharid, dbo.tbl_kharid.id_kharid, dbo.tbl_kharid_by_kala.name_kala_kharid,  "+
             "         dbo.tbl_kharid_by_kala.vahed_kala_kharid, dbo.tbl_kharid_by_kala.megdar_kharid, dbo.tbl_kharid_by_kala.price_vahed_kharid,    "+
             "         dbo.tbl_kharid_by_kala.price_kol_kala_kharid, dbo.tbl_froshande.id_froshande         "+
      "           HAVING      (dbo.tbl_froshande.id_froshande = @id_froshande) AND (dbo.tbl_kharid.date_kharid =  @date_kharid)  ");



           AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);
           AddParametr("@date_kharid", date_kharid, ParameterDirection.Input);


           return ExecuteDataTable();
       }
    

    

     public DataTable kharid_by_id_kala(int id_kala)
       {
           CallStoreProcedure("    SELECT     dbo.tbl_froshande.name_froshande AS [نام فروشنده], dbo.tbl_kharid.date_kharid AS [تاریخ خرید], dbo.tbl_kharid.id_kharid AS [ش فاکتور],   "+
                   "   dbo.tbl_kharid_by_kala.name_kala_kharid AS [نام اجناس], dbo.tbl_kharid_by_kala.vahed_kala_kharid AS واحد, dbo.tbl_kharid_by_kala.megdar_kharid AS تعداد,   "+
                 "     dbo.tbl_kharid_by_kala.price_vahed_kharid AS [قیمت واحد], dbo.tbl_kharid_by_kala.price_kol_kala_kharid AS [قیمت کل]   "+
                   "     FROM         dbo.tbl_kharid INNER JOIN     "+
                  "    dbo.tbl_kharid_by_kala ON dbo.tbl_kharid.id_kharid = dbo.tbl_kharid_by_kala.id_kharid INNER JOIN     "+
                   "   dbo.tbl_froshande ON dbo.tbl_kharid.id_froshande = dbo.tbl_froshande.id_froshande     "+
               "     GROUP BY dbo.tbl_froshande.name_froshande, dbo.tbl_kharid.date_kharid, dbo.tbl_kharid.id_kharid, dbo.tbl_kharid_by_kala.name_kala_kharid,       "+
                   "   dbo.tbl_kharid_by_kala.vahed_kala_kharid, dbo.tbl_kharid_by_kala.megdar_kharid, dbo.tbl_kharid_by_kala.price_vahed_kharid,     "+
                  "    dbo.tbl_kharid_by_kala.price_kol_kala_kharid, dbo.tbl_kharid_by_kala.id_kala       "+
            "         HAVING      (dbo.tbl_kharid_by_kala.id_kala = @id_kala)  ");



           AddParametr("@id_kala", id_kala, ParameterDirection.Input);


           return ExecuteDataTable();
       }











     //    فروش ش ش ش ش ش ش ش ش ش ش ش ش ش  ش ش  شش  از مشتری ی ی ی ی ی ی ی ی ی ی  ی ی ی ی ی   



     public DataTable frosh()
     {
         CallStoreProcedure("     SELECT      dbo.tbl_frosh.price_kol_faktor_frosh AS [قیمت  کل], dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد],   "+
                  "    dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس],    "+
                   "   dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS [تاریخ خرید], dbo.tbl_moshtari.name_moshtari AS [نام مشتری]  "+
         "         FROM         dbo.tbl_frosh INNER JOIN    "+
                 "     dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN    "+
                 "     dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari  "+
          "        GROUP BY dbo.tbl_frosh.price_kol_faktor_frosh, dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_frosh_by_kala.megdar_frosh, dbo.tbl_frosh_by_kala.vahed_kala_frosh,   "+
               "       dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh.date_frosh, dbo.tbl_moshtari.name_moshtari     "+
                     "       ORDER BY [نام اجناس]");

         return ExecuteDataTable();

     }


     public DataTable frosh_by_tarikh(string date_frosh)
     {
         CallStoreProcedure("    SELECT     dbo.tbl_frosh.price_kol_faktor_frosh AS [قیمت  کل], dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد],    "+
                   "   dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس],    "+
                   "  dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS [تاریخ خرید], dbo.tbl_moshtari.name_moshtari AS [نام مشتری]    "+
                   "        FROM         dbo.tbl_frosh INNER JOIN       "+
                  "    dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     "+
                   "   dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari  "+
             "      GROUP BY dbo.tbl_frosh.price_kol_faktor_frosh, dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_frosh_by_kala.megdar_frosh, dbo.tbl_frosh_by_kala.vahed_kala_frosh,    "+
                "      dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh.date_frosh, dbo.tbl_moshtari.name_moshtari     "+
         "          HAVING      (dbo.tbl_frosh.date_frosh =@date_frosh )  " +
         "         ORDER BY [نام اجناس] ");



         AddParametr("@date_frosh",date_frosh, ParameterDirection.Input);


         return ExecuteDataTable();
     }



     public DataTable frosh_by_sh_faktor(int id_frosh)
     {
         CallStoreProcedure("    SELECT      dbo.tbl_frosh.price_kol_faktor_frosh AS [قیمت  کل], dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد],   " +
                  "    dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس],    " +
                   "   dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS [تاریخ خرید], dbo.tbl_moshtari.name_moshtari AS [نام مشتری]  " +
         "         FROM         dbo.tbl_frosh INNER JOIN    " +
                 "     dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN    " +
                 "     dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari  " +
          "        GROUP BY dbo.tbl_frosh.price_kol_faktor_frosh, dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_frosh_by_kala.megdar_frosh, dbo.tbl_frosh_by_kala.vahed_kala_frosh,   " +
               "       dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh.date_frosh, dbo.tbl_moshtari.name_moshtari     " +
             
                "       HAVING      (dbo.tbl_frosh.id_frosh = @id_frosh)   ORDER BY [نام اجناس] ");



         AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);


         return ExecuteDataTable();
     }

     // 

     public DataTable frosh_by_id_moshtari(int id_moshtari)
     {
         CallStoreProcedure("    SELECT    dbo.tbl_frosh.price_kol_faktor_frosh AS [قیمت  کل], dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد],   "+
                   "   dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس],   "+
                  "    dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS [تاریخ خرید], dbo.tbl_moshtari.name_moshtari AS [نام مشتری]      "+
             "        FROM         dbo.tbl_frosh INNER JOIN      "+
                 "     dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     "+
                 "     dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari   "+
              "     GROUP BY dbo.tbl_frosh.price_kol_faktor_frosh, dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_frosh_by_kala.megdar_frosh, dbo.tbl_frosh_by_kala.vahed_kala_frosh,    "+
              "        dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh.date_frosh, dbo.tbl_moshtari.name_moshtari, dbo.tbl_moshtari.id_moshtari      "+
         "         HAVING      (dbo.tbl_moshtari.id_moshtari = @id_moshtari)   " +
          "            ORDER BY [نام اجناس]   ");



         AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);


         return ExecuteDataTable();
     }




     public DataTable frosh_by_id_moshtari_and_tarikh(int id_moshtari, string date_frosh)
     {
         CallStoreProcedure("      SELECT      dbo.tbl_frosh.price_kol_faktor_frosh AS [قیمت  کل], dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد],    "+
                  "    dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس],    "+
                  "    dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS [تاریخ خرید], dbo.tbl_moshtari.name_moshtari AS [نام مشتری]    "+
            "             FROM         dbo.tbl_frosh INNER JOIN    "+
              "        dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN    "+
                "      dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari    "+
           "    GROUP BY dbo.tbl_frosh.price_kol_faktor_frosh, dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_frosh_by_kala.megdar_frosh, dbo.tbl_frosh_by_kala.vahed_kala_frosh,  "+
               "       dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh.date_frosh, dbo.tbl_moshtari.name_moshtari, dbo.tbl_moshtari.id_moshtari "+
          "      HAVING      (dbo.tbl_moshtari.id_moshtari = @id_moshtari) AND (dbo.tbl_frosh.date_frosh =  @date_frosh)     "+
      "          ORDER BY [نام اجناس]  ");



         AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);
         AddParametr("@date_frosh", date_frosh, ParameterDirection.Input);


         return ExecuteDataTable();
     }




     public DataTable frosh_by_id_kala(int id_kala)
     {
         CallStoreProcedure("    SELECT       dbo.tbl_frosh.price_kol_faktor_frosh AS [قیمت  کل], dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد],   "+
                 "     dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس],      "+
                 "     dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS [تاریخ خرید], dbo.tbl_moshtari.name_moshtari AS [نام مشتری]     "+
     "          FROM         dbo.tbl_frosh INNER JOIN      "+
            "          dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN   "+
              "        dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari     "+    
     "           GROUP BY dbo.tbl_frosh.price_kol_faktor_frosh, dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_frosh_by_kala.megdar_frosh, dbo.tbl_frosh_by_kala.vahed_kala_frosh,    "+
          "            dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh.date_frosh, dbo.tbl_moshtari.name_moshtari, dbo.tbl_frosh_by_kala.id_kala        "+
       "        HAVING      (dbo.tbl_frosh_by_kala.id_kala = @id_kala)      " +
   "           ORDER BY [نام اجناس]");



         AddParametr("@id_kala", id_kala, ParameterDirection.Input);


         return ExecuteDataTable();
     }



     // سود فروش /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




    




 public DataTable frosh_sod()
     {
         CallStoreProcedure("     SELECT     dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام مشتری],    "+
                 "     dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_kala.final_price_kharid AS [قیمت خرید],    "+
                  "    dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت فروش],    "+
                 "     dbo.tbl_frosh_by_kala.megdar_frosh * (dbo.tbl_frosh_by_kala.price_vahed_frosh - dbo.tbl_kala.final_price_kharid) AS سود    "+
                 "    FROM         dbo.tbl_frosh INNER JOIN       "+
                 "     dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     "+
                 "     dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN     "+
                 "     dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari   "+
                "    GROUP BY dbo.tbl_moshtari.name_moshtari, dbo.tbl_frosh.date_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh_by_kala.megdar_frosh,     "+
                 "     dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_kala.final_price_kharid");

         return ExecuteDataTable();

     }


     public DataTable frosh_by_tarikh_sod(string date_frosh)
     {
         CallStoreProcedure("    SELECT     dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام مشتری],    " +
                  "    dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_kala.final_price_kharid AS [قیمت خرید],      " +
                  "    dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت فروش],     " +
                  "    dbo.tbl_frosh_by_kala.megdar_frosh * (dbo.tbl_frosh_by_kala.price_vahed_frosh - dbo.tbl_kala.final_price_kharid) AS سود        " +
         "         FROM         dbo.tbl_frosh INNER JOIN        " +
              "        dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     " +
                "      dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN       " +
                  "    dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari      " +
       "             GROUP BY dbo.tbl_moshtari.name_moshtari, dbo.tbl_frosh.date_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh_by_kala.megdar_frosh,      " +
           "           dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_kala.final_price_kharid, dbo.tbl_frosh_by_kala.id_kala     " +
         "          HAVING      (dbo.tbl_frosh.date_frosh =@date_frosh )  ");
      



         AddParametr("@date_frosh",date_frosh, ParameterDirection.Input);


         return ExecuteDataTable();
     }



     public DataTable frosh_by_sh_faktor_sod(int id_frosh)
     {
         CallStoreProcedure("      SELECT     dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام مشتری],    " +
                  "    dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_kala.final_price_kharid AS [قیمت خرید],      " +
                  "    dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت فروش],     " +
                  "    dbo.tbl_frosh_by_kala.megdar_frosh * (dbo.tbl_frosh_by_kala.price_vahed_frosh - dbo.tbl_kala.final_price_kharid) AS سود        " +
         "         FROM         dbo.tbl_frosh INNER JOIN        " +
              "        dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     " +
                "      dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN       " +
                  "    dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari      " +
       "             GROUP BY dbo.tbl_moshtari.name_moshtari, dbo.tbl_frosh.date_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh_by_kala.megdar_frosh,      " +
           "           dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_kala.final_price_kharid, dbo.tbl_frosh_by_kala.id_kala     " +
             
                "       HAVING      (dbo.tbl_frosh.id_frosh = @id_frosh)   ");



         AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);


         return ExecuteDataTable();
     }

     // 

     public DataTable frosh_by_id_moshtari_sod(int id_moshtari)
     {
         CallStoreProcedure("    SELECT     dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام مشتری],    "+
                 "     dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_kala.final_price_kharid AS [قیمت خرید],    "+
                 "     dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت فروش],      "+
                 "     dbo.tbl_frosh_by_kala.megdar_frosh * (dbo.tbl_frosh_by_kala.price_vahed_frosh - dbo.tbl_kala.final_price_kharid) AS سود, dbo.tbl_moshtari.id_moshtari    "+
                 "     FROM         dbo.tbl_frosh INNER JOIN     "+
                 "     dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     "+
                  "    dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN    "+
                  "    dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari       "+
                   "    GROUP BY dbo.tbl_moshtari.name_moshtari, dbo.tbl_frosh.date_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh_by_kala.megdar_frosh,    "+
                  "    dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_kala.final_price_kharid, dbo.tbl_frosh_by_kala.id_kala, dbo.tbl_moshtari.id_moshtari     "+
                  "   HAVING      (dbo.tbl_moshtari.id_moshtari = @id_moshtari)  ");



         AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);


         return ExecuteDataTable();
     }




     public DataTable frosh_by_id_moshtari_and_tarikh_sod(int id_moshtari, string date_frosh)
     {
         CallStoreProcedure("         SELECT     dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام مشتری],     "+
                  "    dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_kala.final_price_kharid AS [قیمت خرید],    "+
                   "   dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت فروش],    "+
                  "    dbo.tbl_frosh_by_kala.megdar_frosh * (dbo.tbl_frosh_by_kala.price_vahed_frosh - dbo.tbl_kala.final_price_kharid) AS سود    "+
                   "     FROM         dbo.tbl_frosh INNER JOIN   "+
                   "   dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     "+
                   "   dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN     "+
                 "     dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari    "+
                "  GROUP BY dbo.tbl_moshtari.name_moshtari, dbo.tbl_frosh.date_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh_by_kala.megdar_frosh,    "+
                 "     dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_kala.final_price_kharid, dbo.tbl_frosh_by_kala.id_kala, dbo.tbl_moshtari.id_moshtari     "+
                  "    HAVING      (dbo.tbl_moshtari.id_moshtari = @id_moshtari) AND (dbo.tbl_frosh.date_frosh =  @date_frosh)      ");



         AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);
         AddParametr("@date_frosh", date_frosh, ParameterDirection.Input);


         return ExecuteDataTable();
     }




     public DataTable frosh_by_id_kala_sod(int id_kala)
     {
         CallStoreProcedure("          SELECT     dbo.tbl_frosh.id_frosh AS [ش فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام مشتری],    "+
                  "    dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد, dbo.tbl_kala.final_price_kharid AS [قیمت خرید],      "+
                  "    dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت فروش],     "+
                  "    dbo.tbl_frosh_by_kala.megdar_frosh * (dbo.tbl_frosh_by_kala.price_vahed_frosh - dbo.tbl_kala.final_price_kharid) AS سود        "+
         "         FROM         dbo.tbl_frosh INNER JOIN        "+
              "        dbo.tbl_frosh_by_kala ON dbo.tbl_frosh.id_frosh = dbo.tbl_frosh_by_kala.id_frosh INNER JOIN     "+
                "      dbo.tbl_kala ON dbo.tbl_frosh_by_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN       "+
                  "    dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari      "+
       "             GROUP BY dbo.tbl_moshtari.name_moshtari, dbo.tbl_frosh.date_frosh, dbo.tbl_frosh.id_frosh, dbo.tbl_frosh_by_kala.name_kala_frosh, dbo.tbl_frosh_by_kala.megdar_frosh,      "+
           "           dbo.tbl_frosh_by_kala.price_vahed_frosh, dbo.tbl_kala.final_price_kharid, dbo.tbl_frosh_by_kala.id_kala     "+
      "       HAVING      (dbo.tbl_frosh_by_kala.id_kala = @id_kala) ");



         AddParametr("@id_kala", id_kala, ParameterDirection.Input);


         return ExecuteDataTable();
     }












     // حساب  فروش  
     public DataTable edit_hesab_frosh(int id_moshtari)
     {
         CallStoreProcedure("  SELECT     id_frosh AS [ش فاکتور], date_frosh AS تاریخ, price_kol_kala_frosh AS [جمع کل فاکتور], discount_frosh AS تخفیف,  "+
                   "   sundries_frosh AS [هزینه متفرقه], price_kol_faktor_frosh AS [جمع فاکتور  نهایی], pay_nagd_frosh AS [پرداخت نقد], pay_mande_frosh AS [مانده حساب]   "+
           "   FROM         dbo.tbl_frosh "+
      "     GROUP BY id_frosh, date_frosh, id_moshtari, price_kol_kala_frosh, discount_frosh, sundries_frosh, price_kol_faktor_frosh, pay_nagd_frosh, pay_mande_frosh "+
   "      HAVING      (id_moshtari = @id_moshtari)");



         AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);


         return ExecuteDataTable();
     }



     public virtual int delete_edit_hesab_frosh(int id_frosh)
     {
         CallStoreProcedure("Delete from tbl_frosh  Where  id_frosh=@id_frosh");

         AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);
         return cmdExeNonQuery();


     }

        public virtual int sabt_edit_hesab_frosh(int id_frosh )
       {
           CallStoreProcedure("Update  tbl_kala Set    date_frosh=@date_frosh, id_moshtari=@id_moshtari, price_kol_kala_frosh=@price_kol_kala_frosh, discount_frosh=@discount_frosh, sundries_frosh=@sundries_frosh, price_kol_faktor_frosh=@price_kol_faktor_frosh, pay_nagd_frosh=@pay_nagd_frosh, "+
                      "  pay_mande_frosh=@pay_nagd_frosh, id_moshtari=@id_moshtari, price_kol_kala_frosh=@price_kol_kala_frosh, discount_frosh=@discount_frosh, sundries_frosh=@sundries_frosh, price_kol_faktor_frosh=@price_kol_faktor_frosh, pay_nagd_frosh=@pay_nagd_frosh, "+
                  "    pay_mande_frosh=@pay_mande_frosh  Where  id_frosh=@id_frosh");

           AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);
           
           return cmdExeNonQuery();
       }

        public DataTable search_edit_hesab_frosh(int id_moshtari, string date_frosh)
       {
           CallStoreProcedure( "  SELECT     id_frosh AS [ش فاکتور], date_frosh AS تاریخ, price_kol_kala_frosh AS [جمع کل فاکتور], discount_frosh AS تخفیف, sundries_frosh AS [هزینه متفرقه],   "+
                "      price_kol_faktor_frosh AS [جمع فاکتور  نهایی], pay_nagd_frosh AS [پرداخت نقد], pay_mande_frosh AS [مانده حساب]   "+
             "       FROM         dbo.tbl_frosh     "+
         "     WHERE     (id_moshtari = @id_moshtari) AND (date_frosh = @date_frosh)");

           AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);
           AddParametr("@date_frosh", date_frosh, ParameterDirection.Input);
           
           return ExecuteDataTable();
       }





        // حساب  خرید   
        public DataTable edit_hesab_kharid(int id_froshande)
        {
            CallStoreProcedure("  SELECT     id_kharid AS [ش فاکتور], date_kharid AS تاریخ, price_kol_kala_kharid AS [جمع کل فاکتور], discount_kharid AS تخفیف, sundries_kharid AS [هزینه متفرقه],    "+
                  "    price_kol_faktor_kharid AS [جمع  نهایی], pay_nagd_kharid AS [پرداخت نقد], pay_mande_kharid AS [مانده حساب]         "+
"  FROM         dbo.tbl_kharid      "+
"   WHERE     (id_froshande = @id_froshande)");



            AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);


            return ExecuteDataTable();
        }



        public virtual int delete_edit_hesab_kharid(int id_kharid)
        {
            CallStoreProcedure("Delete from tbl_kharid  Where  id_kharid=@id_kharid");

            AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);
            return cmdExeNonQuery();


        }



        public DataTable search_edit_hesab_kharid(int id_froshande, string date_kharid)
        {
            CallStoreProcedure("  SELECT     id_kharid AS [ش فاکتور], date_kharid AS تاریخ, price_kol_kala_kharid AS [جمع کل فاکتور], discount_kharid AS تخفیف, sundries_kharid AS [هزینه متفرقه],    " +
                  "    price_kol_faktor_kharid AS [جمع  نهایی], pay_nagd_kharid AS [پرداخت نقد], pay_mande_kharid AS [مانده حساب]         " +
"  FROM         dbo.tbl_kharid      " +
          "     WHERE     (id_froshande = @id_froshande) AND (date_kharid = @date_kharid)");

            AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);
            AddParametr("@date_kharid", date_kharid, ParameterDirection.Input);

            return ExecuteDataTable();
        }

   

    }
}
