﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using hesabdari.classes;

namespace abzar.classes
{
   public class sabt:ConDBMS
    {
       // قیمت  فروش  

       public DataTable price_frosh(int id_kala)
       {
           CallStoreProcedure("SELECT     final_price_frosh     "+
"FROM         dbo.tbl_kala     "+
     "         WHERE     (id_kala = @id_kala)   ");



           AddParametr("@id_kala", id_kala, ParameterDirection.Input);


           return ExecuteDataTable();
       }


       public virtual int Add_frosh_kala(int id_kala, string name_kala_frosh, string vahed_kala_frosh, int megdar_frosh, Double price_vahed_frosh, Double price_kol_kala_frosh, int id_frosh)
       {
           CallStoreProcedure("Insert Into tbl_frosh_by_kala( id_kala, name_kala_frosh, vahed_kala_frosh, megdar_frosh, price_vahed_frosh, price_kol_kala_frosh,id_frosh ) Values(@id_kala, @name_kala_frosh, @vahed_kala_frosh, @megdar_frosh, @price_vahed_frosh, @price_kol_kala_frosh,@id_frosh)");

           AddParametr("@id_kala", id_kala, ParameterDirection.Input);
           AddParametr("@name_kala_frosh", name_kala_frosh, ParameterDirection.Input);
           AddParametr("@megdar_frosh", megdar_frosh, ParameterDirection.Input);
           AddParametr("@vahed_kala_frosh", vahed_kala_frosh, ParameterDirection.Input);
           AddParametr("@price_vahed_frosh", price_vahed_frosh, ParameterDirection.Input);
           AddParametr("@price_kol_kala_frosh", price_kol_kala_frosh, ParameterDirection.Input);
           AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);

           return cmdExeNonQuery();

       }





       public DataTable show_frosh_Kala(int id_frosh)
       {
           CallStoreProcedure(" SELECT     id_frosh_by_kala AS ش, id_kala AS [ش اجناس], name_kala_frosh AS [نام اجناس], vahed_kala_frosh AS واحد, megdar_frosh AS تعداد, price_vahed_frosh AS [قیمت واحد],   "+
                    "  price_kol_kala_frosh AS [قیمت کل]   "+
               "       FROM         dbo.tbl_frosh_by_kala where id_frosh=@id_frosh ");


           AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);



           return ExecuteDataTable();
       }
 
       public virtual int delete_frosh_kala(int id_frosh_by_kala)
       {
           CallStoreProcedure("Delete from tbl_frosh_by_kala  Where  id_frosh_by_kala=@id_frosh_by_kala");

           AddParametr("@id_frosh_by_kala", id_frosh_by_kala, ParameterDirection.Input);
           return cmdExeNonQuery();


       }
       // شماره  بیشترین مقدار  ایدی فروش   

       public DataTable max_ID_frosh()
       {
           CallStoreProcedure(" SELECT     MAX(id_frosh) AS Expr1   "+
            "       FROM         dbo.tbl_frosh ");



           return ExecuteDataTable();
       }



       public DataTable show_search_Kala(string st)
       {
           CallStoreProcedure("SELECT     id_kala AS [شماره اجناس], name_kala AS [نام اجناس], name_vahed_kala AS [واحد اجناس] FROM         dbo.tbl_kala   where (name_kala LIKE N'%" + st + "%')  ");



           return ExecuteDataTable();

       }

       //   ثبت  فاکتور  


       public virtual int Add_faktor_frosh(int id_frosh)
       {
           CallStoreProcedure("Insert Into tbl_frosh(  id_frosh ) Values(@id_frosh)");

           AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);
    

           return cmdExeNonQuery();

       }

       public virtual int Edit_faktor_frosh(int id_kala, string name_kala, string name_vahed_kala)
       {
           CallStoreProcedure("Update  tbl_kala Set   name_kala=@name_kala, name_vahed_kala=@name_vahed_kala  Where  id_kala=@id_kala");

           AddParametr("@id_kala", id_kala, ParameterDirection.Input);
           AddParametr("@name_kala", name_kala, ParameterDirection.Input);
           AddParametr("@name_vahed_kala", name_vahed_kala, ParameterDirection.Input);
           return cmdExeNonQuery();
       }




         public DataTable   show_kala( )
       {
           CallStoreProcedure("  SELECT     id_kala AS ش, name_kala AS [نام اجناس], name_vahed_kala AS و    "+
  "        FROM         dbo.tbl_kala");

       
    

           return ExecuteDataTable();

       }


          public DataTable   show_moshatari( )
       {
           CallStoreProcedure("    SELECT     id_moshtari AS ش, name_moshtari AS [نام مشتری]  "+
 " FROM         dbo.tbl_moshtari");

       
    

           return ExecuteDataTable();

       }

          public DataTable show_search_moshatri(string st)
          {
              CallStoreProcedure("SELECT     id_moshtari AS [شماره مشتری], name_moshtari AS [نام مشتری]   " +
      "        FROM         dbo.tbl_moshtari where (name_moshtari LIKE N'%" + st + "%')  ");




              return ExecuteDataTable();

          }
          public DataTable show_search_frosh_Kala(int id_frosh, string name_kala_frosh)
          {
              CallStoreProcedure(" SELECT     id_frosh_by_kala AS ش, id_kala AS [ش اجناس], name_kala_frosh AS [نام اجناس], vahed_kala_frosh AS واحد, megdar_frosh AS تعداد, price_vahed_frosh AS [قیمت واحد],   " +
                       "  price_kol_kala_frosh AS [قیمت کل]   " +
                  "       FROM         dbo.tbl_frosh_by_kala where (id_frosh=@id_frosh)AND(name_kala_frosh LIKE N'%" + name_kala_frosh + "%')  ");


              AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);

              AddParametr("@name_kala_frosh", name_kala_frosh, ParameterDirection.Input);

              return ExecuteDataTable();
          }


         public DataTable sum_frosh_Kala(int id_frosh )
          {
              CallStoreProcedure("  SELECT     SUM(price_kol_kala_frosh) AS Expr1, id_frosh  "+
" FROM         dbo.tbl_frosh_by_kala  "+
" GROUP BY id_frosh "+
" HAVING      (id_frosh = @id_frosh)  ");


              AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);
 

              return ExecuteDataTable();
          }




       // sabt koli frosh 

        public virtual int Edit_sabt_koli_frosh ( int  id_frosh,string date_frosh,int id_moshtari,Double price_kol_kala_frosh,Double discount_frosh,Double sundries_frosh,Double price_kol_faktor_frosh,Double pay_nagd_frosh,Double pay_mande_frosh)
     {
         CallStoreProcedure("Update  tbl_frosh Set  date_frosh=@date_frosh, id_moshtari=@id_moshtari, price_kol_kala_frosh=@price_kol_kala_frosh, discount_frosh=@discount_frosh, sundries_frosh=@sundries_frosh, price_kol_faktor_frosh=@price_kol_faktor_frosh, pay_nagd_frosh=@pay_nagd_frosh, pay_mande_frosh=@pay_mande_frosh     Where  id_frosh=@id_frosh");
         AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);
         AddParametr("@date_frosh", date_frosh, ParameterDirection.Input);
         AddParametr("@id_moshtari", id_moshtari, ParameterDirection.Input);
         AddParametr("@price_kol_kala_frosh", price_kol_kala_frosh, ParameterDirection.Input);

         AddParametr("@discount_frosh", discount_frosh, ParameterDirection.Input);
         AddParametr("@sundries_frosh", sundries_frosh, ParameterDirection.Input);
         AddParametr("@price_kol_faktor_frosh", price_kol_faktor_frosh, ParameterDirection.Input);

         AddParametr("@pay_nagd_frosh", pay_nagd_frosh, ParameterDirection.Input);

               AddParametr("@pay_mande_frosh", pay_mande_frosh, ParameterDirection.Input);


         return cmdExeNonQuery(); 
     }


 // خرید د د د د د ددددددددددددددددددددددددددددددددد ددددد دددددددد دددددددددددددد دددد دددد دد ددددددددد ددددددددد


        public virtual int Add_kharid_kala(int id_kala, string name_kala_kharid, string vahed_kala_kharid, int megdar_kharid, Double price_vahed_kharid, Double price_kol_kala_kharid, int id_kharid)
        {
            CallStoreProcedure("Insert Into tbl_kharid_by_kala( id_kala, name_kala_kharid, vahed_kala_kharid, megdar_kharid, price_vahed_kharid, price_kol_kala_kharid, id_kharid ) Values( @id_kala, @name_kala_kharid, @vahed_kala_kharid, @megdar_kharid, @price_vahed_kharid, @price_kol_kala_kharid, @id_kharid)");

            AddParametr("@id_kala", id_kala, ParameterDirection.Input);
            AddParametr("@name_kala_kharid", name_kala_kharid, ParameterDirection.Input);
            AddParametr("@megdar_kharid", megdar_kharid, ParameterDirection.Input);
            AddParametr("@vahed_kala_kharid", vahed_kala_kharid, ParameterDirection.Input);
            AddParametr("@price_vahed_kharid", price_vahed_kharid, ParameterDirection.Input);
            AddParametr("@price_kol_kala_kharid", price_kol_kala_kharid, ParameterDirection.Input);
            AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);

            return cmdExeNonQuery();

        }

        public DataTable show_kharid_Kala(int id_kharid)
        {
            CallStoreProcedure("SELECT     id_kharid_by_kala AS ش, name_kala_kharid AS [نام اجناس], vahed_kala_kharid AS [واحد اجناس], megdar_kharid AS مقدار, price_vahed_kharid AS [قیمت  واحد],  "+
                  "    price_kol_kala_kharid AS [قیمت کل]   "+
               "      FROM         dbo.tbl_kharid_by_kala where id_kharid=@id_kharid ");


            AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);



            return ExecuteDataTable();
        }




        public DataTable sum_kharid_Kala(int id_kharid)
        {
            CallStoreProcedure(" SELECT     SUM(price_kol_kala_kharid) AS Expr1   "+
       "      FROM         dbo.tbl_kharid_by_kala   "+
       "        GROUP BY id_kharid   "+
        "       HAVING      (id_kharid = @id_kharid)  ");


            AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);


            return ExecuteDataTable();
        }




        public DataTable max_ID_kharid()
        {
            CallStoreProcedure(" SELECT     MAX(id_kharid) AS Expr1   "+
           "     FROM         dbo.tbl_kharid ");



            return ExecuteDataTable();
        }



        public virtual int Add_faktor_kharid(int id_kharid)
        {
            CallStoreProcedure("Insert Into tbl_kharid(  id_kharid ) Values(@id_kharid)");

            AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);


            return cmdExeNonQuery();

        }



        public DataTable show_froshande()
        {
            CallStoreProcedure("  SELECT     id_froshande AS ش, name_froshande AS [نام فروشنده]  "+
     "             FROM         dbo.tbl_froshande  ");




            return ExecuteDataTable();

        }


        public DataTable show_search_froshande(string st)
        {
            CallStoreProcedure("  SELECT     id_froshande AS ش, name_froshande AS [نام فروشنده]  " +
     "             FROM         dbo.tbl_froshande where (name_froshande LIKE N'%" + st + "%')  ");




            return ExecuteDataTable();

        }



        public DataTable show_search_kharid_Kala(int id_kharid, string name_kala_kharid)
          {
              CallStoreProcedure(" SELECT     id_kharid_by_kala AS ش, name_kala_kharid AS [نام اجناس], vahed_kala_kharid AS [واحد اجناس], megdar_kharid AS مقدار, price_vahed_kharid AS [قیمت  واحد],  " +
                  "    price_kol_kala_kharid AS [قیمت کل]   " +
               "      FROM         dbo.tbl_kharid_by_kala where (id_kharid=@id_kharid)AND(name_kala_kharid LIKE N'%" + name_kala_kharid + "%')  ");


              AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);

              AddParametr("@name_kala_kharid", name_kala_kharid, ParameterDirection.Input);

              return ExecuteDataTable();
          }



        public virtual int delete_kharid_kala(int id_kharid_by_kala)
        {
            CallStoreProcedure("Delete from tbl_kharid_by_kala  Where  id_kharid_by_kala=@id_kharid_by_kala");

            AddParametr("@id_kharid_by_kala", id_kharid_by_kala, ParameterDirection.Input);
            return cmdExeNonQuery();


        }




        // sabt koli kharid

        public virtual int Edit_sabt_koli_kharid(int id_kharid, string date_kharid, int id_froshande, Double price_kol_kala_kharid, Double discount_kharid, Double sundries_kharid, Double price_kol_faktor_kharid, Double pay_nagd_kharid, Double pay_mande_kharid)
        {
            CallStoreProcedure("Update  tbl_kharid Set  date_kharid=@date_kharid, id_froshande=@id_froshande, price_kol_kala_kharid=@price_kol_kala_kharid, discount_kharid=@discount_kharid, sundries_kharid=@sundries_kharid, price_kol_faktor_kharid=@price_kol_faktor_kharid, pay_nagd_kharid=@pay_nagd_kharid, pay_mande_kharid=@pay_mande_kharid     Where  id_kharid=@id_kharid");
            AddParametr("@id_kharid", id_kharid, ParameterDirection.Input);
            AddParametr("@date_kharid", date_kharid, ParameterDirection.Input);
            AddParametr("@id_froshande", id_froshande, ParameterDirection.Input);
            AddParametr("@price_kol_kala_kharid", price_kol_kala_kharid, ParameterDirection.Input);

            AddParametr("@discount_kharid", discount_kharid, ParameterDirection.Input);
            AddParametr("@sundries_kharid", sundries_kharid, ParameterDirection.Input);
            AddParametr("@price_kol_faktor_kharid", price_kol_faktor_kharid, ParameterDirection.Input);

            AddParametr("@pay_nagd_kharid", pay_nagd_kharid, ParameterDirection.Input);

            AddParametr("@pay_mande_kharid", pay_mande_kharid, ParameterDirection.Input);


            return cmdExeNonQuery();
        }


     //  SELECT     id_kharid, id_froshande, date_kharid, price_kol_kala_kharid, discount_kharid, sundries_kharid, price_kol_faktor_kharid, pay_nagd_kharid, pay_mande_kharid
   //         FROM         dbo.tbl_kharid



//       SELECT     id_kharid_by_kala, id_kala, name_kala_kharid, vahed_kala_kharid, megdar_kharid, price_vahed_kharid, price_kol_kala_kharid, id_kharid
//FROM         dbo.tbl_kharid_by_kala


      

       public DataTable date ( )
          { 
              CallStoreProcedure("   SELECT     date_kharid  "+
          "      FROM         dbo.tbl_kharid  ");


      

              return ExecuteDataTable();
          }


     // report frosh  






       public   DataTable report_frosh(  int id_frosh)
        {
            CallStoreProcedure("  SELECT     dbo.tbl_frosh.id_frosh AS [شماره فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام  مشتری], dbo.tbl_moshtari.id_moshtari AS [ش مشتری],  "+
                   "   dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد,   "+
                  "    dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد], dbo.tbl_frosh_by_kala.price_kol_kala_frosh AS [قیمت کل], dbo.tbl_frosh.pay_nagd_frosh AS [پرداخت نقدی],  "+
                 "     dbo.tbl_frosh.pay_mande_frosh AS [مانده حساب]   "+
      "              FROM         dbo.tbl_frosh_by_kala INNER JOIN    "+
                 "     dbo.tbl_frosh ON dbo.tbl_frosh_by_kala.id_frosh = dbo.tbl_frosh.id_frosh INNER JOIN      "+
                "      dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari   "+
        "       WHERE     (dbo.tbl_frosh.id_frosh = @id_frosh)");

   
            AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);
            return ExecuteDataTable();


        }


       public int id_frosh1;
       
        public DataTable test_report( int id_frosh)
        {
            CallStoreProcedure("    SELECT     dbo.tbl_frosh.id_frosh AS [شماره فاکتور], dbo.tbl_frosh.date_frosh AS تاریخ, dbo.tbl_moshtari.name_moshtari AS [نام  مشتری], dbo.tbl_moshtari.id_moshtari AS [ش مشتری],    "+
                   "   dbo.tbl_frosh_by_kala.name_kala_frosh AS [نام اجناس], dbo.tbl_frosh_by_kala.vahed_kala_frosh AS واحد, dbo.tbl_frosh_by_kala.megdar_frosh AS تعداد,  "+
                     " dbo.tbl_frosh_by_kala.price_vahed_frosh AS [قیمت واحد], dbo.tbl_frosh_by_kala.price_kol_kala_frosh AS [قیمت کل], dbo.tbl_frosh.pay_nagd_frosh AS [پرداخت نقدی],   "+
                    "  dbo.tbl_frosh.pay_mande_frosh AS [مانده حساب]   "+
                    "      FROM         dbo.tbl_frosh_by_kala INNER JOIN   "+
                  "    dbo.tbl_frosh ON dbo.tbl_frosh_by_kala.id_frosh = dbo.tbl_frosh.id_frosh INNER JOIN   "+
                "      dbo.tbl_moshtari ON dbo.tbl_frosh.id_moshtari = dbo.tbl_moshtari.id_moshtari   "+
                   "        WHERE     (dbo.tbl_frosh.id_frosh = @id_frosh) ");

            AddParametr("@id_frosh", id_frosh, ParameterDirection.Input);


            return ExecuteDataTable();

        }

       public string Getmax_id_frosh()
        {
            CallStoreProcedure("SELECT     TOP (100) PERCENT MAX(id_frosh) AS Expr1   "+ 
   "      FROM         dbo.tbl_frosh   "+ 
       "      ORDER BY MAX(id_frosh)");
            return cmdExcuteScalar();
        }


  // SELECT     id, id_user, id_kala
// FROM         dbo.Tbl_user_kala


       public virtual int Add_kala_and_user(int id_user, int id_kala)
       {
           CallStoreProcedure("Insert Into Tbl_user_kala(  id_user, id_kala  ) Values( @id_user, @id_kala  )");


           AddParametr("@id_user", id_user, ParameterDirection.Input);
           AddParametr("@id_kala", id_kala, ParameterDirection.Input);


           return cmdExeNonQuery();

       }


       public DataTable show_kala_and_user( int  id_user )
       {
           CallStoreProcedure("  SELECT     dbo.Tbl_user_kala.id AS شماره, dbo.tbl_kala.name_kala AS [نام اجناس]   "+
            "        FROM         dbo.Tbl_user_kala INNER JOIN     "+
                   "   dbo.tbl_kala ON dbo.Tbl_user_kala.id_kala = dbo.tbl_kala.id_kala  "+
              "   WHERE     (dbo.Tbl_user_kala.id_user = @id_user)");

           AddParametr("@id_user", id_user, ParameterDirection.Input);

           return ExecuteDataTable();
       }




       public virtual int delete_kala_and_user(int id)
       {
           CallStoreProcedure("Delete from Tbl_user_kala  Where    id=@id");

           AddParametr("id", id, ParameterDirection.Input);
           return cmdExeNonQuery();


       }


       public DataTable select_kala(string user_name)
       {
           CallStoreProcedure("  SELECT     dbo.tbl_kala.id_kala AS ش, dbo.tbl_kala.name_kala AS [نام اجناس], dbo.tbl_kala.name_vahed_kala    "+
                 "       FROM         dbo.Tbl_user_kala INNER JOIN   "+
                  "     dbo.tbl_kala ON dbo.Tbl_user_kala.id_kala = dbo.tbl_kala.id_kala INNER JOIN   "+ 
                   "    dbo.Tbl_user ON dbo.Tbl_user_kala.id_user = dbo.Tbl_user.id_user   "+
                  "     WHERE     (dbo.Tbl_user.user_name = N'"+user_name+"') ");
          

           AddParametr("@user_name", user_name, ParameterDirection.Input);
           


           return ExecuteDataTable();

       }



        public DataTable select_kala1(string user_name)
       {
           CallStoreProcedure("   SELECT     dbo.tbl_kala.name_kala AS [نام اجناس], dbo.tbl_kala.megdar AS [موجودی اجناس]   " + 
                   "     FROM         dbo.tbl_kala INNER JOIN      "+ 
                  "    dbo.Tbl_user_kala ON dbo.tbl_kala.id_kala = dbo.Tbl_user_kala.id_kala INNER JOIN      "+ 
                  "    dbo.Tbl_user ON dbo.Tbl_user_kala.id_user = dbo.Tbl_user.id_user "+
                  "     WHERE     (dbo.Tbl_user.user_name = N'"+user_name+"') ");
          

           AddParametr("@user_name", user_name, ParameterDirection.Input);
           


           return ExecuteDataTable();

       }



      
   
   
    }
}
